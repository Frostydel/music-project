# SONARIA: The World That Hears You (prototype)

2D top-down fantasy adventure in Godot 4.3 (GDScript). Music changes the world: sing notes to revive trees, grow bridges, wake ancient mechanisms and make rivers run. No external assets or API keys needed; all art and audio are generated in code.

## Run (Ubuntu)
1. Install Godot 4.3 (https://godotengine.org/download/linux) and make it available as `godot`.
2. `cd sonaria && godot --path .`   (first launch: `godot --path . --import`)

## Controls
WASD/Arrows move | E interact | 1/2/3 select Growth/Resonance/Flow note | Space sing | in puzzles 1-4 notes, L listen, H hint, R retry, Backspace undo | Esc pause | F3 Director debug panel

## How to play
Wake the Awakening Stone (Repeat the Melody) -> clear the thicket (Growth) -> ring the Spring Hollow chimes in the mural's order (Environmental Harmony, gives Flow) -> grow the Elder Willow bridge -> read the 4 tablets and open the Resonance Shrine (gives Resonance) -> wake the 2 pillars, flood the aqueduct, open the door -> collect 4 melody fragments (the 4th comes from a Director event) -> sing the Main Melody at the Heart Altar.

## Architecture (scripts/)
- `core/` GameState (autoload), Player, Game, data, art/fx helpers
- `world/` World builder, collision grid (flood-fill reachability), River, Ground, objects/
- `director/` EventSpec (schema), EventValidator, RuleDirector (scoring), FallbackEvents, EventExecutor, WorldDirector, PuzzleGenerator
- `llm/` optional LLMAdapter (OpenAI-compatible endpoint)
- `audio/` AudioManager (synth + procedural music that grows richer with restoration)
- `ui/` HUD, puzzle UI, dialogue, title, pause, victory

## AI World Director
Pipeline: GameState snapshot -> Director (rules, or optional LLM proposal) -> Validator -> Executor -> World, with predefined Fallback events if anything fails.
- 8 event types: hidden shrine, musical creature, environment puzzle, corruption shift, route opening, discovery, tutorial assist, ability lesson.
- Reacts to: just-unlocked ability (lesson), repeated failures (assist / easier variants), thorough exploration (shrine), region restored (no corruption events), missing fragments (guaranteed fragment event), repetition (penalties, cooldowns, caps).
- Deterministic for a given seed and state. New seed = different puzzles, scatter and events.
- The validator rejects unsupported types, bad abilities/rewards, unmet prerequisites, unreachable sites and unsolvable puzzles. LLM output is whitelisted to data fields and never executes code.

## Optional LLM (off by default)
Set `SONARIA_LLM_ENDPOINT` (OpenAI-compatible chat URL), optionally `SONARIA_LLM_API_KEY`, `SONARIA_LLM_MODEL`, `SONARIA_LLM_TIMEOUT`. Keys are read from the environment only.

## Tests (headless)
`GODOT=/path/to/godot TEST_PARTS=unit tests/run_tests.sh` (parts: unit, world, llm, shell).
Screenshots: `tools/shot.sh NAME --autostart --seed=1` (needs xvfb + mesa).

## Status / known limitations (honest)
- Verified by running: project loads and runs; renders (screenshots checked); 69 unit tests pass (generators, validator, Director adaptation, determinism, fallbacks, audio synth); 22 world tests pass (collision, reachability, abilities, thicket).
- Not yet verified: the full scripted playthrough from the Awakening Stone onward, the LLM failure-mode tests, and the pause/victory shell tests were written but not run to completion. Two world tests currently fail (collecting a revealed cache; capturing the Awakening Stone puzzle request in the test harness), so expect bugs there.
- Never played by a human; audio not heard (dummy driver); balance and pacing untested.
- No save/load; art is procedural and simple.
- Dev flag: `-- --autostart --seed=N --cheat=restore|abilities --at=X,Y`.
