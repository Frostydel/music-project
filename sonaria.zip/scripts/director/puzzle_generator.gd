class_name PuzzleGenerator
extends RefCounted
## Deterministic puzzle generation. Every generator output passes
## `is_solvable`, so impossible puzzles cannot exist.

static func melody(rng: RandomNumberGenerator, length: int, alphabet: Array, need_all := false) -> Array:
    var out: Array = []
    for attempt in 80:
        out.clear()
        for i in length:
            out.append(alphabet[rng.randi_range(0, alphabet.size() - 1)])
        if _acceptable(out, alphabet, need_all):
            return out
    # Deterministic safe fallback: cycle through the alphabet.
    out.clear()
    for i in length:
        out.append(alphabet[i % alphabet.size()])
    return out

static func _acceptable(m: Array, alphabet: Array, need_all: bool) -> bool:
    var distinct := {}
    for n in m:
        distinct[n] = true
    if need_all and distinct.size() < alphabet.size():
        return false
    if distinct.size() < mini(2, alphabet.size()):
        return false
    for i in range(2, m.size()):
        if m[i] == m[i - 1] and m[i] == m[i - 2]:
            return false
    return true

static func event_melody(rng: RandomNumberGenerator, difficulty: int) -> Dictionary:
    var d := clampi(difficulty, 1, 3)
    var alphabet: Array = SData.NOTES.slice(0, 3 if d < 3 else 4)
    return {"kind": "repeat_melody", "notes": melody(rng, 2 + d, alphabet), "alphabet": alphabet, "difficulty": d}

static func order(rng: RandomNumberGenerator, n: int) -> Array:
    var base: Array = []
    for i in n:
        base.append(i)
    for attempt in 40:
        var g := base.duplicate()
        for i in range(g.size() - 1, 0, -1):
            var j := rng.randi_range(0, i)
            var tmp = g[i]
            g[i] = g[j]
            g[j] = tmp
        if g != base:
            return g
    base.reverse()
    return base

static func event_order(rng: RandomNumberGenerator, n: int) -> Dictionary:
    return {"kind": "order", "glyphs": order(rng, n), "difficulty": 1}

static func main_puzzles(rng: RandomNumberGenerator) -> Dictionary:
    var three: Array = ["C", "E", "G"]
    return {
        "awakening": {"kind": "repeat_melody", "notes": melody(rng, 3, three), "alphabet": three, "difficulty": 1},
        "spring": {"kind": "order", "glyphs": order(rng, 4), "difficulty": 2},
        "shrine": {"kind": "shrine", "notes": melody(rng, 4, SData.NOTES), "alphabet": SData.NOTES, "difficulty": 2},
        "altar": {"kind": "repeat_melody", "notes": melody(rng, 8, SData.NOTES, true), "alphabet": SData.NOTES, "difficulty": 3},
    }

## Structural solvability check: the answer must be expressible with the
## inputs the player actually has.
static func is_solvable(spec: Variant) -> bool:
    if typeof(spec) != TYPE_DICTIONARY:
        return false
    var kind = spec.get("kind", "")
    if kind == "repeat_melody" or kind == "shrine":
        var notes = spec.get("notes", [])
        if typeof(notes) != TYPE_ARRAY or notes.size() < 1 or notes.size() > 8:
            return false
        var alphabet = spec.get("alphabet", SData.NOTES)
        if typeof(alphabet) != TYPE_ARRAY or alphabet.is_empty():
            return false
        for a in alphabet:
            if not SData.NOTES.has(a):
                return false
        for n in notes:
            if not alphabet.has(n):
                return false
        return true
    if kind == "order":
        var g = spec.get("glyphs", [])
        if typeof(g) != TYPE_ARRAY or g.size() < 2 or g.size() > 4:
            return false
        var seen := {}
        for v in g:
            if typeof(v) != TYPE_INT or v < 0 or v >= g.size() or seen.has(v):
                return false
            seen[v] = true
        return true
    return false
