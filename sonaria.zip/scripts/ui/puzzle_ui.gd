class_name PuzzleUI
extends Control
## Puzzle interface for Repeat-the-Melody, Resonance Shrine and the final
## altar. Gives understandable feedback (green/red slots, counts), unlimited
## retries/listens, hints, and reacts live to Director "assist" events.

signal opened
signal closed

class SlotRow extends Control:
    var slots: Array = []        # {note, state, ghost}
    func setup(n: int) -> void:
        slots.clear()
        for i in n:
            slots.append({"note": "", "state": 0, "ghost": ""})
        custom_minimum_size = Vector2(n * 62.0 + 8.0, 76.0)
        queue_redraw()
    func _draw() -> void:
        for i in slots.size():
            var s: Dictionary = slots[i]
            var c := Vector2(36.0 + i * 62.0, 38.0)
            var col := Color(0.4, 0.4, 0.6)
            if s["ghost"] != "":
                var gc: Color = SData.NOTE_COLOR[s["ghost"]]
                draw_circle(c, 24.0, Color(gc.r, gc.g, gc.b, 0.16))
                draw_string(ThemeDB.fallback_font, c + Vector2(-10, 7), s["ghost"], HORIZONTAL_ALIGNMENT_CENTER, 20.0, 20, Color(gc.r, gc.g, gc.b, 0.5))
            if s["note"] != "":
                col = SData.NOTE_COLOR[s["note"]]
                Art.glow(self, c, 30.0, col, 0.6)
                draw_circle(c, 22.0, col.darkened(0.35))
                Art.crystal(self, c + Vector2(0, 11), 20.0, 9.0, col)
            draw_arc(c, 24.0, 0.0, TAU, 28, col, 2.5)
            match int(s["state"]):
                2:
                    draw_arc(c, 28.0, 0.0, TAU, 28, Color("5ee0a0"), 4.0)
                3:
                    draw_arc(c, 28.0, 0.0, TAU, 28, Color("ff5a7a"), 4.0)
                4:
                    draw_arc(c, 28.0, 0.0, TAU, 28, SData.GOLD, 3.0)

var req: Dictionary = {}
var target: Array = []
var alphabet: Array = []
var _entered: Array = []
var _busy := false
var _done := false
var _wrong_shown := false
var _assist_seen := 0
var _attempts := 0
var _panel: PanelContainer
var _title: Label
var _sub: Label
var _slots: SlotRow
var _clues: VBoxContainer
var _msg: Label
var _note_buttons: Dictionary = {}
var _gen := 0     # invalidates stale playback timers

func _init() -> void:
    theme = UITheme.get_theme()
    set_anchors_preset(Control.PRESET_FULL_RECT)
    visible = false
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.02, 0.08, 0.7)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    _panel = PanelContainer.new()
    center.add_child(_panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    _panel.add_child(v)
    _title = UITheme.label("", 26, SData.GOLD)
    _title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(_title)
    _sub = UITheme.wrap_label("", 620, 17)
    _sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(_sub)
    _clues = VBoxContainer.new()
    _clues.add_theme_constant_override("separation", 2)
    v.add_child(_clues)
    _slots = SlotRow.new()
    var sc := CenterContainer.new()
    sc.add_child(_slots)
    v.add_child(sc)
    var nb := HBoxContainer.new()
    nb.alignment = BoxContainer.ALIGNMENT_CENTER
    nb.add_theme_constant_override("separation", 12)
    nb.name = "NoteButtons"
    v.add_child(nb)
    _msg = UITheme.wrap_label("", 620, 17, Color(0.8, 0.8, 1.0))
    _msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _msg.custom_minimum_size.y = 48
    v.add_child(_msg)
    var ab := HBoxContainer.new()
    ab.alignment = BoxContainer.ALIGNMENT_CENTER
    ab.add_theme_constant_override("separation", 10)
    v.add_child(ab)
    for spec in [["Listen (L)", "listen"], ["Hint (H)", "hint"], ["Retry (R)", "retry"], ["Undo (Backspace)", "undo"], ["Close (Esc)", "close"]]:
        var b := UITheme.button(spec[0], Vector2(130, 38))
        b.pressed.connect(_on_action.bind(spec[1]))
        ab.add_child(b)

func open(request: Dictionary) -> void:
    req = request
    target = request["notes"].duplicate()
    alphabet = request.get("alphabet", SData.NOTES).duplicate()
    _entered.clear()
    _busy = false
    _done = false
    _wrong_shown = false
    _attempts = 0
    _gen += 1
    _assist_seen = int(GameState.assist.get(req["id"], 0))
    _title.text = req.get("title", "")
    _sub.text = req.get("subtitle", "")
    _slots.setup(target.size())
    _msg.text = "Sing the notes with keys 1-%d or click them." % alphabet.size()
    # note buttons
    var nb: HBoxContainer = _panel.find_child("NoteButtons", true, false)
    for c in nb.get_children():
        c.queue_free()
    _note_buttons.clear()
    for i in alphabet.size():
        var n: String = alphabet[i]
        var col: Color = SData.NOTE_COLOR[n]
        var b := Button.new()
        b.text = "%d   %s" % [i + 1, n]
        b.custom_minimum_size = Vector2(104, 62)
        b.add_theme_font_size_override("font_size", 22)
        b.add_theme_stylebox_override("normal", UITheme.box(col.darkened(0.7), col, 3, 10, 8))
        b.add_theme_stylebox_override("hover", UITheme.box(col.darkened(0.5), col.lightened(0.3), 3, 10, 8))
        b.add_theme_stylebox_override("pressed", UITheme.box(col.darkened(0.2), Color.WHITE, 3, 10, 8))
        b.add_theme_color_override("font_color", col.lightened(0.5))
        b.focus_mode = Control.FOCUS_NONE
        b.pressed.connect(_press_note.bind(n))
        nb.add_child(b)
        _note_buttons[n] = b
    # clue list (shrine)
    for c in _clues.get_children():
        c.queue_free()
    var clues: Array = req.get("clues", [])
    _clues.visible = not clues.is_empty()
    for cl in clues:
        var known: bool = cl["known"]
        var txt := "Verse %s:  %s" % [SData.ROMAN[cl["index"]], cl["note"]] if known else "Verse %s:  ?   (not yet read - look in %s)" % [SData.ROMAN[cl["index"]], cl["where"]]
        var l := UITheme.label(txt, 16, SData.NOTE_COLOR[cl["note"]].lightened(0.3) if known else Color(0.6, 0.6, 0.8))
        l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        _clues.add_child(l)
        if known:
            _slots.slots[cl["index"]]["ghost"] = cl["note"]
    visible = true
    opened.emit()
    if req.get("kind", "") != "shrine":
        _apply_assist(false)
        get_tree().create_timer(0.55, false).timeout.connect(_listen.bind(_gen))
    _slots.queue_redraw()

func _process(_d: float) -> void:
    if visible and not req.is_empty():
        var a := int(GameState.assist.get(req["id"], 0))
        if a > _assist_seen:
            _assist_seen = a
            _apply_assist(true)

func _apply_assist(announce: bool) -> void:
    var a := int(GameState.assist.get(req["id"], 0))
    if a <= 0 or req.get("kind", "") == "shrine":
        return
    for i in target.size():
        if i == 0 or a >= 2:
            _slots.slots[i]["ghost"] = target[i]
    _slots.queue_redraw()
    if announce:
        _msg.text = "A guide wisp helps: the melody is shown faintly and plays more slowly."
        _listen(_gen)

func _step_time() -> float:
    return 0.8 if int(GameState.assist.get(req.get("id", ""), 0)) > 0 else 0.55

func _listen(gen := -1) -> void:
    if (gen != -1 and gen != _gen) or not visible or _done:
        return
    if req.get("kind", "") == "shrine":
        if _all_known():
            _play_sequence(target)
        else:
            _msg.text = "You can only hear the verses you have read on the tablets."
            var known: Array = []
            for cl in req["clues"]:
                if cl["known"]:
                    known.append(cl["note"])
            _play_sequence(known)
        return
    _play_sequence(target)

func _all_known() -> bool:
    for cl in req.get("clues", []):
        if not cl["known"]:
            return false
    return true

func _play_sequence(notes: Array) -> void:
    _gen += 1
    var my := _gen
    _busy = true
    var step := _step_time()
    for i in notes.size():
        get_tree().create_timer(step * i, false).timeout.connect(func():
            if my != _gen:
                return
            AudioManager.play_note(notes[i], "bell", -3.0)
            _flash(notes[i]))
    get_tree().create_timer(step * notes.size() + 0.1, false).timeout.connect(func():
        if my == _gen:
            _busy = false)

func _flash(n: String) -> void:
    var b: Button = _note_buttons.get(n, null)
    if b == null:
        return
    b.modulate = Color(2.0, 2.0, 2.0)
    get_tree().create_timer(0.3, false).timeout.connect(func():
        if is_instance_valid(b):
            b.modulate = Color.WHITE)

func _press_note(n: String) -> void:
    if _done or not visible:
        return
    if _wrong_shown:
        _clear()
    if _entered.size() >= target.size():
        return
    _gen += 1
    _busy = false
    _entered.append(n)
    AudioManager.play_note(n, "bell", -3.0)
    _flash(n)
    _slots.slots[_entered.size() - 1]["note"] = n
    _slots.slots[_entered.size() - 1]["state"] = 0
    _slots.queue_redraw()
    if _entered.size() == target.size():
        _check()

func _clear() -> void:
    _entered.clear()
    _wrong_shown = false
    for s in _slots.slots:
        s["note"] = ""
        s["state"] = 0
    _slots.queue_redraw()

func _check() -> void:
    var right := 0
    for i in target.size():
        var ok: bool = _entered[i] == target[i]
        _slots.slots[i]["state"] = 2 if ok else 3
        if ok:
            right += 1
    _slots.queue_redraw()
    if right == target.size():
        _done = true
        AudioManager.play_sfx("success")
        _msg.text = "Yes! The melody rings true."
        get_tree().create_timer(1.4, false).timeout.connect(_finish_success)
    else:
        _attempts += 1
        _wrong_shown = true
        AudioManager.play_sfx("wrong")
        GameState.record_failure(req["id"])
        var extra := " Press L to hear it again" if req.get("kind", "") != "shrine" else " Re-read the tablets for the missing verses"
        _msg.text = "%d of %d notes were right (green). The red ones are wrong.%s, H for a hint, or just start again." % [right, target.size(), extra]
        var tw := create_tween()
        for dx in [10, -10, 6, -6, 0]:
            tw.tween_property(_panel, "position:x", _panel.position.x + dx, 0.04)

func _finish_success() -> void:
    visible = false
    var cb: Callable = req.get("on_success", Callable())
    closed.emit()
    if cb.is_valid():
        cb.call()

func close_cancel() -> void:
    _gen += 1
    visible = false
    closed.emit()

func _hint() -> void:
    if _done:
        return
    if req.get("kind", "") == "shrine":
        for cl in req["clues"]:
            if not cl["known"]:
                _msg.text = "Hint: Verse %s is carved in %s." % [SData.ROMAN[cl["index"]], cl["where"]]
                GameState.hints_used += 1
                return
    if _wrong_shown:
        _clear()
    if _entered.size() >= target.size():
        return
    var i := _entered.size()
    GameState.hints_used += 1
    _entered.append(target[i])
    _slots.slots[i]["note"] = target[i]
    _slots.slots[i]["state"] = 4
    AudioManager.play_note(target[i], "bell", -3.0)
    _flash(target[i])
    _msg.text = "Hint: the next note is %s." % target[i]
    _slots.queue_redraw()
    if _entered.size() == target.size():
        _check()

func _on_action(a: String) -> void:
    match a:
        "listen": _listen()
        "hint": _hint()
        "retry":
            _clear()
            _msg.text = "Fresh start. Listen again with L if you need to."
        "undo":
            if _wrong_shown:
                _clear()
            elif _entered.size() > 0:
                _entered.pop_back()
                _slots.slots[_entered.size()]["note"] = ""
                _slots.slots[_entered.size()]["state"] = 0
                _slots.queue_redraw()
        "close": close_cancel()

func _input(event: InputEvent) -> void:
    if not visible or not (event is InputEventKey) or not event.pressed or event.echo:
        return
    var handled := true
    match event.keycode:
        KEY_ESCAPE: close_cancel()
        KEY_L: _on_action("listen")
        KEY_H: _on_action("hint")
        KEY_R: _on_action("retry")
        KEY_BACKSPACE: _on_action("undo")
        KEY_1, KEY_2, KEY_3, KEY_4, KEY_5:
            var idx: int = event.keycode - KEY_1
            if idx < alphabet.size():
                _press_note(alphabet[idx])
        _:
            handled = false
    if handled:
        get_viewport().set_input_as_handled()

## Test helper: enter a whole sequence as if typed.
func debug_enter(notes: Array) -> void:
    for n in notes:
        _press_note(n)
