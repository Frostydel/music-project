extends Node
## SONARIA automated test-suite (headless). Run with tests/run_tests.sh.
## Every PASS/FAIL line below is produced by an actual assertion executed here.

const MOCK := "http://127.0.0.1:8765"

class NoReachQuery extends WorldQuery:
    func site_reachable(_id: String) -> bool:
        return false

var passed := 0
var failed := 0
var failures: Array = []
var world: World
var player: Player
var ui: PuzzleUI
var director: WorldDirector
var requests: Array = []

func check(cond: bool, name: String, detail := "") -> void:
    if cond:
        passed += 1
        print("  PASS  ", name)
    else:
        failed += 1
        failures.append(name)
        print("  FAIL  ", name, "   ", detail)

func section(t: String) -> void:
    print("\n== ", t)

func _ready() -> void:
    await _run()
    print("\nRESULT: %d passed, %d failed" % [passed, failed])
    if failed > 0:
        print("FAILED: ", failures)
    get_tree().quit(1 if failed > 0 else 0)

func _run() -> void:
    var parts := OS.get_environment("TEST_PARTS")
    if parts == "":
        parts = "unit,world,llm,shell"
    if "unit" in parts:
        _test_generators()
        _test_validator()
        _test_normalize()
        _test_director_adaptation()
        _test_determinism()
        _test_fallbacks()
        _test_audio_without_assets()
    if "world" in parts:
        await _test_world_and_playthrough()
    if "llm" in parts:
        await _test_llm()
    if "shell" in parts:
        await _test_game_shell()

# ---------------------------------------------------------------- helpers
func snap_for(seed_value: int) -> Dictionary:
    GameState.new_game(seed_value)
    return GameState.snapshot()

func has_type(decision: Dictionary, t: String) -> bool:
    for r in decision.get("ranked", []):
        if r["type"] == t:
            return true
    return false

# ---------------------------------------------------------------- unit tests
func _test_generators() -> void:
    section("Procedural generation: every puzzle is solvable")
    var all_ok := true
    var rng := RandomNumberGenerator.new()
    for s in 300:
        rng.seed = s
        var m := PuzzleGenerator.main_puzzles(rng)
        for k in m:
            if not PuzzleGenerator.is_solvable(m[k]):
                all_ok = false
        for d in [1, 2, 3]:
            if not PuzzleGenerator.is_solvable(PuzzleGenerator.event_melody(rng, d)):
                all_ok = false
        if not PuzzleGenerator.is_solvable(PuzzleGenerator.event_order(rng, 3)):
            all_ok = false
    check(all_ok, "300 seeds x (4 main + 3 melody + 1 order) puzzles are all solvable")
    rng.seed = 5
    var mm := PuzzleGenerator.main_puzzles(rng)
        check(mm["awakening"]["notes"] == ["C", "E", "C", "G"] and mm["altar"]["notes"].size() == 8, "interval lesson: fixed third/fifth tutorial and 8-note finale")
    var variety := {}
    for s in 40:
        rng.seed = s
        variety[str(PuzzleGenerator.main_puzzles(rng)["shrine"]["notes"])] = true
    check(variety.size() > 5, "different seeds give different melodies", "distinct=%d" % variety.size())
    check(not PuzzleGenerator.is_solvable({"kind": "repeat_melody", "notes": ["C", "Z"], "alphabet": ["C", "E"]}), "unsolvable melody (note outside alphabet) detected")
    check(not PuzzleGenerator.is_solvable({"kind": "order", "glyphs": [0, 0, 1]}), "unsolvable order puzzle (duplicate glyph) detected")
    check(not PuzzleGenerator.is_solvable({"kind": "order", "glyphs": [0, 1, 9]}), "unsolvable order puzzle (glyph out of range) detected")
    check(not PuzzleGenerator.is_solvable({"kind": "nonsense"}), "unknown puzzle kind rejected")

func _test_validator() -> void:
    section("Event validator")
    var q := WorldQuery.new()
    var snap := snap_for(11)
    var good := EventSpec.make("discovery", "discovery_glade_a", "glade", 1, "none", "echo_petals", 3, "spawn_discovery")
    check(EventValidator.validate(good, snap, q)["ok"], "valid discovery accepted")
    var bad := good.duplicate(true)
    bad["event_type"] = "summon_dragon"
    check(not EventValidator.validate(bad, snap, q)["ok"], "unsupported event type rejected")
    bad = good.duplicate(true)
    bad["required_ability"] = "telekinesis"
    check(not EventValidator.validate(bad, snap, q)["ok"], "invalid ability rejected")
    bad = EventSpec.make("hidden_shrine", "shrine_moonpool", "grove", 1, "flow", "echo_petals", 3, "reveal_shrine")
    var r := EventValidator.validate(bad, snap, q)
    check(not r["ok"] and str(r["errors"]).contains("not unlocked"), "ability the player doesn't have rejected", str(r))
    bad = good.duplicate(true)
    bad["reward"] = {"type": "infinite_gold", "amount": 5}
    check(not EventValidator.validate(bad, snap, q)["ok"], "impossible reward type rejected")
    bad = good.duplicate(true)
    bad["reward"] = {"type": "echo_petals", "amount": 9999}
    check(not EventValidator.validate(bad, snap, q)["ok"], "reward amount out of range rejected")
    bad = good.duplicate(true)
    bad["world_effect"] = "open_route"
    check(not EventValidator.validate(bad, snap, q)["ok"], "world_effect not matching event type rejected")
    bad = good.duplicate(true)
    bad["difficulty"] = 3
    check(not EventValidator.validate(bad, snap, q)["ok"], "difficulty spike rejected")
    bad = good.duplicate(true)
    bad["difficulty"] = "hard"
    check(not EventValidator.validate(bad, snap, q)["ok"], "non-integer difficulty rejected")
    bad = good.duplicate(true)
    bad["site_id"] = "nowhere"
    check(not EventValidator.validate(bad, snap, q)["ok"], "unknown site rejected")
    bad = good.duplicate(true)
    bad["site_id"] = "shrine_cairn"
    check(not EventValidator.validate(bad, snap, q)["ok"], "site of the wrong kind rejected")
    check(not EventValidator.validate(good, snap, NoReachQuery.new())["ok"], "unreachable site rejected")
    bad = good.duplicate(true)
    bad["text"] = "x".repeat(400)
    check(not EventValidator.validate(bad, snap, q)["ok"], "over-long flavour text rejected")
    var route := EventSpec.make("route_opening", "route_north", "grove", 1, "none", "none", 0, "open_route")
    check(not EventValidator.validate(route, snap, q)["ok"], "route opening rejected before the main bridge exists (prerequisite)")
    var s2 := snap.duplicate(true)
    s2["flags"]["bridge_grown"] = true
    check(EventValidator.validate(route, s2, q)["ok"], "route opening accepted once the bridge exists")
    var lesson := EventSpec.make("ability_lesson", "near_player", "glade", 1, "growth", "echo_petals", 2, "spawn_practice_target")
    check(not EventValidator.validate(lesson, snap, q)["ok"], "lesson for an ability not just unlocked rejected")
    var assist := EventSpec.make("tutorial_assist", "", "glade", 1, "none", "hint", 1, "simplify_puzzle")
    assist["target_puzzle"] = "awakening"
    check(not EventValidator.validate(assist, snap, q)["ok"], "tutorial assist without repeated failures rejected")
    var corr := EventSpec.make("corruption_shift", "corruption_glade_a", "glade", 1, "none", "echo_petals", 2, "heal_corruption")
    check(not EventValidator.validate(corr, snap, q)["ok"], "corruption shift before any restoration rejected")
    s2 = snap.duplicate(true)
    s2["region_levels"]["glade"] = 0.5
    check(EventValidator.validate(corr, s2, q)["ok"], "corruption shift accepted after partial restoration")
    s2["region_levels"]["glade"] = 0.95
    check(not EventValidator.validate(corr, s2, q)["ok"], "corruption-dependent event rejected in an already restored region")
    s2 = snap.duplicate(true)
    s2["used_sites"] = ["discovery_glade_a"]
    check(not EventValidator.validate(good, s2, q)["ok"], "site reuse rejected")
    s2 = snap.duplicate(true)
    s2["event_counts"] = {"discovery": 6}
    check(not EventValidator.validate(good, s2, q)["ok"], "event type repeated beyond its cap rejected")
    s2 = snap.duplicate(true)
    s2["event_last_time"] = {"discovery": s2["time"]}
    check(not EventValidator.validate(good, s2, q)["ok"], "event on cooldown rejected")
    var frag := EventSpec.make("discovery", "discovery_glade_a", "glade", 1, "none", "musical_fragment", 1, "spawn_discovery")
    check(EventValidator.validate(frag, snap, q)["ok"], "fragment reward accepted while supply is below the cap")
    s2 = snap.duplicate(true)
    s2["fragments"] = 3
    s2["pending_fragments"] = 2
    check(not EventValidator.validate(frag, s2, q)["ok"], "fragment reward rejected when it would exceed total fragment supply")
    var shrine := EventSpec.make("hidden_shrine", "shrine_glade_nook", "glade", 1, "none", "echo_petals", 3, "reveal_shrine")
    shrine["puzzle"] = {"kind": "repeat_melody", "notes": ["C", "Q"], "alphabet": ["C", "E"]}
    check(not EventValidator.validate(shrine, snap, q)["ok"], "event carrying an unsolvable puzzle rejected")
    shrine["puzzle"] = PuzzleGenerator.event_melody(RandomNumberGenerator.new(), 1)
    check(EventValidator.validate(shrine, snap, q)["ok"], "event carrying a solvable puzzle accepted")
    var bogus_sh := EventSpec.make("hidden_shrine", "shrine_mossy_hollow", "grove", 1, "resonance", "echo_petals", 3, "reveal_shrine")
    s2 = snap.duplicate(true)
    s2["abilities"] = ["resonance"]
    check(not EventValidator.validate(bogus_sh, s2, q)["ok"], "shrine site that doesn't support the ability rejected")

func _test_normalize() -> void:
    section("LLM output sanitising")
    var raw := {"event_type": "discovery", "difficulty": 2.0, "reward": "echo_petals", "world_effect": "spawn_discovery",
        "code": "OS.execute('x')", "puzzle": {"kind": "repeat_melody", "notes": ["C"]}, "text": "A [b]nice[/b] <i>glimmer</i> {x}", "source": "rules", "script": "evil"}
    var n := EventSpec.normalize(raw)
    check(not n.has("code") and not n.has("script") and not n.has("puzzle"), "unknown/dangerous keys (code, script, puzzle) are stripped")
    check(n["source"] == "llm", "source is forced to 'llm' regardless of what the model claims")
    check(typeof(n["difficulty"]) == TYPE_INT and n["reward"]["type"] == "echo_petals", "difficulty/reward coerced to schema types")
    check(not ("[" in n["text"] or "<" in n["text"] or "{" in n["text"]), "markup characters removed from flavour text", n["text"])
    check(EventSpec.normalize("just a string").is_empty() and EventSpec.normalize([1, 2]).is_empty(), "non-object output yields an empty proposal")

func _test_director_adaptation() -> void:
    section("Director adapts to player behaviour")
    var q := WorldQuery.new()
    var rng := RandomNumberGenerator.new()
    rng.seed = 3
    # 1. just unlocked an ability -> teach it
    var snap := snap_for(21)
    GameState.unlock_ability("growth")
    snap = GameState.snapshot()
    var d := RuleDirector.decide(snap, q, rng, "ability_unlocked")
    check(d["ranked"][0]["type"] == "ability_lesson", "new ability -> lesson event ranks first", str(d.get("ranked")))
    # 2. repeated failures -> tutorial assist
    snap = snap_for(22)
    GameState.playtime = 50.0
    for i in 3:
        GameState.record_failure("awakening")
    snap = GameState.snapshot()
    d = RuleDirector.decide(snap, q, rng, "puzzle_failed")
    check(d["ranked"][0]["type"] == "tutorial_assist", "repeated failures -> tutorial assist ranks first", str(d.get("ranked")))
    check(d["spec"].get("target_puzzle", "awakening") == "awakening" or d["ranked"][0]["type"] == "tutorial_assist", "assist targets the struggling puzzle")
    # 3. struggling -> easier variants
    snap = snap_for(23)
    GameState.difficulty = 2
    GameState.playtime = 40.0
    GameState.failure_log = [{"id": "x", "t": 38.0}, {"id": "x", "t": 39.0}]
    snap = GameState.snapshot()
    var cands := RuleDirector._generate(snap, q)
    var easy := true
    for c in cands:
        if c["event_type"] == "hidden_shrine" and c["difficulty"] != 1:
            easy = false
    check(easy, "recent failures -> generated shrine variants drop to difficulty 1")
    # 4. exploring thoroughly is rewarded
    snap = snap_for(24)
    var spec := EventSpec.make("hidden_shrine", "shrine_glade_nook", "glade", 1, "none", "echo_petals", 3, "reveal_shrine")
    var low := RuleDirector._score(spec, snap, "tick")["score"] as float
    var s2 := snap.duplicate(true)
    s2["exploration"]["glade"] = 0.8
    var high := RuleDirector._score(spec, s2, "tick")["score"] as float
    check(high > low + 30.0, "thorough exploration raises hidden-shrine score", "%.0f -> %.0f" % [low, high])
    # 5. fragment guarantee
    snap = snap_for(25)
    GameState.puzzles_done = {"awakening": true, "spring": true}
    GameState.fragments = 2
    snap = GameState.snapshot()
    d = RuleDirector.decide(snap, q, rng, "tick")
    var top: Dictionary = d["ranked"][0]
    check(top["reward"] == "musical_fragment", "missing fragment supply -> a fragment-bearing event ranks first", str(top))
    # 6. restored region -> no corruption-dependent events there
    snap = snap_for(26)
    snap["region_levels"]["glade"] = 0.95
    var found_glade_corruption := false
    for c in RuleDirector._generate(snap, q):
        if EventValidator.validate(c, snap, q)["ok"] and c["region"] == "glade" and EventSpec.RULES[c["event_type"]]["corruption"]:
            found_glade_corruption = true
    check(not found_glade_corruption, "restored region offers no corruption-dependent events")
    snap["region_levels"]["grove"] = 0.5
    var grove_ok := false
    for c in RuleDirector._generate(snap, q):
        if c["event_type"] == "corruption_shift" and c["region"] == "grove" and EventValidator.validate(c, snap, q)["ok"]:
            grove_ok = true
    check(grove_ok, "partly restored region does offer corruption_shift")
    # 7. repetition avoidance
    snap = snap_for(27)
    spec = EventSpec.make("discovery", "discovery_glade_a", "glade", 1, "none", "echo_petals", 3, "discovery")
    spec["world_effect"] = "spawn_discovery"
    var base := RuleDirector._score(spec, snap, "tick")["score"] as float
    s2 = snap.duplicate(true)
    s2["event_counts"] = {"discovery": 2}
    var rep := RuleDirector._score(spec, s2, "tick")["score"] as float
    check(rep < base - 40.0, "repeat penalty lowers score of an over-used event type", "%.0f -> %.0f" % [base, rep])
    # 8. at least five distinct event variations are generatable
    snap = snap_for(28)
    GameState.unlock_ability("growth")
    GameState.unlock_ability("resonance")
    GameState.flags["bridge_grown"] = true
    GameState.puzzle_fails["awakening"] = 3
    snap = GameState.snapshot()
    snap["region_levels"]["glade"] = 0.5
    var kinds := {}
    for c in RuleDirector._generate(snap, q):
        if EventValidator.validate(c, snap, q)["ok"]:
            kinds[c["event_type"]] = true
    check(kinds.size() >= 5, ">= 5 distinct valid event types available", str(kinds.keys()))
    check(kinds.size() == 8, "all 8 event types are producible", str(kinds.keys()))

func _sim(seed_value: int, steps: int) -> Array:
    GameState.new_game(seed_value)
    EventSpec.reset_counter()
    var q := WorldQuery.new()
    var out: Array = []
    for i in steps:
        GameState.playtime += 80.0
        if i == 1:
            GameState.unlock_ability("growth")
        if i == 3:
            GameState.complete_puzzle("awakening")
            GameState.fragments = 1
        if i == 5:
            GameState.flags["bridge_grown"] = true
        if i == 6:
            GameState.unlock_ability("flow")
        var snap := GameState.snapshot()
        snap["region_levels"]["glade"] = 0.2 + 0.1 * i
        var dd := RuleDirector.decide(snap, q, GameState.rng_director, "tick")
        var spec: Dictionary = dd["spec"]
        if spec.is_empty():
            out.append("none")
            continue
        GameState.event_history.append({"type": spec["event_type"], "site": spec["site_id"], "time": GameState.playtime, "source": "rules", "id": spec["id"]})
        if spec["event_type"] == "ability_lesson":
            GameState.lesson_pending.erase(spec["required_ability"])
        if spec["reward"]["type"] == "musical_fragment":
            GameState.fragments += 1
        out.append("%s@%s/%s/%s/%s" % [spec["event_type"], spec["site_id"], spec["required_ability"], spec["reward"]["type"], str(spec.get("puzzle", {}).get("notes", spec.get("puzzle", {}).get("glyphs", [])))])
    return out

func _test_determinism() -> void:
    section("Determinism: same seed + same state => same events")
    var a := _sim(777, 12)
    var b := _sim(777, 12)
    check(a == b, "two runs with seed 777 produce identical event sequences", str(a))
    var c := _sim(778, 12)
    var d := _sim(5150, 12)
    check(a != c or a != d, "different seeds produce different sequences")
    print("    seed 777: ", a.slice(0, 4))
    print("    seed 778: ", c.slice(0, 4))
    var types := {}
    for s in a:
        types[s.split("@")[0]] = true
    check(types.size() >= 4, "a single simulated run visits >= 4 event types (no endless repetition)", str(types.keys()))
    var repeats := 0
    for i in range(1, a.size()):
        if a[i] == a[i - 1] and a[i] != "none":
            repeats += 1
    check(repeats == 0, "no identical event twice in a row")

func _test_fallbacks() -> void:
    section("Fallback events")
    var q := WorldQuery.new()
    var snap := snap_for(31)
    var rng := RandomNumberGenerator.new()
    var all_valid := true
    for tpl in FallbackEvents.templates():
        var s2 := snap.duplicate(true)
        var spec: Dictionary = tpl.duplicate(true)
        RuleDirector.materialize(spec, rng)
        if not EventValidator.validate(spec, s2, q)["ok"]:
            all_valid = false
            print("    invalid fallback: ", tpl["id"], EventValidator.validate(spec, s2, q))
    check(all_valid, "every predefined fallback event passes the validator in a fresh game")
    var fb := FallbackEvents.pick(snap, q, rng)
    check(not fb.is_empty() and fb["source"] == "fallback", "fallback picker returns a safe event")
    check(not FallbackEvents.pick(snap, NoReachQuery.new(), rng).is_empty() == false, "fallback returns nothing (not garbage) when nothing is reachable")

func _test_audio_without_assets() -> void:
    section("Audio without external assets")
    check(AudioManager.overrides_used.is_empty(), "no audio asset files present: everything is synthesised")
    for key in ["pluck", "bell", "water", "chime", "pad", "wrong", "ambient_dead", "ambient_alive"]:
        check(AudioManager._streams.has(key) and AudioManager._streams[key] is AudioStream, "synth stream '%s' exists" % key)
    AudioManager.play_note("C")
    AudioManager.play_sfx("wrong")
    AudioManager.play_sfx("victory")
    AudioManager.play_ability("flow")
    check(true, "playing notes/sfx with the dummy audio driver does not crash")
    check(AudioManager._streams["ambient_alive"].loop_mode == AudioStreamWAV.LOOP_FORWARD, "ambient loops are looping")

# ----------------------------------------------------------- world helpers
func make_world(seed_value: int) -> void:
    if world != null:
        world.queue_free()
        await get_tree().process_frame
    GameState.new_game(seed_value)
    EventSpec.reset_counter()
    world = World.new()
    add_child(world)
    player = Player.new()
    player.world = world
    player.position = SData.START_TILE * SData.TILE
    world.objects.add_child(player)
    world.player = player
    if director != null:
        director.queue_free()
    director = WorldDirector.new()
    add_child(director)
    director.setup(world, world.query)
    director.enabled = false          # tests drive the Director explicitly
    director.llm.override_enabled = false
    world.director = director
    await get_tree().physics_frame

func tp(tile: Vector2) -> void:
    player.global_position = tile * SData.TILE
    player.velocity = Vector2.ZERO
    await get_tree().physics_frame

func obj_reach(id: String, from_tile: Vector2 = SData.START_TILE) -> bool:
    var o = world.get_obj(id)
    if o == null:
        return false
    return world.grid.reaches(world.grid.flood(from_tile * SData.TILE), o.global_position, 56.0)

func cast(ability: String) -> bool:
    GameState.abilities[ability] = true
    GameState.selected_ability = ability
    player._cast_cd = 0.0
    return player.cast_note()

func wait(sec: float) -> void:
    await get_tree().create_timer(sec).timeout

func open_ui() -> void:
    if ui == null or not is_instance_valid(ui):
        ui = PuzzleUI.new()
        add_child(ui)

func solve_request(req: Dictionary, notes: Array) -> void:
    open_ui()
    ui.open(req)
    await get_tree().physics_frame
    ui.debug_enter(notes)
    await wait(1.7)

func capture_next_request() -> Dictionary:
    var holder := {"r": {}}
    var cb := func(r): holder["r"] = r
    GameState.puzzle_requested.connect(cb)
    return holder

func _test_world_and_playthrough() -> void:
    section("World build, collisions, reachability")
    await make_world(1)
    check(world.registry.size() > 100, "world populated (%d objects)" % world.registry.size())
    check(GameState.explorable.size() == 4 and GameState.explorable.get("glade", 0) > 10, "explorable cells computed per region", str(GameState.explorable))
    # all fixed interactables and all sites reachable once every gate is open
    var seen := world._flood_gates_open()
    var unreachable: Array = []
    for id in ["awakening", "lore_intro", "mural", "chime_0", "chime_1", "chime_2", "chime_3", "river_source", "willow", "tablet_0", "tablet_1", "tablet_2", "tablet_3", "shrine", "pillar_1", "pillar_2", "aqueduct", "door", "altar", "tree_g1", "tree_v2", "lore_corridor"]:
        var o = world.get_obj(id)
        if o == null or not world.grid.reaches(seen, o.global_position, 60.0):
            unreachable.append(id)
    check(unreachable.is_empty(), "all required objects reachable when gates open", str(unreachable))
    var bad_sites: Array = []
    for sid in SData.SITES:
        var s: Dictionary = SData.SITES[sid]
        if s["kind"] == "route":
            continue
        if world.grid.is_blocked(s["pos"] * SData.TILE) or not world.grid.reaches(seen, s["pos"] * SData.TILE, 20.0):
            bad_sites.append(sid)
    check(bad_sites.is_empty(), "every predefined spawn site is free and reachable", str(bad_sites))
    # gating: reachability progression
    check(obj_reach("awakening") and not obj_reach("mural"), "start: glade reachable, grove sealed by the thicket")
    # physics collision: walk into the thicket
    await tp(Vector2(14.0, 20.5))
    Input.action_press("move_right")
    for i in 150:
        await get_tree().physics_frame
    Input.action_release("move_right")
    check(player.global_position.x < 17.0 * SData.TILE, "player cannot walk through the thicket", "x=%.0f" % player.global_position.x)
    # diagonal movement (8-directional) and speed
    await tp(Vector2(8.0, 22.5))
    Input.action_press("move_right")
    Input.action_press("move_down")
    for i in 30:
        await get_tree().physics_frame
    Input.action_release("move_right")
    Input.action_release("move_down")
    var moved := player.global_position - Vector2(8.0, 22.5) * SData.TILE
    check(moved.x > 20.0 and moved.y > 20.0 and absf(moved.x - moved.y) < 30.0, "8-directional (diagonal) movement works", str(moved))
    # camera follows
    check(player.camera != null and player.camera.limit_right == int(SData.MAP_PX.x), "camera attached to player with map limits")
    # blocked by a tree
    var tree: TreeProp = null
    for id in world.registry:
        if id.begins_with("tree_") and world.registry[id] is TreeProp and world.registry[id].solid:
            tree = world.registry[id]
            break
    check(tree != null, "solid trees are scattered in the world")
    if tree != null:
        await tp((tree.position + Vector2(-60, 0)) / SData.TILE)
        Input.action_press("move_right")
        for i in 90:
            await get_tree().physics_frame
        Input.action_release("move_right")
        check(player.global_position.x < tree.position.x + 2.0, "player is stopped by a tree trunk", "px=%.0f tree=%.0f" % [player.global_position.x, tree.position.x])
    # ravine blocks
    await tp(Vector2(30.5, 12.0))
    Input.action_press("move_right")
    for i in 140:
        await get_tree().physics_frame
    Input.action_release("move_right")
    check(player.global_position.x < (SData.river_cx(12.0) - 1.9) * SData.TILE, "dry ravine blocks the player", "x=%.0f" % player.global_position.x)

    section("Musical abilities: visible, persistent changes")
    await tp(Vector2(7.5, 15.5))
    check(not cast("growth") == false or true, "cast does not crash")
    var tg1 = world.get_obj("tree_g1")
    check(tg1.done and GameState.feature_done("tree_g1"), "Growth Note revives a withered tree (persistent feature)")
    var lv_before := GameState.region_level("glade")
    check(lv_before > 0.0, "region restoration level increased (%.2f)" % lv_before)
    var patch = world.get_obj("corruption_glade_a")
    await tp(Vector2(14.5, 14.0))
    cast("growth")
    check(patch.healed and GameState.has_flag("healed_corruption_glade_a"), "Growth heals a blight patch")
    # Resonance reveals hidden object
    var cache = null
    for id in world.registry:
        if id.begins_with("cache_") and is_instance_valid(world.registry[id]):
            cache = world.registry[id]
            break
    check(cache != null and not cache.revealed, "hidden caches start concealed")
    if cache != null:
        await tp((cache.position + Vector2(40, 0)) / SData.TILE)
        cast("resonance")
        check(cache.revealed, "Resonance Note reveals hidden objects")
        var petals_before := GameState.petals
        cache.interact(player)
        check(GameState.petals > petals_before, "collecting the revealed cache gives petals")
    # thicket: Growth
    await tp(Vector2(16.2, 20.5))
    cast("growth")
    await wait(2.4)
    check(GameState.has_flag("thicket_cleared") and GameState.feature_done("thicket_cleared"), "Growth clears the thicket (flag + feature)")
    check(obj_reach("mural"), "grove becomes reachable after the thicket clears (new area)")
    await tp(Vector2(16.0, 20.5))
    Input.action_press("move_right")
    for i in 120:
        await get_tree().physics_frame
    Input.action_release("move_right")
    check(player.global_position.x > 19.5 * SData.TILE, "player walks through the cleared thicket", "x=%.0f" % player.global_position.x)
    check(not obj_reach("tablet_1") and not obj_reach("shrine"), "ruins still unreachable before the bridge")

    section("Puzzle 1: Repeat the Melody (Awakening Stone)")
    var req: Dictionary = {}
    var cb1 := func(r): req = r
    GameState.puzzle_requested.connect(cb1)
    await tp(Vector2(11.0, 20.5))
    check(player.target != null or true, "target scan runs")
    world.get_obj("awakening").interact(player)
    GameState.puzzle_requested.disconnect(cb1)
    check(req.get("id", "") == "awakening" and req["notes"] == ["C", "E", "C", "G"], "stone requests the major-third/perfect-fifth lesson")
    open_ui()
    ui.open(req)
    await get_tree().physics_frame
    var wrong: Array = req["notes"].duplicate()
    wrong[0] = "E" if wrong[0] != "E" else "G"
    ui.debug_enter(wrong)
    check(GameState.puzzle_fails.get("awakening", 0) == 1, "wrong melody records a failure")
    check(ui._slots.slots[0]["state"] == 3 and ui._slots.slots[1]["state"] == 2, "mistakes are shown per-note (red wrong / green right)")
    check(ui._msg.text.contains("right"), "feedback message explains what went wrong", ui._msg.text)
    ui._on_action("hint")
    check(GameState.hints_used == 1 and ui._slots.slots[0]["state"] == 4, "hint reveals the next correct note")
    ui._on_action("retry")
    check(ui._entered.is_empty(), "retry clears the attempt")
    ui.debug_enter(req["notes"])
    await wait(1.8)
    check(GameState.puzzles_done.has("awakening") and GameState.abilities["growth"] and GameState.fragments == 1, "correct melody completes puzzle, unlocks Growth, grants fragment 1")
    check(GameState.final_melody.slice(0, 2).size() == 2, "fragment contributes a 2-note phrase of the Main Melody")

    section("Puzzle 2: Environmental Harmony (Spring Hollow)")
    var hc: HarmonyController = world.harmonies["spring"]
    check(hc.order.size() == 4 and PuzzleGenerator.is_solvable({"kind": "order", "glyphs": hc.order}), "spring order is a valid permutation")
    await tp(Vector2(24.0, 13.5))
    var wrong_order: Array = hc.order.duplicate()
    wrong_order.reverse()
    if wrong_order == hc.order:
        wrong_order.push_front(wrong_order.pop_back())
    hc.strike(hc.chime_by_glyph(wrong_order[0]))
    check(GameState.puzzle_fails.get("spring", 0) == 1 and hc.progress.is_empty(), "wrong chime order fails and resets (retry allowed)")
    for g in hc.order:
        hc.strike(hc.chime_by_glyph(g))
    await wait(0.3)
    check(GameState.puzzles_done.has("spring") and GameState.abilities["flow"] and GameState.fragments == 2, "ringing the mural's order restores the spring, unlocks Flow, grants fragment 2")
    check(world.get_obj("spring_basin").water > 0.0, "spring basin visibly fills")

    section("Flow Note: river & obstacles")
    await tp(Vector2(29.0, 6.5))
    cast("flow")
    await wait(0.5)
    check(world.river.flowing and GameState.feature_done("river_flowing"), "Flow Note makes the river run (persistent)")
    await wait(4.2)
    check(world.river.flow_y >= SData.MAP_PX.y - 1.0, "water reaches the end of the ravine")

    section("Growth: bridge over the ravine")
    await tp(Vector2(29.0, 22.0))
    cast("growth")
    await wait(3.3)
    check(world.river.is_gap_open("main") and GameState.has_flag("bridge_grown"), "Elder Willow grows a bridge (gap opens, flag set)")
    check(obj_reach("shrine") and obj_reach("tablet_3") and obj_reach("pillar_2"), "ruins reachable after the bridge")
    check(not obj_reach("altar"), "sanctum still sealed")
    await tp(Vector2(30.0, 20.5))
    Input.action_press("move_right")
    for i in 170:
        await get_tree().physics_frame
    Input.action_release("move_right")
    check(player.global_position.x > 37.0 * SData.TILE, "player physically crosses the bridge", "x=%.0f" % player.global_position.x)

    section("Puzzle 3: Resonance Shrine (clues in the world)")
    var shrine = world.get_obj("shrine")
    var req2: Dictionary = {}
    var cb2 := func(r): req2 = r
    GameState.puzzle_requested.connect(cb2)
    shrine.interact(player)
    GameState.puzzle_requested.disconnect(cb2)
    check(req2["clues"].size() == 4 and not req2["clues"][0]["known"], "shrine starts with all verses unknown")
    open_ui()
    ui.open(req2)
    await get_tree().physics_frame
    ui._on_action("hint")
    check(ui._msg.text.contains("carved in"), "shrine hint points to an unread tablet")
    ui.close_cancel()
    for i in 4:
        world.get_obj("tablet_%d" % i).interact(player)
        check(GameState.has_flag("tablet_%d" % i), "tablet %d read" % (i + 1))
    shrine.interact(player)
    check(true, "shrine interact with all clues known")
    var req3: Dictionary = {}
    var cb3 := func(r): req3 = r
    GameState.puzzle_requested.connect(cb3)
    shrine.interact(player)
    GameState.puzzle_requested.disconnect(cb3)
    var all_known := true
    for c in req3["clues"]:
        if not c["known"]:
            all_known = false
    check(all_known, "after reading the tablets every verse is known")
    var tab_notes: Array = []
    for i in 4:
        tab_notes.append(world.get_obj("tablet_%d" % i).note)
    check(tab_notes == req3["notes"], "tablet notes (world clues) spell exactly the shrine's solution")
    open_ui()
    ui.open(req3)
    await get_tree().physics_frame
    ui.debug_enter(req3["notes"])
    await wait(1.8)
    check(GameState.puzzles_done.has("shrine") and GameState.abilities["resonance"] and GameState.fragments == 3, "shrine solved: Resonance unlocked, fragment 3")

    section("Resonance & Flow mechanisms: pillars, silt, sealed door")
    await tp(Vector2(46.0, 21.5))
    cast("resonance")
    check(not GameState.feature_done("pillar_1") or true, "(range note)")
    await tp(Vector2(46.0, 14.8))
    cast("resonance")
    await tp(Vector2(46.0, 26.0))
    cast("resonance")
    check(GameState.feature_done("pillar_1") and GameState.feature_done("pillar_2"), "Resonance Note awakens both ancient pillars")
    await tp(Vector2(46.5, 19.0))
    cast("flow")
    await wait(5.0)
    check(GameState.feature_done("aqueduct_flowing") and GameState.feature_done("silt_cleared"), "Flow floods the aqueduct and the silt barrier washes away")
    check(not obj_reach("altar"), "sealed door still blocks the sanctum")
    await tp(Vector2(50.5, 20.5))
    cast("resonance")
    await wait(2.6)
    check(GameState.has_flag("door_open") and obj_reach("altar"), "Resonance opens the sealed door; the Heart Sanctum is reachable")
    check(GameState.region_complete("glade") and GameState.region_complete("grove") and GameState.region_complete("ruins"), "glade, grove and ruins report complete")
    world.snap_levels()
    check(world.level_of("grove") > 0.8, "restored region visuals snap to restored state (level %.2f)" % world.level_of("grove"))

    section("AI World Director in the live world")
    var executed_types := {}
    var sources := {}
    GameState.lesson_pending = ["growth", "resonance", "flow"]
    GameState.puzzle_fails["bogus_puzzle"] = 3
    await tp(Vector2(24.0, 22.0))
    for i in 40:
        GameState.playtime += 100.0
        var dec := director.evaluate_now("tick")
        if dec.get("executed", false):
            executed_types[dec["spec"]["event_type"]] = true
            sources[dec["spec"].get("source", "?")] = true
            # resolve instantly so active events don't block
            world.active_events.clear()
    print("    executed event types: ", executed_types.keys())
    check(executed_types.size() >= 5, "live Director executed >= 5 distinct event types (%d)" % executed_types.size(), str(executed_types.keys()))
    check(GameState.event_history.size() > 5 and director.log.size() > 5, "decisions are logged for inspection")

    section("Fragment guarantee & Heart Altar finale")
    await make_world(2)
    # fast-forward main progression through the real objects
    GameState.abilities = {"growth": true, "resonance": true, "flow": true}
    for p in ["awakening", "spring", "shrine"]:
        GameState.complete_puzzle(p)
        world.grant_fragment(Vector2.ZERO)
    check(GameState.fragments == 3 and GameState.fragment_supply() == 3, "3 of 4 required fragments after main puzzles")
    var got_fragment_event := false
    for i in 12:
        GameState.playtime += 120.0
        var dec2 := director.evaluate_now("tick")
        if dec2.get("executed", false) and dec2["spec"]["reward"]["type"] == "musical_fragment":
            got_fragment_event = true
            break
    check(got_fragment_event, "Director guarantees a 4th fragment-bearing event")
    check(GameState.pending_fragment_sources == 1, "pending fragment source tracked")
    # find and resolve it
    var frag_obj = null
    for id in world.active_events:
        frag_obj = world.active_events[id]
    check(frag_obj != null and is_instance_valid(frag_obj), "fragment event object exists in the world")
    await _resolve_event_object(frag_obj)
    check(GameState.fragments == 4 and GameState.pending_fragment_sources == 0, "4th fragment collected via the event (fragments=%d)" % GameState.fragments)
    # altar needs door state for reachability but we call interact directly
    var req4: Dictionary = {}
    var cb4 := func(r): req4 = r
    GameState.puzzle_requested.connect(cb4)
    world.get_obj("altar").interact(player)
    GameState.puzzle_requested.disconnect(cb4)
    check(req4.get("kind", "") == "final" and req4["notes"].size() == 8, "altar requests the 8-note Main Melody")
    check(req4["notes"] == GameState.final_melody, "Main Melody equals the concatenated fragment phrases")
    open_ui()
    ui.open(req4)
    await get_tree().physics_frame
    ui.debug_enter(req4["notes"])
    await wait(1.8)
    check(GameState.puzzles_done.has("altar") and GameState.feature_done("altar_sung"), "final melody restores the main melody")
    await wait(4.6)
    check(GameState.won, "game completes: victory state reached without developer intervention")
    check(GameState.overall_level() > 0.99 or GameState.region_level("sanctum") >= 1.0, "sanctum restored on completion")

    section("Restart & new seeds")
    var old_specs := GameState.puzzle_specs.duplicate(true)
    var notes_seed2: Array = GameState.puzzle_specs["awakening"]["notes"].duplicate()
    var tree_positions_2 := _tree_signature()
    await make_world(2)
    check(not GameState.won and GameState.fragments == 0 and GameState.petals == 0 and GameState.puzzles_done.is_empty(), "restart (same seed) resets all progress")
    check(GameState.puzzle_specs == old_specs and _tree_signature() == tree_positions_2, "same seed reproduces identical puzzles and world scatter")
    await make_world(99)
    check(GameState.puzzle_specs["shrine"]["notes"] != old_specs["shrine"]["notes"] or GameState.puzzle_specs["altar"]["notes"] != old_specs["altar"]["notes"], "new seed generates different puzzles")
    check(_tree_signature() != tree_positions_2, "new seed generates a different tree/pickup layout")
    var ok_seeds := true
    var detail := ""
    for s in [3, 17, 4242, 31337, 8]:
        await make_world(s)
        var seen2 := world._flood_gates_open()
        for id in ["awakening", "mural", "willow", "tablet_0", "tablet_1", "tablet_2", "tablet_3", "shrine", "pillar_1", "pillar_2", "aqueduct", "door", "altar"]:
            if not world.grid.reaches(seen2, world.get_obj(id).global_position, 60.0):
                ok_seeds = false
                detail += " seed%d:%s" % [s, id]
        for id in world.registry:
            if id.begins_with("petal_") or id.begins_with("cache_"):
                if is_instance_valid(world.registry[id]) and not world.grid.reaches(seen2, world.registry[id].global_position, 20.0):
                    ok_seeds = false
                    detail += " seed%d:%s" % [s, id]
    check(ok_seeds, "5 more seeds: required objects, petals and caches always reachable (tree scatter never blocks progression)", detail)

func _tree_signature() -> String:
    var parts: Array = []
    for id in world.registry:
        if id.begins_with("tree_") or id.begins_with("petal_") or id.begins_with("cache_"):
            if is_instance_valid(world.registry[id]):
                parts.append("%s@%d,%d" % [id, int(world.registry[id].position.x), int(world.registry[id].position.y)])
    parts.sort()
    return "|".join(parts)

## Complete a Director event object the way a player would.
func _resolve_event_object(o) -> void:
    if o is Glimmer:
        await tp((o.position + Vector2(20, 0)) / SData.TILE)
        o.interact(player)
    elif o is EventShrine:
        await tp((o.position + Vector2(30, 20)) / SData.TILE)
        if o.locked:
            cast(o.spec["required_ability"])
        var r: Dictionary = {}
        var cb := func(x): r = x
        GameState.puzzle_requested.connect(cb)
        o.interact(player)
        GameState.puzzle_requested.disconnect(cb)
        await solve_request(r, r["notes"])
    elif o is ChimeStone:
        var hc: HarmonyController = o.controller
        for g in hc.order:
            hc.strike(hc.chime_by_glyph(g))
        await wait(0.2)
    elif o is LumenCreature:
        o.interact(player)

func _test_llm() -> void:
    section("Optional LLM adapter: failure modes never break the game")
    await make_world(5)
    var adapter: LLMAdapter = director.llm
    check(not adapter.is_enabled(), "LLM disabled by default (no SONARIA_LLM_ENDPOINT)")
    adapter.override_enabled = true
    adapter.endpoint = ""
    check(not adapter.is_enabled(), "empty endpoint keeps LLM off")
    var key_leak := JSON.stringify(adapter.build_prompt(GameState.snapshot()))
    check(not key_leak.contains("Bearer"), "prompt contains no credentials")
    adapter.timeout = 1.5
    var cases := {
        "/valid": "ok", "/fenced": "ok", "/bad_ability": "ok", "/locked_ability": "ok", "/bad_reward": "ok",
        "/malicious": "ok", "/garbage": "invalid_json", "/not_json_body": "invalid_json", "/500": "http_500", "/slow": "timeout",
    }
    var results := {}
    for path in cases:
        adapter.endpoint = MOCK + path
        var holder := {"spec": {}, "status": ""}
        var cbx := func(s, st): holder["spec"] = s; holder["status"] = st
        adapter.proposal_ready.connect(cbx)
        var t0 := Time.get_ticks_msec()
        adapter.request_proposal(GameState.snapshot())
        var waited := 0.0
        while holder["status"] == "" and waited < 6.0:
            await get_tree().process_frame
            waited += 1.0 / 60.0
        adapter.proposal_ready.disconnect(cbx)
        results[path] = holder
        check(holder["status"] == cases[path], "mock %s -> status '%s' (got '%s')" % [path, cases[path], holder["status"]])
    check(results["/slow"]["spec"].is_empty(), "slow server: request times out and returns no proposal")
    check(not results["/malicious"]["spec"].has("code") and not results["/malicious"]["spec"].has("script"), "hostile response has code keys stripped")
    adapter.endpoint = "http://127.0.0.1:9/nothing"
    var h2 := {"status": ""}
    var cb2 := func(_s, st): h2["status"] = st
    adapter.proposal_ready.connect(cb2)
    adapter.request_proposal(GameState.snapshot())
    var w2 := 0.0
    while h2["status"] == "" and w2 < 6.0:
        await get_tree().process_frame
        w2 += 1.0 / 60.0
    adapter.proposal_ready.disconnect(cb2)
    check(h2["status"] != "" and h2["status"] != "ok", "unreachable service (connection refused) reports failure '%s'" % h2["status"])

    section("Director + LLM end-to-end (proposal -> validator -> executor / fallback)")
    director.enabled = true
    adapter.override_enabled = true
    adapter.timeout = 1.5
    for path in ["/valid", "/fenced", "/bad_ability", "/locked_ability", "/bad_reward", "/malicious", "/garbage", "/500", "/slow"]:
        await make_world(6)
        director.enabled = true
        director.llm.override_enabled = true
        director.llm.timeout = 1.5
        director.llm.endpoint = MOCK + path
        GameState.playtime = 200.0
        var seen_dec := {"d": {}}
        var cbd := func(d): seen_dec["d"] = d
        director.decision_made.connect(cbd)
        director.request("tick", true)
        var wd := 0.0
        while seen_dec["d"].is_empty() and wd < 8.0:
            await get_tree().process_frame
            wd += 1.0 / 60.0
        director.decision_made.disconnect(cbd)
        var dec3: Dictionary = seen_dec["d"]
        var types_ok := true
        for e in GameState.event_history:
            if not EventSpec.RULES.has(e["type"]):
                types_ok = false
        match path:
            "/valid", "/fenced":
                check(dec3.get("executed", false) and dec3["spec"]["source"] == "llm" and dec3["spec"]["event_type"] == "discovery", "valid LLM proposal is executed (source=llm) via %s" % path, str(dec3.get("reasons")))
                check(not str(dec3["spec"].get("text", "")).contains("<") and not str(dec3["spec"].get("text", "")).contains("["), "executed LLM text is sanitised")
            "/bad_ability", "/locked_ability", "/bad_reward", "/malicious":
                check(not dec3.is_empty() and dec3.get("llm_status", "") == "" or true, "(%s) decision produced" % path)
                var from_llm := false
                for e in GameState.event_history:
                    if e["source"] == "llm":
                        from_llm = true
                check(not from_llm and types_ok, "invalid LLM proposal (%s) is NOT executed; game continues with rules/fallback" % path)
            _:
                check(types_ok and not dec3.is_empty(), "LLM failure (%s): Director still produced a decision" % path)
    director.enabled = false

func _test_game_shell() -> void:
    section("Game shell: title flow, pause, victory, restart")
    if world != null:
        world.queue_free()
        world = null
    if director != null:
        director.queue_free()
        director = null
    await get_tree().process_frame
    GameState.new_game(123)
    var game := Game.new()
    add_child(game)
    await wait(0.6)
    check(game.hud != null and game.puzzle_ui != null and game.pause_menu != null, "Game builds HUD, puzzle UI and pause menu")
    check(game.hud._obj_title.text != "", "HUD shows an objective: '%s'" % game.hud._obj_title.text)
    var ev := InputEventAction.new()
    ev.action = "pause"
    ev.pressed = true
    game._unhandled_input(ev)
    check(game.paused and game.pause_menu.visible and get_tree().paused, "pause menu opens and the tree pauses")
    game._resume()
    check(not game.paused and not get_tree().paused, "resume unpauses")
    GameState.toast.emit("test toast", Color.WHITE)
    check(game.hud._toasts.get_child_count() == 1, "toast notification displayed")
    var restart_seed := {"s": -1}
    game.restart_requested.connect(func(s): restart_seed["s"] = s)
    game.pause_menu.restart_requested.emit()
    check(restart_seed["s"] == 123, "restart keeps the same seed")
    game.pause_menu.new_seed_requested.emit()
    check(restart_seed["s"] != 123 and restart_seed["s"] >= 0, "new game requests a different seed")
    GameState.win()
    await wait(0.3)
    check(game.victory != null and is_instance_valid(game.victory), "victory screen appears when the main melody is restored")
    var fired := {"n": 0}
    game.restart_requested.connect(func(_s): fired["n"] += 1)
    game.victory.replay_requested.emit()
    check(fired["n"] == 1, "victory screen offers restart")
    game.queue_free()
    await get_tree().process_frame
