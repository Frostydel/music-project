#!/usr/bin/env python3
"""Mock OpenAI-compatible LLM endpoint used by the automated tests.
Each URL path simulates a different behaviour (valid, hostile, slow, broken)."""
import json, sys, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

def chat(content):
    return json.dumps({"choices": [{"message": {"role": "assistant", "content": content}}]})

VALID = {"event_type": "discovery", "difficulty": 1, "required_ability": "none",
         "reward": {"type": "echo_petals", "amount": 3}, "world_effect": "spawn_discovery",
         "text": "A [b]glimmer[/b] <script>alert(1)</script> hums nearby."}

RESPONSES = {
    "/valid": (200, chat(json.dumps(VALID))),
    "/fenced": (200, chat("Sure!\n```json\n" + json.dumps(VALID) + "\n```")),
    "/bad_ability": (200, chat(json.dumps({**VALID, "required_ability": "telekinesis"}))),
    "/locked_ability": (200, chat(json.dumps({"event_type": "hidden_shrine", "difficulty": 1, "required_ability": "flow",
                         "reward": {"type": "echo_petals", "amount": 3}, "world_effect": "reveal_shrine"}))),
    "/bad_reward": (200, chat(json.dumps({**VALID, "reward": {"type": "infinite_gold", "amount": 99999}}))),
    "/malicious": (200, chat(json.dumps({"event_type": "execute_script", "code": "OS.execute('rm',['-rf','/'])",
                    "world_effect": "get_tree().quit()", "difficulty": 9, "reward": {"type": "musical_fragment", "amount": 50}}))),
    "/garbage": (200, chat("I'm sorry, I cannot help with that.")),
    "/not_json_body": (200, "<html>oops</html>"),
    "/500": (500, "internal error"),
}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0)); self.rfile.read(n)
        if self.path == "/slow":
            time.sleep(8)
            code, body = RESPONSES["/valid"]
        else:
            code, body = RESPONSES.get(self.path, (404, "not found"))
        data = body.encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers()
        try: self.wfile.write(data)
        except Exception: pass

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
