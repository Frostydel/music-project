#!/usr/bin/env bash
# Runs the full automated suite headlessly. Usage: GODOT=/path/to/godot tests/run_tests.sh
set -u
GODOT="${GODOT:-godot}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 "$ROOT/tests/mock_llm_server.py" 8765 & SRV=$!
trap 'kill $SRV 2>/dev/null' EXIT
sleep 1
timeout "${TEST_TIMEOUT:-280}" "$GODOT" --headless --path "$ROOT" --fixed-fps 60 res://tests/test_runner.tscn 2>&1 | grep -v -E "^Godot Engine|ObjectDB|at: cleanup|^$"
exit "${PIPESTATUS[0]}"
