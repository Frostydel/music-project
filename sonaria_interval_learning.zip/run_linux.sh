#!/usr/bin/env sh
set -eu
if command -v godot4 >/dev/null 2>&1; then
  exec godot4 --path "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)" "$@"
elif command -v godot >/dev/null 2>&1; then
  exec godot --path "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)" "$@"
fi
printf '%s\n' 'Godot 4.3 is required. Install it from https://godotengine.org/download/ and run this script again.' >&2
exit 127
