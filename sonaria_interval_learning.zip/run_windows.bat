@echo off
setlocal
set "PROJECT=%~dp0"
where godot4.exe >nul 2>nul
if %errorlevel%==0 (
  godot4.exe --path "%PROJECT%" %*
  exit /b %errorlevel%
)
where godot.exe >nul 2>nul
if %errorlevel%==0 (
  godot.exe --path "%PROJECT%" %*
  exit /b %errorlevel%
)
echo Godot 4.3 is required. Install it from https://godotengine.org/download/ and run this script again.
exit /b 127
