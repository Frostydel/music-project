#!/usr/bin/env bash
# Usage: tools/shot.sh NAME [godot user args...]   -> tests/out/shot_NAME.png (needs xvfb + mesa)
# Example: tools/shot.sh restored --autostart --seed=1 --cheat=restore --at=11,20
set -e
GODOT="${GODOT:-godot}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME="$1"; shift
mkdir -p "$ROOT/tests/out"
LIBGL_ALWAYS_SOFTWARE=1 timeout 180 xvfb-run -a -s "-screen 0 1280x720x24" "$GODOT" --path "$ROOT" \
  --rendering-driver opengl3 --resolution 1280x720 -- "$@" \
  --screenshot="$ROOT/tests/out/shot_$NAME.png" --shot-after="${SHOT_AFTER:-5}" 2>&1 | grep -E "SCRIPT ERROR|^ERROR|screenshot saved" || true
