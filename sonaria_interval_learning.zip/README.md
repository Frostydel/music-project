# SONARIA: The World That Hears You

A 2D top-down fantasy adventure for Godot 4.3. The Silence has drained music from the world; use its notes to revive trees, open paths and restore the lost melody. Art and audio are generated in code; no external assets or API keys are needed.

## Clear learning goal

By the end of the game, the player should be able to hear and distinguish two consonant upward intervals:

- **Major third:** C to E, four semitones, the warm rise taught by the Awakening Stone.
- **Perfect fifth:** C to G, seven semitones, the wider rise taught by the same lesson.

The opening puzzle plays a fixed C–E–C–G demonstration, so players hear both intervals before repeating them. When they make a pitch error in the opening lesson or final performance, the game says whether the chosen pitch was too high or too low. The eight-note altar melody reuses the same C/E/G relationships. This connects the notes to an audible concept rather than relying only on random sequence memory. The game does not claim to teach interval identification to mastery; a teacher can assess that by asking players to identify the two intervals without visual note labels.

## Run the game

Install Godot 4.3, then launch with the included script:

- Linux: `./run_linux.sh`
- Windows: `run_windows.bat`

You can also open this folder in Godot and press **F6/F5** (or run `godot --path .`). The launchers need the Godot 4.3 editor/runtime installed. This archive contains the complete runnable project source, not a platform-exported standalone binary; exporting a self-contained Windows/Linux executable requires Godot export templates for the target platform.

## Controls

WASD / arrows move · E interact · 1/2/3 select Growth/Resonance/Flow · Space sing · Puzzle: 1–4 play notes, L listen, H hint, R retry, Backspace undo · Esc pause · F3 Director debug panel.

## Adventure progression

Wake the Awakening Stone and learn the major third and perfect fifth → clear the thicket with Growth → ring the Spring Hollow chimes in the mural's order to earn Flow → grow the Elder Willow bridge → read four tablets and sing their melody at the Resonance Shrine → wake two pillars, flood the aqueduct and open the sealed door → collect four melody fragments → sing the Main Melody at the Heart Altar.

## Project features

- Seeded world and puzzle generation, procedural audio and visuals, no external assets.
- An AI World Director with eight event types, rules-only offline mode, optional validated LLM proposals, and deterministic seeded behavior.
- Puzzle retries, listening, hints, color-coded note feedback and pitch-direction feedback for the interval lesson.
- Unit, world, LLM and shell test suites under `tests/`.

## Verification notes

This revision could not be run in the current build environment because Godot 4.3 and export templates are not installed. The original project notes reported 69 unit tests and 22 world tests passing, with two world-test failures and several unverified test groups. This revision updates the lesson-related test expectations, but those tests and a full human playthrough still need to be run in Godot before presenting it as fully verified. Save/load, microphone/MIDI input, balance and pacing remain future work.
