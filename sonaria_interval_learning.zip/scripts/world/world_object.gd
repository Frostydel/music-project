class_name WorldObject
extends Node2D
## Base class for everything placed in the world (props, puzzles, events).
## Subclasses override build(), prompt(), interact(), on_note(), _draw().

var object_id := ""
var region := "glade"
var world = null
var highlighted := false
var interactable := false
var accepts_notes := false
var animated := false
var interact_radius := 44.0
var _t := 0.0
var _bodies: Array = []
var _solid_ids: Array = []

func build() -> void:
    pass

func prompt() -> String:
    return "Interact"

func can_interact() -> bool:
    return interactable and visible

func interact(_player) -> void:
    pass

## Return true if the note had an effect (consumes the cast feedback).
func on_note(_ability: String, _player) -> bool:
    return false

func note_radius() -> float:
    return 130.0

func interact_point() -> Vector2:
    return global_position

func level() -> float:
    return world.level_of(region) if world != null else 0.0

func refresh() -> void:
    queue_redraw()

func _process(delta: float) -> void:
    _t += delta
    if highlighted or animated:
        queue_redraw()

## Add a solid rectangle (local coordinates). Mirrored into the world grid.
func add_solid(rect: Rect2) -> void:
    var body := StaticBody2D.new()
    body.collision_layer = 2
    body.collision_mask = 0
    var sh := CollisionShape2D.new()
    var rs := RectangleShape2D.new()
    rs.size = rect.size
    sh.shape = rs
    sh.position = rect.get_center()
    body.add_child(sh)
    add_child(body)
    _bodies.append(body)
    var id := "%s#%d" % [object_id, _bodies.size()]
    _solid_ids.append(id)
    if world != null:
        world.grid.add(id, Rect2(global_position + rect.position, rect.size))

func set_solids_enabled(on: bool) -> void:
    for b in _bodies:
        for c in b.get_children():
            if c is CollisionShape2D:
                c.set_deferred("disabled", not on)
    if world != null:
        for id in _solid_ids:
            world.grid.set_enabled(id, on)

func draw_marker(offset_y := -48.0) -> void:
    if not highlighted:
        return
    var b := sin(_t * 5.0) * 3.0
    var p := Vector2(0, offset_y + b)
    Art.glow(self, p, 16.0, SData.GOLD, 0.8)
    draw_colored_polygon(PackedVector2Array([p + Vector2(0, 8), p + Vector2(-7, 0), p + Vector2(0, -8), p + Vector2(7, 0)]), SData.GOLD)
    draw_arc(Vector2.ZERO, 26.0 + sin(_t * 4.0) * 2.0, 0.0, TAU, 32, Color(1, 0.9, 0.6, 0.55), 2.0)
