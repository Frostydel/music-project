class_name Ground
extends Node2D
## Tile ground + dirt paths, tinted by each region's restoration level.

var world
var paths: Array = []      # arrays of Vector2 (tile coords)

func _hash(x: int, y: int) -> float:
    return float((x * 73856093 ^ y * 19349663) & 255) / 255.0

func _draw() -> void:
    var T := SData.TILE
    var lv_cache := {}
    for r in SData.REGIONS:
        lv_cache[r] = world.level_of(r)
    for ty in SData.MAP_H:
        for tx in SData.MAP_W:
            var lv: float = lv_cache[SData.region_at_tile(float(tx) + 0.5)]
            var h := _hash(tx, ty) * 0.55
            var dead := SData.GROUND_DEAD.lerp(SData.GROUND_DEAD.lightened(0.06), h)
            var alive := SData.GROUND_ALIVE_A.lerp(SData.GROUND_ALIVE_B, h)
            draw_rect(Rect2(tx * T, ty * T, T, T), dead.lerp(alive, lv))
    for pass_i in 2:
        for path in paths:
            for i in range(path.size() - 1):
                var a: Vector2 = path[i] * T
                var b: Vector2 = path[i + 1] * T
                var steps := maxi(1, int(a.distance_to(b) / 96.0))
                for s in steps:
                    var p0 := a.lerp(b, float(s) / steps)
                    var p1 := a.lerp(b, float(s + 1) / steps)
                    var lv2: float = lv_cache[SData.region_at_tile((p0.x + p1.x) * 0.5 / T)]
                    var col := SData.PATH_DEAD.lerp(SData.PATH_ALIVE, lv2)
                    if pass_i == 0:
                        Art.thick_line(self, p0, p1, 44.0, col.darkened(0.3))
                        draw_circle(p0, 22.0, col.darkened(0.3))
                    else:
                        Art.thick_line(self, p0, p1, 36.0, col)
                        draw_circle(p0, 18.0, col)
            var last: Vector2 = path[path.size() - 1] * T
            var lc := SData.PATH_DEAD.lerp(SData.PATH_ALIVE, lv_cache[SData.region_at_tile(last.x / T)])
            draw_circle(last, 22.0 if pass_i == 0 else 18.0, lc.darkened(0.3) if pass_i == 0 else lc)
