class_name World
extends Node2D
## Builds the forest region and provides services to world objects:
## restoration visuals, rewards, reachability queries and the Director's
## event handlers (exec_*). Layout is fixed; only tree scatter, petals,
## hidden caches and puzzle contents vary with the seed.

const T := SData.TILE
const PATHS := [
    [Vector2(4, 20.5), Vector2(17, 20.5), Vector2(30, 20.5), Vector2(38, 20.5), Vector2(47, 20.5), Vector2(52.5, 20.5), Vector2(58, 20.5)],
    [Vector2(24, 20.5), Vector2(24, 14.0)], [Vector2(24, 20.5), Vector2(21.5, 26.5)],
    [Vector2(39, 20.5), Vector2(38.5, 26.5)], [Vector2(41, 20.5), Vector2(41, 12.5), Vector2(43.5, 12.5)],
    [Vector2(41, 20.5), Vector2(41, 28.5), Vector2(43.5, 28.5)],
]
const TABLET_POS := [Vector2(21.5, 26.5), Vector2(38.5, 26.5), Vector2(43.5, 12.5), Vector2(43.5, 28.5)]
const CACHE_CANDIDATES := [Vector2(9.5, 8.5), Vector2(8.5, 31.0), Vector2(28.5, 28.0), Vector2(20.5, 13.0), Vector2(27.0, 6.5), Vector2(41.0, 8.5), Vector2(49.0, 32.0)]

var grid := WorldGrid.new()
var objects: Node2D
var fx: Node2D
var ground: Ground
var river: River
var decor: Decor
var player = null
var director = null
var query: WorldQuery
var shown := {"glade": 0.0, "grove": 0.0, "ruins": 0.0, "sanctum": 0.0}
var registry := {}
var active_events := {}
var harmonies := {}
var particles := {}
var _canvas_mod: CanvasModulate
var _refresh_acc := 0.0
var _keep: Array = []
var ending_started := false

func _ready() -> void:
    build_world()

# ====================================================================== build
func build_world() -> void:
    _canvas_mod = CanvasModulate.new()
    _canvas_mod.color = Color(0.74, 0.77, 0.96)
    add_child(_canvas_mod)
    ground = Ground.new()
    ground.world = self
    ground.paths = PATHS
    ground.z_index = -20
    add_child(ground)
    river = River.new()
    river.world = self
    river.z_index = -19
    add_child(river)
    river.build()
    decor = Decor.new()
    decor.world = self
    decor.z_index = -15
    add_child(decor)
    decor.build()
    objects = Node2D.new()
    objects.y_sort_enabled = true
    add_child(objects)
    fx = Node2D.new()
    fx.z_index = 30
    add_child(fx)
    _add_walls()
    _populate()
    grid.rebuild()
    _scatter_petals_and_caches()
    _scatter_trees()
    _plant_border_trees()
    _build_particles()
    grid.rebuild()
    _compute_explorable()
    query = WorldQueryImpl.new(self)

func add_obj(cls: GDScript, id: String, tile: Vector2, props := {}) -> Node2D:
    var o = cls.new()
    o.object_id = id
    o.world = self
    for k in props:
        o.set(k, props[k])
    o.region = SData.region_at_tile(tile.x)
    o.position = tile * T
    objects.add_child(o)
    o.build()
    registry[id] = o
    if o.interactable:
        o.add_to_group("interactable")
    if o.accepts_notes:
        o.add_to_group("note_target")
    return o

func add_wall(rect_tiles: Rect2, style := "invisible", id := "") -> void:
    var size := rect_tiles.size * T
    var bottom_center := Vector2(rect_tiles.position.x + rect_tiles.size.x * 0.5, rect_tiles.end.y)
    add_obj(WallBlock, id if id != "" else "wall_%d_%d" % [rect_tiles.position.x, rect_tiles.position.y], bottom_center, {"size_px": size, "style": style})

func get_obj(id: String):
    var o = registry.get(id, null)
    if o != null and is_instance_valid(o):
        return o
    return null

func level_of(region: String) -> float:
    return shown.get(region, 0.0)

func _add_walls() -> void:
    add_wall(Rect2(0, 0, 64, 2), "invisible", "border_top")
    add_wall(Rect2(0, 38, 64, 2), "invisible", "border_bottom")
    add_wall(Rect2(0, 2, 1, 36), "invisible", "border_left")
    add_wall(Rect2(63, 2, 1, 36), "invisible", "border_right")
    add_wall(Rect2(17, 2, 2, 16), "invisible", "forest_wall_n")
    add_wall(Rect2(17, 23, 2, 15), "invisible", "forest_wall_s")
    add_wall(Rect2(52, 2, 11, 9), "invisible", "sanct_north_forest")
    add_wall(Rect2(52, 31, 11, 7), "invisible", "sanct_south_forest")
    add_wall(Rect2(52, 11, 11, 1), "ruin", "sanct_north")
    add_wall(Rect2(52, 30, 11, 1), "ruin", "sanct_south")
    add_wall(Rect2(52, 12, 1, 7), "ruin", "sanct_west_n")
    add_wall(Rect2(52, 22, 1, 8), "ruin", "sanct_west_s")
    add_wall(Rect2(48, 17, 4, 1), "ruin", "corridor_n")
    add_wall(Rect2(48, 23, 4, 1), "ruin", "corridor_s")
    _forest_line(Vector2(17.4, 2.5), Vector2(17.4, 18.0), 1.15)
    _forest_line(Vector2(18.6, 3.0), Vector2(18.6, 18.0), 1.15)
    _forest_line(Vector2(17.4, 24.5), Vector2(17.4, 38.0), 1.15)
    _forest_line(Vector2(18.6, 25.0), Vector2(18.6, 38.0), 1.15)
    _forest_line(Vector2(52.4, 2.5), Vector2(52.4, 11.0), 1.2)
    _forest_line(Vector2(53.8, 2.5), Vector2(62.5, 2.5), 1.3)
    _forest_line(Vector2(52.4, 31.5), Vector2(62.5, 31.5), 1.3)
    _forest_line(Vector2(52.4, 38.0), Vector2(52.4, 31.5), 1.2)

func _forest_line(a: Vector2, b: Vector2, step: float) -> void:
    var n := maxi(1, int(a.distance_to(b) / step))
    for i in n + 1:
        var p := a.lerp(b, float(i) / n)
        var tr = add_obj(TreeProp, "ftree_%d_%d" % [int(p.x * 10.0), int(p.y * 10.0)], p, {"solid": false, "sway": false, "variant": fmod(p.x * 7.3 + p.y * 3.1, 1.0), "scale_k": 1.0 + 0.15 * sin(p.y * 4.0)})
        tr.set_process(false)

func _plant_border_trees() -> void:
    for row in [[1.9, 0.5], [2.6, 1.1]]:
        var x: float = row[1]
        while x < 64.0:
            _border_tree(Vector2(x, row[0]))
            _border_tree(Vector2(x + 0.2, 40.0 - row[0] + 1.3))
            x += 1.7
    var y := 3.0
    while y < 38.0:
        _border_tree(Vector2(0.4, y))
        _border_tree(Vector2(63.6, y))
        y += 1.7

func _border_tree(p: Vector2) -> void:
    var tr = add_obj(TreeProp, "btree_%d_%d" % [int(p.x * 10.0), int(p.y * 10.0)], p, {"solid": false, "sway": false, "variant": fmod(p.x * 5.1 + p.y * 2.3, 1.0), "scale_k": 1.1})
    tr.set_process(false)

# ================================================================== populate
func _populate() -> void:
    var growth_target := {"kind": "tree", "ability": "growth"}
    # ---------------- Glade
    add_obj(LoreStone, "lore_intro", Vector2(6.8, 18.8), {"title": "Echo Stone", "text": "Long ago every living thing in Sonaria had its own melody, and the forests grew by harmony. Then came the Silence. You carry the Resonance Core, the last warm echo. Find the Awakening Stone east of here and answer its song."})
    add_obj(AwakeningStone, "awakening", Vector2(11.0, 19.0))
    add_obj(AbilityTarget, "tree_g1", Vector2(7.5, 14.0), growth_target)
    add_obj(AbilityTarget, "tree_g2", Vector2(8.5, 26.5), growth_target)
    add_obj(AbilityTarget, "tree_g3", Vector2(14.0, 24.0), growth_target)
    add_obj(LoreStone, "lore_thicket", Vector2(15.0, 22.0), {"title": "Weathered Stone", "text": "Thorns choke the only road east. Withered things remember the Growth Note: select it with 1 and sing it with Space while standing close."})
    add_obj(Thicket, "thicket", Vector2(18.0, 23.0), {"size_px": Vector2(64, 160)})
    # ---------------- Grove
    var hc := HarmonyController.new()
    hc.puzzle_id = "spring"
    hc.order = GameState.puzzle_specs["spring"]["glyphs"].duplicate()
    hc.world = self
    hc.center = Vector2(24.0, 10.0) * T
    hc.on_solved = Callable(self, "_spring_solved")
    harmonies["spring"] = hc
    add_obj(SpringBasin, "spring_basin", Vector2(24.0, 10.0))
    var chime_pos := [Vector2(21.5, 8.0), Vector2(26.5, 8.0), Vector2(26.5, 12.2), Vector2(21.5, 12.2)]
    for i in 4:
        var c = add_obj(ChimeStone, "chime_%d" % i, chime_pos[i], {"glyph": i, "controller": hc})
        hc.chimes.append(c)
    add_obj(HarmonyMural, "mural", Vector2(24.0, 15.2), {"order": hc.order})
    add_obj(RiverSource, "river_source", Vector2(30.5, 5.5))
    add_obj(ElderWillow, "willow", Vector2(30.2, 21.8))
    add_obj(LoreStone, "lore_willow", Vector2(28.0, 22.6), {"title": "Willow Stone", "text": "The Elder Willow still dreams of reaching the far bank. Sing Growth beside it and it will finish its bridge. Beyond the ravine lie the ruins of the Old Choir."})
    add_obj(LoreStone, "lore_river", Vector2(31.2, 8.0), {"title": "Source Stone", "text": "The river is only a scar until it is sung awake. When you know the Flow Note, return to the dry basin at the ravine's head."})
    var tablets: Array = GameState.puzzle_specs["shrine"]["notes"]
    add_obj(GlyphTablet, "tablet_0", TABLET_POS[0], {"index": 0, "note": tablets[0]})
    add_obj(AbilityTarget, "tree_v1", Vector2(27.0, 17.2), growth_target)
    add_obj(AbilityTarget, "tree_v2", Vector2(22.0, 31.0), growth_target)
    # ---------------- Ruins
    for i in range(1, 4):
        add_obj(GlyphTablet, "tablet_%d" % i, TABLET_POS[i], {"index": i, "note": tablets[i]})
    add_obj(ResonanceShrine, "shrine", Vector2(44.0, 18.6))
    add_obj(LoreStone, "lore_ruins", Vector2(40.5, 22.6), {"title": "Choir Stone", "text": "Four tablets carry the Verses of the Old Choir, scattered across the world. The shrine to the north will only answer someone who has read them all, in order."})
    add_obj(LoreStone, "lore_corridor", Vector2(46.2, 22.0), {"title": "Silt Stone", "text": "The corridor ahead is choked with silt, and the door beyond is sealed. Two pillars stand ready to wake, and the old aqueduct above only waits for water."})
    add_obj(ResonancePillar, "pillar_1", Vector2(46.5, 14.0))
    add_obj(ResonancePillar, "pillar_2", Vector2(46.5, 26.8))
    add_obj(Aqueduct, "aqueduct", Vector2(47.0, 16.2))
    add_obj(SiltBarrier, "silt", Vector2(50.0, 23.0), {"size_px": Vector2(64, 160)})
    add_obj(SealedDoor, "door", Vector2(52.5, 22.0), {"size_px": Vector2(32, 96)})
    add_obj(WallBlock, "ruin_pillar_a", Vector2(39.5, 18.0), {"size_px": Vector2(26, 60), "style": "pillar"})
    add_obj(WallBlock, "ruin_pillar_b", Vector2(39.5, 23.8), {"size_px": Vector2(26, 52), "style": "pillar"})
    add_obj(WallBlock, "ruin_wall_a", Vector2(44.5, 10.0), {"size_px": Vector2(96, 24), "style": "ruin"})
    add_obj(WallBlock, "ruin_wall_b", Vector2(44.5, 30.8), {"size_px": Vector2(96, 24), "style": "ruin"})
    # ---------------- Sanctum
    add_obj(HeartAltar, "altar", Vector2(58.0, 21.0))
    add_obj(WallBlock, "sanct_pillar_a", Vector2(55.5, 16.0), {"size_px": Vector2(26, 56), "style": "pillar"})
    add_obj(WallBlock, "sanct_pillar_b", Vector2(55.5, 26.0), {"size_px": Vector2(26, 56), "style": "pillar"})
    add_obj(WallBlock, "sanct_pillar_c", Vector2(61.0, 16.0), {"size_px": Vector2(26, 56), "style": "pillar"})
    add_obj(WallBlock, "sanct_pillar_d", Vector2(61.0, 26.0), {"size_px": Vector2(26, 56), "style": "pillar"})
    # ---------------- Blight patches (one per corruption site)
    for sid in SData.sites_of_kind("corruption"):
        add_obj(BlightPatch, sid, SData.SITES[sid]["pos"])
    # ---------------- Restoration features
    for f in [["stone_awakened", "glade", 2.0, true], ["thicket_cleared", "glade", 2.0, true], ["tree_g1", "glade", 1.0, false], ["tree_g2", "glade", 1.0, false], ["tree_g3", "glade", 1.0, false],
            ["spring_restored", "grove", 3.0, true], ["river_flowing", "grove", 3.0, true], ["willow_bridge", "grove", 2.0, true], ["tree_v1", "grove", 1.0, false], ["tree_v2", "grove", 1.0, false],
            ["shrine_resonated", "ruins", 2.0, true], ["pillar_1", "ruins", 1.0, true], ["pillar_2", "ruins", 1.0, true], ["aqueduct_flowing", "ruins", 1.0, true], ["silt_cleared", "ruins", 1.0, true], ["door_open", "ruins", 1.0, true],
            ["altar_sung", "sanctum", 3.0, true]]:
        GameState.register_feature(f[0], f[1], f[2], f[3])

func _spring_solved() -> void:
    GameState.complete_puzzle("spring")
    get_obj("spring_basin").restore()
    complete_feature("spring_restored")
    unlock_ability("flow", Vector2(24, 10) * T)
    grant_fragment(Vector2(24, 10) * T)

# ======================================================== seeded scattering
func _flood_gates_open() -> PackedByteArray:
    var ids: Array = []
    for id in grid.rects:
        if id.begins_with("thicket#") or id.begins_with("silt#") or id.begins_with("door#") or id.begins_with("gap_main_"):
            ids.append(id)
    for id in ids:
        grid.set_enabled(id, false)
    grid.rebuild()
    var seen := grid.flood(SData.START_TILE * T)
    for id in ids:
        grid.set_enabled(id, true)
    grid.rebuild()
    return seen

func _scatter_petals_and_caches() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = GameState.seed_value * 17 + 3
    var seen := _flood_gates_open()
    var taken: Array = []
    # hidden caches revealed by Resonance
    var cands: Array = CACHE_CANDIDATES.duplicate()
    for i in range(cands.size() - 1, 0, -1):
        var j := rng.randi_range(0, i)
        var tmp = cands[i]
        cands[i] = cands[j]
        cands[j] = tmp
    var n := 0
    for c in cands:
        if n >= 3:
            break
        if grid.reaches(seen, c * T, 12.0) and not grid.is_blocked(c * T):
            add_obj(Glimmer, "cache_%d" % n, c, {"concealed": true, "reward": {"type": "echo_petals", "amount": 4}})
            taken.append(c * T)
            n += 1
    # petals
    var count := 0
    var tries := 0
    while count < 14 and tries < 3000:
        tries += 1
        var t := Vector2(rng.randf_range(2.5, 51.0), rng.randf_range(3.0, 37.0))
        var px := t * T
        if absf(t.x - SData.river_cx(t.y)) < 3.0 or (t.x > 16.0 and t.x < 20.0):
            continue
        if grid.is_blocked(px) or not grid.reaches(seen, px, 6.0):
            continue
        var ok := true
        for q in taken:
            if px.distance_to(q) < 110.0:
                ok = false
                break
        if not ok:
            continue
        for sid in SData.SITES:
            if px.distance_to(SData.SITES[sid]["pos"] * T) < 70.0:
                ok = false
                break
        if not ok or px.distance_to(SData.START_TILE * T) < 100.0:
            continue
        taken.append(px)
        add_obj(EchoPetal, "petal_%d" % count, t)
        count += 1

func _keep_clear() -> Array:
    var keep: Array = []
    for path in PATHS:
        for i in range(path.size() - 1):
            var a: Vector2 = path[i] * T
            var b: Vector2 = path[i + 1] * T
            var n := maxi(1, int(a.distance_to(b) / 64.0))
            for s in n + 1:
                keep.append([a.lerp(b, float(s) / n), 84.0])
    for id in registry:
        var o = registry[id]
        if is_instance_valid(o) and not (o is TreeProp) and not (o is WallBlock):
            keep.append([o.position, 78.0])
    for sid in SData.SITES:
        keep.append([SData.SITES[sid]["pos"] * T, 90.0])
    keep.append([SData.START_TILE * T, 140.0])
    return keep

func _scatter_trees() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = GameState.seed_value * 31 + 7
    var keep := _keep_clear()
    var placed: Array = []
    var tries := 0
    while placed.size() < 70 and tries < 5000:
        tries += 1
        var t := Vector2(rng.randf_range(2.0, 62.0), rng.randf_range(3.0, 37.5))
        var px := t * T
        if t.x >= 51.0 or absf(t.x - SData.river_cx(t.y)) < 3.6:
            continue
        if t.x > 16.0 and t.x < 20.5:
            continue
        if t.x > 36.0 and t.x < 52.0 and t.y > 8.5 and t.y < 31.5:
            continue
        if grid.is_blocked(px):
            continue
        var ok := true
        for k in keep:
            if px.distance_to(k[0]) < k[1]:
                ok = false
                break
        if not ok:
            continue
        for q in placed:
            if px.distance_to(q) < 100.0:
                ok = false
                break
        if not ok:
            continue
        placed.append(px)
        add_obj(TreeProp, "tree_%d" % placed.size(), t, {"solid": true, "variant": rng.randf(), "scale_k": rng.randf_range(0.9, 1.25)})

func _build_particles() -> void:
    var rects := {"glade": Rect2(1, 2, 16, 36), "grove": Rect2(19, 2, 14, 36), "ruins": Rect2(37, 2, 15, 36), "sanctum": Rect2(53, 12, 10, 18)}
    for r in rects:
        var rc: Rect2 = rects[r]
        var p := CPUParticles2D.new()
        p.position = (rc.position + rc.size * 0.5) * T
        p.amount = 46
        p.lifetime = 6.0
        p.preprocess = 6.0
        p.texture = Fx.glow_texture()
        p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
        p.emission_rect_extents = rc.size * T * 0.5
        p.direction = Vector2(0, -1)
        p.spread = 60.0
        p.initial_velocity_min = 4.0
        p.initial_velocity_max = 14.0
        p.scale_amount_min = 0.03
        p.scale_amount_max = 0.09
        p.color = SData.GOLD.lerp(SData.TEAL, 0.3)
        var ramp := Gradient.new()
        ramp.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
        ramp.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
        p.color_ramp = ramp
        p.z_index = 25
        p.modulate.a = 0.0
        p.emitting = Prefs.particles
        add_child(p)
        particles[r] = p
        # drifting ash for dead regions
        var ash := p.duplicate() as CPUParticles2D
        ash.color = Color(0.5, 0.45, 0.6)
        ash.amount = 30
        ash.initial_velocity_max = 8.0
        ash.gravity = Vector2(0, 6)
        ash.direction = Vector2(0.3, 1)
        ash.modulate.a = 0.5
        add_child(ash)
        particles[r + "_ash"] = ash

func _compute_explorable() -> void:
    grid.ensure()
    var counts := {}
    var per := int(GameState.COARSE / WorldGrid.CELL)
    for cy in int(SData.MAP_PX.y / GameState.COARSE):
        for cx in int(SData.MAP_PX.x / GameState.COARSE):
            var free := false
            for y in range(cy * per, cy * per + per):
                for x in range(cx * per, cx * per + per):
                    if grid.blocked[y * grid.cols + x] == 0:
                        free = true
                        break
                if free:
                    break
            if free:
                var r := SData.region_at_tile((cx + 0.5) * GameState.COARSE / T)
                counts[r] = int(counts.get(r, 0)) + 1
    GameState.explorable = counts

# ====================================================================== tick
func _process(delta: float) -> void:
    var changed := false
    for r in SData.REGIONS:
        var cur: float = shown[r]
        var n := move_toward(cur, GameState.region_level(r), delta * 0.3)
        if n != cur:
            shown[r] = n
            changed = true
    if changed:
        _refresh_acc += delta
        if _refresh_acc > 0.06:
            _refresh_acc = 0.0
            refresh_all()
    var avg := 0.0
    for r in SData.REGIONS:
        avg += shown[r]
    avg /= 4.0
    _canvas_mod.color = Color(0.74, 0.77, 0.96).lerp(Color(1.0, 0.99, 0.96), clampf(avg * 1.3, 0.0, 1.0))
    for r in SData.REGIONS:
        particles[r].modulate.a = smoothstep(0.1, 0.9, shown[r]) * 0.9
        particles[r + "_ash"].modulate.a = (1.0 - shown[r]) * 0.45
    AudioManager.level = GameState.overall_level()
    for id in harmonies:
        if player != null:
            harmonies[id].update(delta, player.global_position)

func refresh_all() -> void:
    ground.queue_redraw()
    for o in objects.get_children():
        if o.has_method("refresh"):
            o.refresh()

## Snap all visuals to the current state (used by tests and the ending).
func snap_levels() -> void:
    for r in SData.REGIONS:
        shown[r] = GameState.region_level(r)
    refresh_all()

# ================================================================== services
func complete_feature(id: String) -> void:
    GameState.complete_feature(id)

func grant_petals(n: int, pos: Vector2) -> void:
    if n <= 0:
        return
    GameState.add_petals(n)
    AudioManager.play_note("A", "bell", -10.0)
    Fx.burst(fx, pos + Vector2(0, -24), SData.GOLD, 10 + n * 2, 60.0)
    GameState.toast.emit("+%d Echo Petal%s" % [n, "" if n == 1 else "s"], SData.GOLD)

func grant_fragment(pos: Vector2) -> void:
    var phrase: Array = GameState.add_fragment()
    get_tree().create_timer(0.9, false).timeout.connect(func(): AudioManager.play_melody(phrase, 0.3, "bell"))
    Fx.burst(fx, pos + Vector2(0, -40), SData.NOTE_COLOR["A"], 36, 120.0, 1.4)
    Fx.ring(fx, pos, SData.NOTE_COLOR["A"], 160.0, 1.2)
    GameState.toast.emit("Melody fragment recovered (%d/%d)" % [GameState.fragments, SData.FRAGMENTS_NEEDED], SData.NOTE_COLOR["A"])

func unlock_ability(a: String, pos: Vector2) -> void:
    GameState.unlock_ability(a)
    AudioManager.play_sfx("unlock")
    Fx.burst(fx, pos + Vector2(0, -40), SData.NOTE_COLOR[SData.ABILITY_NOTE[a]], 36, 120.0, 1.4)
    var texts := {
        "growth": "Press 1 to select it and Space to sing. Withered trees, thorn thickets and blighted ground will respond.",
        "resonance": "Press 2 to select it and Space to sing. Dormant pillars, sealed doors and hidden things will answer.",
        "flow": "Press 3 to select it and Space to sing. Dry basins, channels and riverbeds will fill with water.",
    }
    GameState.dialogue_requested.emit({"title": "You learned the %s Note" % SData.ABILITY_LABEL[a], "text": texts[a], "notes": [SData.ABILITY_NOTE[a]], "note_label": ""})

func grant_reward(reward: Dictionary, pos: Vector2) -> void:
    match reward.get("type", "none"):
        "musical_fragment":
            GameState.pending_fragment_sources = maxi(0, GameState.pending_fragment_sources - 1)
            grant_fragment(pos)
        "echo_petals":
            grant_petals(int(reward.get("amount", 1)), pos)
        "hint":
            var lines: Array = GameState.objective_lines()
            GameState.toast.emit("Hint: " + str(lines[1]).split("\n")[0], SData.GOLD)

func notify_fragments_missing() -> void:
    if director != null:
        director.request("fragments_missing", true)

func play_ending() -> void:
    if ending_started:
        return
    ending_started = true
    AudioManager.play_sfx("victory")
    var altar = get_obj("altar")
    for i in 6:
        get_tree().create_timer(0.35 * i, false).timeout.connect(func():
            if altar != null:
                Fx.burst(fx, altar.global_position + Vector2(randf_range(-60, 60), randf_range(-80, 0)), SData.GOLD, 30, 150.0, 1.6)
                Fx.ring(fx, altar.global_position, SData.NOTE_COLOR[SData.NOTES[i % 4]], 200.0 + 30.0 * i, 1.4))
    get_tree().create_timer(4.0, false).timeout.connect(func(): GameState.win())

## Valid, reachable, unblocked point near `origin` (deterministic if rng null).
func find_free_spot(origin: Vector2, rmin: float, rmax: float, rng: RandomNumberGenerator) -> Variant:
    var seen := grid.flood(origin)
    var cands: Array = []
    for ring in 3:
        var r := lerpf(rmin, rmax, float(ring) / 2.0)
        for k in 16:
            var p := origin + Vector2.from_angle(float(k) * TAU / 16.0 + float(ring) * 0.2) * r
            if p.x < 64.0 or p.y < 64.0 or p.x > SData.MAP_PX.x - 64.0 or p.y > SData.MAP_PX.y - 64.0:
                continue
            if grid.is_blocked(p) or not grid.reaches(seen, p, 8.0):
                continue
            var clear := true
            for o in get_tree().get_nodes_in_group("interactable"):
                if o.global_position.distance_to(p) < 50.0:
                    clear = false
                    break
            if clear:
                cands.append(p)
    if cands.is_empty():
        return null
    if rng == null:
        return cands[0]
    return cands[rng.randi_range(0, cands.size() - 1)]

func reveal_cache_near(pos: Vector2) -> String:
    var best = null
    var bd := 1e9
    for id in registry:
        var o = registry[id]
        if is_instance_valid(o) and o is Glimmer and o.concealed and not o.revealed:
            var d: float = o.global_position.distance_to(pos)
            if d < bd:
                bd = d
                best = o
    if best != null:
        best.force_reveal()
        return SData.dir_text(pos, best.global_position)
    var spot = find_free_spot(pos, 90.0, 150.0, null)
    if spot != null:
        add_obj(Glimmer, "cache_extra_%d" % registry.size(), spot / T, {"reward": {"type": "echo_petals", "amount": 3}})
        return SData.dir_text(pos, spot)
    return "nearby"

# ================================================================ event API
func active_event_count() -> int:
    for id in active_events.keys():
        if not is_instance_valid(active_events[id]):
            active_events.erase(id)
    return active_events.size()

func _register_event(spec: Dictionary, node: Node) -> void:
    active_events[spec["id"]] = node
    if spec["reward"]["type"] == "musical_fragment":
        GameState.pending_fragment_sources += 1

func event_finished(spec: Dictionary, _success: bool) -> void:
    active_events.erase(spec["id"])
    GameState.event_resolved.emit(spec)

func _announce(spec: Dictionary, tile: Vector2, text: String) -> void:
    var where := ""
    if player != null:
        where = SData.dir_text(player.global_position, tile * T)
    var msg := text.replace("%s", where)
    if spec.has("text") and spec["text"] != "":
        msg += "  " + str(spec["text"])
    GameState.toast.emit(msg, SData.GOLD)
    AudioManager.play_sfx("reveal")

func exec_reveal_shrine(spec: Dictionary) -> bool:
    var site: Dictionary = SData.SITES[spec["site_id"]]
    var o = add_obj(EventShrine, spec["id"], site["pos"], {"spec": spec})
    _register_event(spec, o)
    _announce(spec, site["pos"], "A hidden shrine has appeared %s!")
    return true

func exec_reveal_secret(spec: Dictionary) -> bool:
    var site: Dictionary = SData.SITES[spec["site_id"]]
    var o = add_obj(LumenCreature, spec["id"], site["pos"], {"spec": spec})
    _register_event(spec, o)
    _announce(spec, site["pos"], "A lumen creature drifts %s. It seems to want to tell you something.")
    return true

func exec_spawn_discovery(spec: Dictionary) -> bool:
    var site: Dictionary = SData.SITES[spec["site_id"]]
    var o = add_obj(Glimmer, spec["id"], site["pos"], {"spec": spec, "reward": spec["reward"].duplicate()})
    _register_event(spec, o)
    _announce(spec, site["pos"], "Something glimmers %s.")
    return true

func exec_spawn_chime_puzzle(spec: Dictionary) -> bool:
    var site: Dictionary = SData.SITES[spec["site_id"]]
    var center: Vector2 = site["pos"] * T
    var order: Array = spec["puzzle"]["glyphs"].duplicate()
    var hc := HarmonyController.new()
    hc.puzzle_id = spec["id"]
    hc.order = order
    hc.world = self
    hc.center = center
    hc.on_solved = func():
        GameState.complete_puzzle(spec["id"])
        grant_reward(spec["reward"], center)
        event_finished(spec, true)
    harmonies[spec["id"]] = hc
    var group := Node2D.new()
    for i in 3:
        var ang := -PI / 2.0 + float(i) * TAU / 3.0
        var pos: Vector2 = (center + Vector2.from_angle(ang) * 58.0) / T
        var c = add_obj(ChimeStone, "%s_c%d" % [spec["id"], i], pos, {"glyph": i, "controller": hc})
        hc.chimes.append(c)
    group.queue_free()
    _register_event(spec, hc.chimes[0])
    _announce(spec, site["pos"], "Three echoing chimes have risen %s. Listen to their order.")
    return true

func exec_heal_corruption(spec: Dictionary) -> bool:
    var patch = get_obj(spec["site_id"])
    if patch == null or patch.healed:
        return false
    patch.heal()
    grant_reward(spec["reward"], patch.global_position)
    _announce(spec, SData.SITES[spec["site_id"]]["pos"], "The blight has withered away %s as the land heals itself.")
    GameState.event_resolved.emit(spec)
    return true

func exec_open_route(spec: Dictionary) -> bool:
    var site: Dictionary = SData.SITES[spec["site_id"]]
    var gap: String = site["gap"]
    var row: float = (SData.GAPS[gap][0] + SData.GAPS[gap][1]) * 0.5 + 0.5
    var cx := SData.river_cx(row)
    var deck := BridgeDeck.new()
    deck.position = Vector2(cx, row) * T
    deck.from_p = Vector2(-3.3 * T, 0)
    deck.to_p = Vector2(3.3 * T, 0)
    deck.width = 76.0
    deck.style = "stone"
    deck.z_index = -10
    add_child(deck)
    var tw := create_tween()
    tw.tween_property(deck, "progress", 1.0, 2.6).set_trans(Tween.TRANS_SINE)
    tw.finished.connect(func():
        river.open_gap(gap)
        AudioManager.play_sfx("unlock"))
    _announce(spec, site["pos"], "Stones rise from the ravine %s: a new route is opening!")
    GameState.event_resolved.emit(spec)
    return true

func exec_simplify_puzzle(spec: Dictionary) -> bool:
    var target: String = spec["target_puzzle"]
    GameState.assist[target] = int(GameState.assist.get(target, 0)) + 1
    if harmonies.has(target):
        harmonies[target]._cd = 0.0
        harmonies[target].demo()
    if player != null:
        var w = add_obj(GuideWisp, "wisp_%s" % spec["id"], (player.global_position + Vector2(40, 0)) / T)
        w.position = player.global_position + Vector2(40, 0)
    GameState.toast.emit("A guide wisp joins you. Puzzles will be gentler for a while.", SData.GOLD)
    AudioManager.play_sfx("reveal")
    grant_reward(spec["reward"], player.global_position if player != null else Vector2.ZERO)
    GameState.event_resolved.emit(spec)
    return true

func exec_spawn_practice_target(spec: Dictionary) -> bool:
    var ab: String = spec["required_ability"]
    var origin: Vector2 = player.global_position if player != null else SData.START_TILE * T
    var spot = find_free_spot(origin, 80.0, 170.0, GameState.rng_director)
    if spot == null:
        return false
    var kind := {"growth": "sapling", "resonance": "rune", "flow": "pool"}[ab] as String
    var o = add_obj(AbilityTarget, spec["id"], spot / T, {"ability": ab, "kind": kind, "spec": spec, "reward_petals": int(spec["reward"]["amount"])})
    _register_event(spec, o)
    GameState.lesson_pending.erase(ab)
    GameState.toast.emit("A small %s has appeared. Press %d, then Space, to try your new note." % [{"sapling": "withered sapling", "rune": "dormant rune", "pool": "dry pool"}[kind], SData.ABILITIES.find(ab) + 1], SData.NOTE_COLOR[SData.ABILITY_NOTE[ab]])
    AudioManager.play_sfx("reveal")
    return true
