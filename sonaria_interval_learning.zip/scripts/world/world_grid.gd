class_name WorldGrid
extends RefCounted
## Coarse collision grid mirroring the physics solids. Used for real
## reachability tests (flood fill) so generated content is always reachable.

const CELL := 16
const INFLATE := 9.0       # player radius + margin
const DIRS := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]

var cols := int(SData.MAP_W * SData.TILE / CELL)
var rows := int(SData.MAP_H * SData.TILE / CELL)
var rects: Dictionary = {}
var blocked := PackedByteArray()
var version := 0
var _dirty := true

func add(id: String, rect: Rect2, enabled := true) -> void:
    rects[id] = {"rect": rect, "on": enabled}
    _dirty = true

func set_enabled(id: String, on: bool) -> void:
    if rects.has(id) and rects[id]["on"] != on:
        rects[id]["on"] = on
        _dirty = true

func ensure() -> void:
    if _dirty:
        rebuild()

func rebuild() -> void:
    blocked.resize(cols * rows)
    blocked.fill(0)
    for id in rects:
        var e: Dictionary = rects[id]
        if not e["on"]:
            continue
        var r: Rect2 = e["rect"].grow(INFLATE)
        var x0 := clampi(int(floor(r.position.x / CELL)), 0, cols - 1)
        var x1 := clampi(int(floor(r.end.x / CELL)), 0, cols - 1)
        var y0 := clampi(int(floor(r.position.y / CELL)), 0, rows - 1)
        var y1 := clampi(int(floor(r.end.y / CELL)), 0, rows - 1)
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                if r.has_point(Vector2((x + 0.5) * CELL, (y + 0.5) * CELL)):
                    blocked[y * cols + x] = 1
    _dirty = false
    version += 1

func cell_of(p: Vector2) -> Vector2i:
    return Vector2i(clampi(int(p.x / CELL), 0, cols - 1), clampi(int(p.y / CELL), 0, rows - 1))

func is_blocked(p: Vector2) -> bool:
    ensure()
    var c := cell_of(p)
    return blocked[c.y * cols + c.x] == 1

func nearest_free(p: Vector2, max_r := 8) -> Variant:
    ensure()
    var c := cell_of(p)
    if blocked[c.y * cols + c.x] == 0:
        return c
    for r in range(1, max_r + 1):
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if maxi(absi(dx), absi(dy)) != r:
                    continue
                var n := Vector2i(c.x + dx, c.y + dy)
                if n.x < 0 or n.y < 0 or n.x >= cols or n.y >= rows:
                    continue
                if blocked[n.y * cols + n.x] == 0:
                    return n
    return null

func flood(from: Vector2) -> PackedByteArray:
    ensure()
    var seen := PackedByteArray()
    seen.resize(cols * rows)
    seen.fill(0)
    var start = nearest_free(from)
    if start == null:
        return seen
    var queue := PackedInt32Array()
    queue.append(start.y * cols + start.x)
    seen[start.y * cols + start.x] = 1
    var head := 0
    while head < queue.size():
        var cur := queue[head]
        head += 1
        var cx := cur % cols
        @warning_ignore("integer_division")
        var cy := cur / cols
        for d in DIRS:
            var nx: int = cx + d.x
            var ny: int = cy + d.y
            if nx < 0 or ny < 0 or nx >= cols or ny >= rows:
                continue
            var ni := ny * cols + nx
            if seen[ni] == 0 and blocked[ni] == 0:
                seen[ni] = 1
                queue.append(ni)
    return seen

func reaches(seen: PackedByteArray, target: Vector2, radius: float) -> bool:
    var c := cell_of(target)
    var rc := int(ceil(radius / CELL))
    for dy in range(-rc, rc + 1):
        for dx in range(-rc, rc + 1):
            var n := Vector2i(c.x + dx, c.y + dy)
            if n.x < 0 or n.y < 0 or n.x >= cols or n.y >= rows:
                continue
            if Vector2(dx, dy).length() * CELL > radius:
                continue
            if seen[n.y * cols + n.x] == 1:
                return true
    return false
