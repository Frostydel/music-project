class_name Thicket
extends WorldObject
## Withered thorn wall blocking the glade's only exit. Growth makes it bloom
## and recede; its solid is then removed permanently.

var size_px := Vector2(64, 192)
var bloom := 0.0
var done := false
var _blobs: Array = []

func build() -> void:
    accepts_notes = true
    animated = true
    add_solid(Rect2(-size_px.x / 2.0, -size_px.y, size_px.x, size_px.y))
    var rng := RandomNumberGenerator.new()
    rng.seed = 77
    for i in 46:
        _blobs.append([Vector2(rng.randf_range(-size_px.x / 2.0 + 6.0, size_px.x / 2.0 - 6.0), rng.randf_range(-size_px.y + 6.0, -6.0)), rng.randf_range(9.0, 17.0), rng.randf()])

func note_radius() -> float:
    return 170.0

func on_note(a: String, _player) -> bool:
    if done or a != "growth":
        return false
    done = true
    var tw := create_tween()
    tw.tween_property(self, "bloom", 1.0, 2.0)
    tw.finished.connect(func(): set_solids_enabled(false))
    Fx.ring(world.fx, global_position + Vector2(0, -size_px.y / 2.0), SData.NOTE_COLOR["C"], 140.0, 1.0)
    for i in 4:
        Fx.burst(world.fx, global_position + Vector2(0, -20.0 - i * 45.0), SData.NOTE_COLOR["C"], 18, 90.0, 1.2)
    GameState.set_flag("thicket_cleared")
    world.complete_feature("thicket_cleared")
    GameState.toast.emit("The thicket blooms and parts. The path east is open!", SData.NOTE_COLOR["C"])
    return true

func _draw() -> void:
    var b := bloom
    for bl in _blobs:
        var p: Vector2 = bl[0]
        var r: float = bl[1] * (1.0 - 0.85 * b)
        var dead := Color("3b2650").lerp(Color("2b1d3c"), bl[2])
        var live := Color("2fbf9f").lerp(Color("7a5fd0"), bl[2])
        draw_circle(p, r, dead.lerp(live, b))
        if b < 0.6:
            var a := 1.0 - b
            draw_colored_polygon(PackedVector2Array([p + Vector2(-4, -r), p + Vector2(0, -r - 8.0), p + Vector2(4, -r)]), Color(0.5, 0.3, 0.6, a))
            draw_colored_polygon(PackedVector2Array([p + Vector2(r, -4), p + Vector2(r + 8.0, 0), p + Vector2(r, 4)]), Color(0.5, 0.3, 0.6, a))
        if b > 0.3:
            Art.glow(self, p + Vector2(0, -r), 9.0, SData.GOLD, (b - 0.3) * 1.1)
