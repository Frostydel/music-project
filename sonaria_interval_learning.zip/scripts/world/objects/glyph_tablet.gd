class_name GlyphTablet
extends WorldObject
## Tablet of the Old Choir: reveals one note of the Resonance Shrine's melody.

var index := 0
var note := "C"

func build() -> void:
    interactable = true
    animated = true
    add_solid(Rect2(-14, -6, 28, 8))

func known() -> bool:
    return GameState.has_flag("tablet_%d" % index)

func prompt() -> String:
    return "Read the tablet" if not known() else "Read the tablet again"

func interact(_player) -> void:
    var first := not known()
    GameState.set_flag("tablet_%d" % index)
    AudioManager.play_note(note, "bell", -4.0)
    Fx.ring(world.fx, global_position + Vector2(0, -26), SData.NOTE_COLOR[note], 80.0, 0.8)
    var n_known := 0
    for i in 4:
        if GameState.has_flag("tablet_%d" % i):
            n_known += 1
    var text := "Verse %s of the Old Choir. The tablet sings a single note and the crystal above it glows. The shrine in the ruins will want all four verses, in order (%d of 4 read)." % [SData.ROMAN[index], n_known]
    GameState.dialogue_requested.emit({"title": "Tablet of the Old Choir - Verse %s" % SData.ROMAN[index], "text": text, "notes": [note], "note_label": SData.ROMAN[index]})
    if first and n_known == 4:
        GameState.toast.emit("All four verses found. Take them to the Resonance Shrine.", SData.GOLD)

func _draw() -> void:
    var lv := level()
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, lv)
    draw_colored_polygon(PackedVector2Array([Vector2(-14, 0), Vector2(-12, -34), Vector2(0, -40), Vector2(12, -34), Vector2(14, 0)]), st)
    var c: Color = SData.NOTE_COLOR[note]
    var kn := known()
    Art.crystal(self, Vector2(0, -22), 10.0, 5.0, c if kn else Color(0.35, 0.33, 0.45))
    draw_string(ThemeDB.fallback_font, Vector2(-12, -2), SData.ROMAN[index], HORIZONTAL_ALIGNMENT_CENTER, 24.0, 11, Color(0.85, 0.82, 1.0, 0.9))
    if kn:
        Art.glow(self, Vector2(0, -22), 24.0, c, 0.5)
    draw_marker(-58.0)
