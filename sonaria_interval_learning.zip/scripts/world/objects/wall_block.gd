class_name WallBlock
extends WorldObject
## Solid rectangle. Origin = bottom-centre. Styles: "invisible" (trees drawn
## separately), "ruin" (brick wall), "pillar" (broken column).

var size_px := Vector2(64, 32)
var style := "invisible"
var _bricks: Array = []

func build() -> void:
    add_solid(Rect2(-size_px.x / 2.0, -size_px.y, size_px.x, size_px.y))
    if style == "ruin":
        var rng := RandomNumberGenerator.new()
        rng.seed = int(position.x * 7.0 + position.y)
        for i in int(size_px.x / 12.0) * int(size_px.y / 10.0):
            _bricks.append(rng.randf())
    if style == "invisible":
        set_process(false)

func _draw() -> void:
    var lv := level()
    var stone := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, lv)
    if style == "ruin":
        var r := Rect2(-size_px.x / 2.0, -size_px.y, size_px.x, size_px.y)
        draw_rect(r, stone.darkened(0.25))
        var cols := int(size_px.x / 12.0)
        for i in _bricks.size():
            var bx := r.position.x + float(i % maxi(cols, 1)) * 12.0
            var by := r.position.y + float(i / maxi(cols, 1)) * 10.0
            draw_rect(Rect2(bx + 1, by + 1, 10, 8), stone.lerp(stone.lightened(0.15), _bricks[i]))
        if lv > 0.3:
            draw_rect(Rect2(r.position.x, r.position.y - 3.0, r.size.x, 5.0), Color(0.2, 0.75, 0.55, (lv - 0.3)))
    elif style == "pillar":
        var w := size_px.x
        draw_colored_polygon(PackedVector2Array([Vector2(-w / 2.0, 0), Vector2(-w / 2.0 + 2, -size_px.y), Vector2(w / 2.0 - 4, -size_px.y + 10), Vector2(w / 2.0, 0)]), stone)
        draw_rect(Rect2(-w / 2.0 - 3, -8, w + 6, 8), stone.darkened(0.2))
        draw_line(Vector2(-2, -size_px.y + 6), Vector2(2, -size_px.y * 0.5), stone.darkened(0.4), 1.5)
        if lv > 0.5:
            Art.glow(self, Vector2(0, -size_px.y * 0.6), 10.0, SData.TEAL, (lv - 0.5) * 1.4)
