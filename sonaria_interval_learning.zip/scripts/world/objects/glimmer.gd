class_name Glimmer
extends WorldObject
## Collectible discovery. If `concealed`, it only appears when Resonance is sung
## nearby ("reveals concealed objects"). Also used by Director discovery events.

var reward: Dictionary = {"type": "echo_petals", "amount": 3}
var concealed := false
var revealed := true
var spec: Dictionary = {}
var _fade := 1.0

func build() -> void:
    interactable = true
    animated = true
    if concealed:
        revealed = false
        _fade = 0.0
        accepts_notes = true

func can_interact() -> bool:
    return revealed and _fade > 0.6

func note_radius() -> float:
    return 170.0

func prompt() -> String:
    return "Collect the glimmer"

func on_note(a: String, _player) -> bool:
    if concealed and not revealed and a == "resonance":
        revealed = true
        create_tween().tween_property(self, "_fade", 1.0, 1.2)
        Fx.ring(world.fx, global_position, SData.NOTE_COLOR["E"], 90.0, 0.8)
        Fx.burst(world.fx, global_position + Vector2(0, -10), SData.NOTE_COLOR["E"], 16, 60.0)
        GameState.toast.emit("Your note reveals something concealed!", SData.NOTE_COLOR["E"])
        return true
    return false

func force_reveal() -> void:
    if concealed and not revealed:
        revealed = true
        create_tween().tween_property(self, "_fade", 1.0, 1.2)

func interact(_player) -> void:
    if not can_interact():
        return
    revealed = false
    world.grant_reward(reward, global_position)
    if not spec.is_empty():
        world.event_finished(spec, true)
    queue_free()

func _draw() -> void:
    if _fade <= 0.01:
        return
    var bob := sin(_t * 2.5) * 4.0
    var c := SData.GOLD if reward.get("type", "") != "musical_fragment" else SData.NOTE_COLOR["A"]
    Art.glow(self, Vector2(0, -16 + bob), 26.0, c, _fade * 0.9)
    Art.star(self, Vector2(0, -16 + bob), 8.0, Color(c.r, c.g, c.b, _fade), 4)
    draw_circle(Vector2(0, -16 + bob), 2.5, Color(1, 1, 1, _fade))
    draw_marker(-46.0)
