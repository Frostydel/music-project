class_name SiltBarrier
extends WorldObject
## Silt mound that fills the corridor to the sanctum until flooded.

var size_px := Vector2(64, 160)
var c := 0.0
var done := false

func build() -> void:
    animated = true
    add_solid(Rect2(-size_px.x / 2.0, -size_px.y, size_px.x, size_px.y))

func collapse() -> void:
    if done:
        return
    done = true
    var tw := create_tween()
    tw.tween_property(self, "c", 1.0, 2.2)
    tw.finished.connect(func():
        set_solids_enabled(false)
        world.complete_feature("silt_cleared")
        AudioManager.play_sfx("unlock")
        GameState.toast.emit("The silt washes away. The corridor is clear.", SData.NOTE_COLOR["G"]))
    Fx.burst(world.fx, global_position + Vector2(0, -60), Color("c9b48a"), 30, 90.0, 1.4)

func _draw() -> void:
    var k := 1.0 - c
    if k <= 0.01:
        return
    var sand := Color("8a7a63").lerp(Color("2a6f8a"), c)
    for i in 6:
        var y := -size_px.y + 10.0 + i * 26.0
        draw_circle(Vector2(sin(i * 2.1) * 12.0, y), 30.0 * k, sand.darkened(0.15 * (i % 2)))
    draw_rect(Rect2(-size_px.x / 2.0, -size_px.y * k, size_px.x, size_px.y * k), sand.darkened(0.1))
