class_name BlightPatch
extends WorldObject
## Corrupted patch of ground. Healed by Growth, or by a Director
## "corruption_shift" event once its region has been restored.

var healed := false
var heal_t := 0.0
var _thorns: Array = []

func build() -> void:
    accepts_notes = true
    animated = true
    z_index = -10
    var rng := RandomNumberGenerator.new()
    rng.seed = int(position.x * 13.0 + position.y)
    for i in 14:
        _thorns.append([Vector2(rng.randf_range(-36, 36), rng.randf_range(-20, 20)), rng.randf_range(5.0, 13.0), rng.randf()])
    GameState.register_feature(object_id, region, 0.5, false)
    if GameState.has_flag("healed_" + object_id):
        healed = true
        heal_t = 1.0

func note_radius() -> float:
    return 100.0

func on_note(a: String, _player) -> bool:
    if healed or a != "growth":
        return false
    heal()
    return true

func heal() -> void:
    if healed:
        return
    healed = true
    GameState.set_flag("healed_" + object_id)
    create_tween().tween_property(self, "heal_t", 1.0, 1.6)
    Fx.burst(world.fx, global_position + Vector2(0, -10), SData.NOTE_COLOR["C"], 22, 70.0, 1.2)
    Fx.ring(world.fx, global_position, SData.NOTE_COLOR["C"], 70.0, 0.9)
    world.complete_feature(object_id)
    world.grant_petals(1, global_position)

func _draw() -> void:
    var h := heal_t
    draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 0.6))
    draw_circle(Vector2.ZERO, 40.0, SData.BLIGHT.lerp(Color(0.12, 0.3, 0.3), h))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    for t in _thorns:
        var p: Vector2 = t[0]
        var r: float = t[1] * (1.0 - h * 0.9)
        if r > 0.8:
            draw_colored_polygon(PackedVector2Array([p + Vector2(-3, 0), p + Vector2(0, -r * 2.0), p + Vector2(3, 0)]), Color("5a2d70"))
        if h > 0.1:
            var col := SData.NOTE_COLOR["C"].lerp(SData.NOTE_COLOR["E"], t[2])
            Art.glow(self, p + Vector2(0, -4), 9.0, col, h * (0.7 + 0.3 * sin(_t * 2.0 + t[2] * 9.0)))
            draw_circle(p + Vector2(0, -4), 2.5, Color(1, 0.95, 0.8, h))
