class_name AwakeningStone
extends WorldObject
## Tutorial puzzle 1 (Repeat the Melody). Rewards the Growth Note + fragment.

var glow := 0.0

func build() -> void:
    interactable = true
    animated = true
    add_solid(Rect2(-14, -8, 28, 12))
    if GameState.puzzles_done.has("awakening"):
        glow = 1.0

func prompt() -> String:
    return "Listen to the stone" if glow < 1.0 else "Touch the stone"

func interact(_player) -> void:
    if GameState.puzzles_done.has("awakening"):
        GameState.dialogue_requested.emit({"title": "Awakening Stone", "text": "The stone hums the Growth Note, warm and steady. Withered things nearby seem to lean toward the sound."})
        return
    var spec: Dictionary = GameState.puzzle_specs["awakening"]
    GameState.puzzle_requested.emit({
        "id": "awakening", "kind": "melody", "title": "The Awakening Stone",
        "subtitle": "Ear-training goal: hear a major third (C→E, a warm 4-step rise) and perfect fifth (C→G, a clear 7-step rise). Listen, then sing the pattern back.",
        "notes": spec["notes"], "alphabet": spec["alphabet"], "on_success": _on_solved,
    })

func _on_solved() -> void:
    GameState.complete_puzzle("awakening")
    create_tween().tween_property(self, "glow", 1.0, 1.5)
    world.complete_feature("stone_awakened")
    world.unlock_ability("growth", global_position)
    world.grant_fragment(global_position)

func _draw() -> void:
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, glow)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 0.5))
    draw_arc(Vector2.ZERO, 40.0, 0.0, TAU, 40, Color(0.4, 0.35, 0.6).lerp(SData.NOTE_COLOR["C"], glow), 2.5)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    draw_colored_polygon(PackedVector2Array([Vector2(-16, 0), Vector2(-12, -46), Vector2(0, -60), Vector2(12, -46), Vector2(16, 0)]), st)
    var rc := Color(0.45, 0.4, 0.65).lerp(SData.NOTE_COLOR["C"], glow)
    draw_arc(Vector2(0, -32), 8.0, 0.0, TAU, 18, rc, 2.0)
    draw_line(Vector2(0, -44), Vector2(0, -20), rc, 2.0)
    draw_line(Vector2(-6, -28), Vector2(6, -36), rc, 2.0)
    if glow > 0.02:
        Art.glow(self, Vector2(0, -32), 46.0, SData.NOTE_COLOR["C"], glow * (0.7 + 0.2 * sin(_t * 2.5)))
    else:
        Art.glow(self, Vector2(0, -32), 20.0, SData.VIOLET, 0.25 + 0.15 * sin(_t * 2.0))
    draw_marker(-72.0)
