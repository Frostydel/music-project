class_name HeartAltar
extends WorldObject
## Final puzzle: replay the Main Melody assembled from all collected fragments.

var glow := 0.0

func build() -> void:
    interactable = true
    animated = true
    add_solid(Rect2(-22, -10, 44, 14))

func prompt() -> String:
    return "Approach the Heart Altar"

func interact(_player) -> void:
    if GameState.fragments < SData.FRAGMENTS_NEEDED:
        GameState.dialogue_requested.emit({"title": "The Heart Altar", "text": "The altar waits for the Main Melody, eight notes woven from the world's lost fragments. It holds %d of the %d fragments it needs. Explore: hidden shrines, creatures and discoveries will reveal themselves." % [GameState.fragments, SData.FRAGMENTS_NEEDED]})
        world.notify_fragments_missing()
        return
    var spec: Dictionary = GameState.puzzle_specs["altar"]
    GameState.puzzle_requested.emit({
        "id": "altar", "kind": "final", "title": "The Heart Altar",
        "subtitle": "Sing the 8-note Main Melody. Hear the major third (C→E, 4 semitones) and perfect fifth (C→G, 7 semitones) as the fragments return.",
        "notes": spec["notes"], "alphabet": spec["alphabet"], "on_success": _on_solved,
    })

func _on_solved() -> void:
    GameState.complete_puzzle("altar")
    create_tween().tween_property(self, "glow", 1.0, 3.0)
    world.complete_feature("altar_sung")
    world.play_ending()

func _draw() -> void:
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, maxf(glow, level()))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 0.5))
    for i in 3:
        draw_arc(Vector2.ZERO, 70.0 - i * 14.0, 0.0, TAU, 48, Color(0.4, 0.35, 0.6).lerp(SData.GOLD, glow), 2.0)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    draw_colored_polygon(PackedVector2Array([Vector2(-26, 0), Vector2(-20, -24), Vector2(20, -24), Vector2(26, 0)]), st.darkened(0.1))
    draw_rect(Rect2(-18, -32, 36, 8), st)
    for i in SData.FRAGMENTS_NEEDED:
        var on: bool = i < GameState.fragments
        Art.crystal(self, Vector2(-21.0 + i * 14.0, -44), 8.0, 4.0, SData.GOLD if on else Color(0.3, 0.28, 0.4))
    Art.glow(self, Vector2(0, -40), 60.0, SData.GOLD, 0.15 + glow * 0.8)
    draw_marker(-84.0)
