class_name ResonanceShrine
extends WorldObject
## Puzzle type 3: the Resonance Shrine. The melody is only known through the
## four tablets scattered across the world.

const WHERE := ["the grove's south-west clearing", "the east bank south of the bridge landing", "the ruins' north courtyard", "the ruins' south courtyard"]
var glow := 0.0

func build() -> void:
    interactable = true
    animated = true
    add_solid(Rect2(-16, -8, 32, 12))
    if GameState.puzzles_done.has("shrine"):
        glow = 1.0

func prompt() -> String:
    return "Approach the shrine" if glow < 1.0 else "Touch the shrine"

func interact(_player) -> void:
    if GameState.puzzles_done.has("shrine"):
        GameState.dialogue_requested.emit({"title": "Resonance Shrine", "text": "The shrine resonates with the Resonance Note. Dormant mechanisms nearby may answer it."})
        return
    var spec: Dictionary = GameState.puzzle_specs["shrine"]
    var clues: Array = []
    for i in spec["notes"].size():
        var known: bool = GameState.has_flag("tablet_%d" % i)
        clues.append({"index": i, "known": known, "note": spec["notes"][i] if known else "", "where": WHERE[i]})
    GameState.puzzle_requested.emit({
        "id": "shrine", "kind": "shrine", "title": "The Resonance Shrine",
        "subtitle": "Four verses of the Old Choir are carved on tablets around the world. Enter their notes in order.",
        "notes": spec["notes"], "alphabet": spec["alphabet"], "clues": clues, "on_success": _on_solved,
    })

func _on_solved() -> void:
    GameState.complete_puzzle("shrine")
    create_tween().tween_property(self, "glow", 1.0, 1.5)
    world.complete_feature("shrine_resonated")
    world.unlock_ability("resonance", global_position)
    world.grant_fragment(global_position)

func _draw() -> void:
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, maxf(glow, level()))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 0.5))
    draw_arc(Vector2.ZERO, 52.0, 0.0, TAU, 40, Color(0.4, 0.35, 0.6).lerp(SData.NOTE_COLOR["E"], glow), 2.5)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    draw_colored_polygon(PackedVector2Array([Vector2(-18, 0), Vector2(-14, -22), Vector2(14, -22), Vector2(18, 0)]), st.darkened(0.15))
    draw_colored_polygon(PackedVector2Array([Vector2(-10, -22), Vector2(-7, -58), Vector2(7, -58), Vector2(10, -22)]), st)
    for i in 4:
        var kn: bool = GameState.has_flag("tablet_%d" % i)
        var c: Color = SData.NOTE_COLOR[SData.NOTES[i]]
        draw_circle(Vector2(-9.0 + i * 6.0, -48), 2.2, c if (kn or glow > 0.5) else Color(0.35, 0.33, 0.45))
    Art.crystal(self, Vector2(0, -72), 13.0, 7.0, SData.NOTE_COLOR["E"].darkened(0.5 - 0.5 * glow))
    Art.glow(self, Vector2(0, -72), 36.0, SData.NOTE_COLOR["E"], 0.2 + glow * 0.7)
    draw_marker(-92.0)
