class_name LumenCreature
extends WorldObject
## Director event: a musical creature that reveals a secret.

var spec: Dictionary = {}
var home := Vector2.ZERO
var spoken := false
var _fade := 0.0

func build() -> void:
    interactable = true
    animated = true
    home = position
    z_index = 5
    create_tween().tween_property(self, "_fade", 1.0, 1.2)

func can_interact() -> bool:
    return not spoken and _fade > 0.7

func prompt() -> String:
    return "Listen to the lumen"

func _process(delta: float) -> void:
    super._process(delta)
    var a := _t * 0.7
    position = home + Vector2(cos(a), sin(a * 1.3)) * 34.0

func interact(_player) -> void:
    if spoken:
        return
    spoken = true
    AudioManager.play_melody(["E", "G", "A", "G"], 0.16, "chime")
    var secret: String = spec.get("secret", "objective_hint")
    var text := ""
    if secret == "hidden_cache":
        var where: String = world.reveal_cache_near(global_position)
        text = "The lumen trills a bright little tune and flits in a circle. Something glimmers %s." % where
    else:
        var lines: Array = GameState.objective_lines()
        text = "The lumen hums a tune you almost understand. It means: \"%s\"" % lines[1].split("\n")[0]
    GameState.dialogue_requested.emit({"title": "Lumen Creature", "text": text})
    world.grant_reward(spec["reward"], global_position)
    world.event_finished(spec, true)
    var tw := create_tween()
    tw.tween_interval(2.5)
    tw.tween_property(self, "_fade", 0.0, 1.5)
    tw.finished.connect(queue_free)

func _draw() -> void:
    if _fade <= 0.01:
        return
    var bob := sin(_t * 3.0) * 4.0
    var c := SData.TEAL.lerp(SData.VIOLET, 0.5 + 0.5 * sin(_t))
    Art.glow(self, Vector2(0, -26 + bob), 30.0, c, _fade)
    draw_circle(Vector2(0, -26 + bob), 9.0, Color(c.r, c.g, c.b, _fade))
    draw_circle(Vector2(-3, -28 + bob), 2.0, Color(0.05, 0.05, 0.15, _fade))
    draw_circle(Vector2(3, -28 + bob), 2.0, Color(0.05, 0.05, 0.15, _fade))
    for i in 3:
        var ang := _t * 2.0 + i * 2.1
        Art.glow(self, Vector2(cos(ang) * 14.0, -26 + bob + sin(ang) * 6.0), 5.0, c, _fade * 0.8)
    draw_marker(-58.0)
