class_name Aqueduct
extends WorldObject
## Dry stone channel in the ruins. Flow floods it; the current washes away the
## silt barrier blocking the corridor to the Heart Sanctum.

const PTS := [Vector2(-96, 0), Vector2(96, 0), Vector2(96, 22)]
var flow := 0.0
var done := false

func build() -> void:
    accepts_notes = true
    animated = true

func note_radius() -> float:
    return 150.0

func on_note(a: String, _player) -> bool:
    if done or a != "flow":
        return false
    done = true
    var tw := create_tween()
    tw.tween_property(self, "flow", 1.0, 2.0)
    tw.finished.connect(func():
        var silt = world.get_obj("silt")
        if silt != null:
            silt.collapse())
    world.complete_feature("aqueduct_flowing")
    var c: Color = SData.NOTE_COLOR["G"]
    Fx.ring(world.fx, global_position, c, 160.0, 1.2)
    GameState.toast.emit("Water rushes down the aqueduct toward the silt barrier!", c)
    return true

func _draw() -> void:
    var lv := level()
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, lv)
    for i in range(PTS.size() - 1):
        Art.thick_line(self, PTS[i], PTS[i + 1], 20.0, st.darkened(0.3))
        Art.thick_line(self, PTS[i], PTS[i + 1], 12.0, Color("0a0814"))
    if flow > 0.0:
        var total := 0.0
        for i in range(PTS.size() - 1):
            total += PTS[i].distance_to(PTS[i + 1])
        var remain := total * flow
        for i in range(PTS.size() - 1):
            var seg: float = PTS[i].distance_to(PTS[i + 1])
            var use: float = minf(seg, remain)
            if use <= 0.0:
                break
            var e: Vector2 = PTS[i].lerp(PTS[i + 1], use / seg)
            Art.thick_line(self, PTS[i], e, 10.0, Color("2fc4c0"))
            draw_line(PTS[i], e, Color(0.8, 1, 1, 0.35 + 0.2 * sin(_t * 6.0)), 3.0)
            remain -= use
        Art.glow(self, PTS[2], 24.0, SData.NOTE_COLOR["G"], flow * 0.6)
