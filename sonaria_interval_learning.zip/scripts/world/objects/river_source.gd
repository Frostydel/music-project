class_name RiverSource
extends WorldObject
## Dry stone basin at the head of the ravine. Flow makes the river run.

var filled := 0.0
var done := false

func build() -> void:
    accepts_notes = true
    animated = true
    add_solid(Rect2(-22, -10, 44, 14))

func note_radius() -> float:
    return 150.0

func on_note(a: String, _player) -> bool:
    if done or a != "flow":
        return false
    done = true
    create_tween().tween_property(self, "filled", 1.0, 1.8)
    world.river.start_flow()
    world.complete_feature("river_flowing")
    var c: Color = SData.NOTE_COLOR["G"]
    Fx.ring(world.fx, global_position, c, 170.0, 1.2)
    Fx.burst(world.fx, global_position + Vector2(0, -10), c, 28, 100.0, 1.2)
    GameState.toast.emit("Water surges from the source — the river lives again!", c)
    return true

func _draw() -> void:
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, filled)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 0.5))
    draw_circle(Vector2.ZERO, 30.0, st.darkened(0.3))
    draw_circle(Vector2.ZERO, 24.0, Color("0a0814"))
    draw_circle(Vector2.ZERO, 24.0 * filled, Color("2fc4c0"))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    if filled > 0.05:
        Art.glow(self, Vector2(0, -6), 34.0, SData.NOTE_COLOR["G"], filled * 0.7)
    else:
        draw_line(Vector2(-12, -2), Vector2(10, 4), Color("3a2a58"), 1.5)
