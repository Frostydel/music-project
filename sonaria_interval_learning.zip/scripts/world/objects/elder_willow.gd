class_name ElderWillow
extends WorldObject
## Dead willow on the ravine's west bank. Growth grows a living-wood bridge.

const DECK_FROM := Vector2(22, -42)
const DECK_TO := Vector2(236, -42)

var bloom := 0.0
var grown := false
var deck: BridgeDeck

func build() -> void:
    accepts_notes = true
    animated = true
    add_solid(Rect2(-12, -8, 24, 10))
    deck = BridgeDeck.new()
    deck.from_p = DECK_FROM
    deck.to_p = DECK_TO
    deck.width = 74.0
    deck.z_index = -10
    add_child(deck)

func note_radius() -> float:
    return 170.0

func on_note(a: String, _player) -> bool:
    if grown or a != "growth":
        return false
    grown = true
    create_tween().tween_property(self, "bloom", 1.0, 2.0)
    var tw := create_tween()
    tw.tween_property(deck, "progress", 1.0, 2.8).set_trans(Tween.TRANS_SINE)
    tw.finished.connect(func():
        world.river.open_gap("main")
        GameState.set_flag("bridge_grown")
        world.complete_feature("willow_bridge")
        AudioManager.play_sfx("unlock")
        GameState.toast.emit("The willow has bridged the ravine!", SData.NOTE_COLOR["C"]))
    Fx.ring(world.fx, global_position + Vector2(0, -30), SData.NOTE_COLOR["C"], 150.0, 1.0)
    Fx.burst(world.fx, global_position + Vector2(40, -40), SData.NOTE_COLOR["C"], 30, 110.0, 1.4)
    return true

func _draw() -> void:
    var b := bloom
    var trunk := SData.TRUNK_DEAD.lerp(SData.TRUNK_ALIVE, b)
    draw_colored_polygon(PackedVector2Array([Vector2(-14, 0), Vector2(-7, -60), Vector2(7, -60), Vector2(14, 0)]), trunk)
    for br in [Vector2(-40, -92), Vector2(38, -96), Vector2(-14, -108), Vector2(18, -112)]:
        draw_line(Vector2(0, -56), br, trunk.lightened(0.1), 5.0)
        for j in 5:
            var sx: float = br.x + (j - 2) * 7.0
            var hang := 28.0 + 10.0 * b
            var col := Color("4b4760").lerp(Color("2fbf9f"), b)
            draw_line(Vector2(sx, br.y), Vector2(sx + sin(_t * 1.2 + j) * 3.0 * b, br.y + hang), col, 2.0)
    if b > 0.05:
        Art.glow(self, Vector2(0, -90), 70.0, SData.NOTE_COLOR["C"], b * 0.6)
