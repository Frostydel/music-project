class_name TreeProp
extends WorldObject
## Tree that is bare/withered in dead regions and lush when restored.

var solid := true
var scale_k := 1.0
var variant := 0.0
var sway := true
var _phase := 0.0

func build() -> void:
    _phase = variant * 20.0
    if solid:
        add_solid(Rect2(-7, -8, 14, 10))
    if not sway:
        set_process(false)

func _process(delta: float) -> void:
    _t += delta
    rotation = sin(_t * 0.8 + _phase) * 0.012 * (0.4 + level())

func _draw() -> void:
    var lv := level()
    var k := scale_k
    var trunk := SData.TRUNK_DEAD.lerp(SData.TRUNK_ALIVE, lv)
    draw_colored_polygon(PackedVector2Array([Vector2(-5, 0) * k, Vector2(-3, -34) * k, Vector2(3, -34) * k, Vector2(5, 0) * k]), trunk)
    var bc := trunk.lightened(0.1)
    for b in [[Vector2(0, -30), Vector2(-17, -50)], [Vector2(0, -32), Vector2(15, -54)], [Vector2(0, -36), Vector2(-2, -64)], [Vector2(-8, -42), Vector2(-20, -42)]]:
        draw_line(b[0] * k, b[1] * k, bc, 2.5 * k)
    var ck := smoothstep(0.05, 0.7, lv)
    if ck > 0.02:
        var base := SData.CANOPY_ALIVE_A.lerp(SData.CANOPY_ALIVE_B, variant)
        var col := SData.CANOPY_DEAD.lerp(base, lv)
        for c in [[Vector2(0, -52), 20.0], [Vector2(-14, -44), 14.0], [Vector2(14, -46), 15.0], [Vector2(0, -64), 13.0]]:
            draw_circle(c[0] * k, c[1] * k * ck, col)
        for c in [[Vector2(-4, -58), 9.0], [Vector2(10, -50), 7.0]]:
            draw_circle(c[0] * k, c[1] * k * ck, col.lightened(0.18))
        if lv > 0.6:
            var a := (lv - 0.6) * 2.5
            for q in [Vector2(-10, -50), Vector2(8, -58), Vector2(14, -42), Vector2(-2, -66)]:
                Art.glow(self, q * k, 7.0, SData.GOLD, a * (0.6 + 0.4 * sin(_t * 2.0 + q.x)))
    else:
        for q in [Vector2(-17, -50), Vector2(15, -54), Vector2(-2, -64)]:
            draw_circle(q * k, 2.0, SData.CANOPY_DEAD)
