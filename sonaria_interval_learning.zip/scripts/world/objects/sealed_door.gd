class_name SealedDoor
extends WorldObject
## Ancient door to the Heart Sanctum. Needs both pillars awake, then Resonance.

var size_px := Vector2(32, 96)
var open_t := 0.0
var opened := false

func build() -> void:
    accepts_notes = true
    animated = true
    add_solid(Rect2(-size_px.x / 2.0, -size_px.y, size_px.x, size_px.y))

func note_radius() -> float:
    return 170.0

func on_note(a: String, _player) -> bool:
    if opened or a != "resonance":
        return false
    if not (GameState.feature_done("pillar_1") and GameState.feature_done("pillar_2")):
        Fx.ring(world.fx, global_position + Vector2(0, -48), SData.NOTE_COLOR["E"], 70.0, 0.6)
        GameState.toast.emit("The door hums faintly... the two pillars outside are still dormant.", SData.NOTE_COLOR["E"])
        return true
    opened = true
    var tw := create_tween()
    tw.tween_property(self, "open_t", 1.0, 2.2)
    tw.finished.connect(func():
        set_solids_enabled(false)
        GameState.set_flag("door_open")
        world.complete_feature("door_open")
        AudioManager.play_sfx("unlock")
        GameState.toast.emit("The sealed door grinds open. The Heart Sanctum awaits.", SData.NOTE_COLOR["E"]))
    Fx.ring(world.fx, global_position + Vector2(0, -48), SData.NOTE_COLOR["E"], 160.0, 1.1)
    return true

func _draw() -> void:
    var k := 1.0 - open_t
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, level()).darkened(0.1)
    var h := size_px.y * k
    if h > 1.0:
        draw_rect(Rect2(-size_px.x / 2.0, -h, size_px.x, h), st)
        var rc := Color(0.4, 0.35, 0.55)
        var both: bool = GameState.feature_done("pillar_1") and GameState.feature_done("pillar_2")
        if both:
            rc = SData.NOTE_COLOR["E"]
        draw_arc(Vector2(0, -h * 0.55), 9.0, 0.0, TAU, 18, rc, 2.5)
        draw_line(Vector2(0, -h * 0.55 - 14.0), Vector2(0, -h * 0.55 + 14.0), rc, 2.5)
        if both:
            Art.glow(self, Vector2(0, -h * 0.55), 34.0, SData.NOTE_COLOR["E"], 0.6 * k)
    draw_rect(Rect2(-size_px.x / 2.0 - 5.0, -size_px.y - 6.0, 6.0, size_px.y + 6.0), st.lightened(0.1))
    draw_rect(Rect2(size_px.x / 2.0 - 1.0, -size_px.y - 6.0, 6.0, size_px.y + 6.0), st.lightened(0.1))
