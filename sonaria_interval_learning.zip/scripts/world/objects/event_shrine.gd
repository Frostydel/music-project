class_name EventShrine
extends WorldObject
## Director event: a hidden shrine appears. Optionally sealed by an ability
## (vines / runes / dry pool). Solving its melody pays the event reward.

var spec: Dictionary = {}
var reveal := 0.0
var locked := false
var done := false
var glow := 0.0

func build() -> void:
    interactable = true
    accepts_notes = true
    animated = true
    add_solid(Rect2(-14, -8, 28, 12))
    locked = spec.get("required_ability", "none") != "none"
    create_tween().tween_property(self, "reveal", 1.0, 2.0)

func can_interact() -> bool:
    return reveal > 0.85 and not done

func note_radius() -> float:
    return 150.0

func prompt() -> String:
    return "Examine the sealed shrine" if locked else "Listen to the shrine"

func on_note(a: String, _player) -> bool:
    if locked and a == spec.get("required_ability", ""):
        locked = false
        var c: Color = SData.NOTE_COLOR[SData.ABILITY_NOTE[a]]
        Fx.ring(world.fx, global_position + Vector2(0, -30), c, 120.0, 0.9)
        Fx.burst(world.fx, global_position + Vector2(0, -30), c, 22, 90.0)
        GameState.toast.emit("The seal dissolves. The shrine is listening.", c)
        return true
    return false

func _seal_name() -> String:
    match spec.get("required_ability", "none"):
        "growth": return "choked by thorny vines"
        "resonance": return "locked by dormant runes"
        "flow": return "buried under a dry pool"
    return ""

func interact(_player) -> void:
    if locked:
        var a: String = spec["required_ability"]
        GameState.dialogue_requested.emit({"title": "Sealed Shrine", "text": "The shrine is %s. Select the %s Note (%s) and sing it beside the shrine." % [_seal_name(), SData.ABILITY_LABEL[a], str(SData.ABILITIES.find(a) + 1)]})
        return
    var pz: Dictionary = spec["puzzle"]
    GameState.puzzle_requested.emit({
        "id": spec["id"], "kind": "melody", "title": "Hidden Shrine",
        "subtitle": "A small shrine hums a melody. Listen, then sing it back.",
        "notes": pz["notes"], "alphabet": pz["alphabet"], "on_success": _on_solved,
    })

func _on_solved() -> void:
    done = true
    GameState.complete_puzzle(spec["id"])
    create_tween().tween_property(self, "glow", 1.0, 1.2)
    world.grant_reward(spec["reward"], global_position)
    world.event_finished(spec, true)

func _draw() -> void:
    var r := reveal
    if r <= 0.01:
        return
    var lv := level()
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, maxf(lv, 0.4))
    var rise := (1.0 - r) * 40.0
    draw_set_transform(Vector2(0, rise), 0.0, Vector2.ONE)
    draw_colored_polygon(PackedVector2Array([Vector2(-16, 0), Vector2(-11, -34), Vector2(11, -34), Vector2(16, 0)]), st)
    Art.crystal(self, Vector2(0, -50), 12.0, 6.0, SData.GOLD.darkened(0.45 - 0.45 * glow))
    Art.glow(self, Vector2(0, -50), 34.0, SData.GOLD, r * (0.35 + glow * 0.6))
    if locked:
        var a: String = spec.get("required_ability", "none")
        if a == "growth":
            for i in 5:
                draw_line(Vector2(-16 + i * 8, 0), Vector2(-14 + i * 7 + sin(i) * 6, -38 + (i % 2) * 8), Color("2fbf9f").darkened(0.3), 3.0)
        elif a == "resonance":
            draw_arc(Vector2(0, -22), 12.0, 0.0, TAU, 16, SData.NOTE_COLOR["E"].darkened(0.3), 2.5)
        elif a == "flow":
            draw_set_transform(Vector2(0, rise + 6), 0.0, Vector2(1, 0.4))
            draw_circle(Vector2.ZERO, 22.0, Color("3a2a58"))
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    draw_marker(-78.0)
