class_name ChimeStone
extends WorldObject
## Musical object for the Environmental Harmony puzzle.

var glyph := 0
var controller
var lit := false
var solved := false
var flash_t := 0.0

func build() -> void:
    interactable = true
    animated = true
    add_solid(Rect2(-8, -6, 16, 8))

func prompt() -> String:
    return "Ring the chime"

func interact(_player) -> void:
    if controller != null:
        controller.strike(self)

func ring() -> void:
    AudioManager.play_chime(glyph)
    flash_t = 1.0
    var c: Color = SData.NOTE_COLOR[SData.NOTES[glyph]]
    Fx.ring(world.fx, global_position + Vector2(0, -22), c, 60.0, 0.6)
    Fx.burst(world.fx, global_position + Vector2(0, -34), c, 8, 50.0, 0.7)

func flash() -> void:
    ring()

func dim() -> void:
    lit = false

func _process(delta: float) -> void:
    super._process(delta)
    flash_t = maxf(0.0, flash_t - delta * 1.2)

func _draw() -> void:
    var c: Color = SData.NOTE_COLOR[SData.NOTES[glyph]]
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, level())
    draw_colored_polygon(PackedVector2Array([Vector2(-10, 0), Vector2(-7, -14), Vector2(7, -14), Vector2(10, 0)]), st)
    var bright := 0.25 + (0.5 if (lit or solved) else 0.0) + flash_t * 0.5
    Art.crystal(self, Vector2(0, -28), 22.0, 8.0, Color(c.r, c.g, c.b).darkened(0.5 - minf(bright, 0.5)))
    Art.glyph(self, glyph, Vector2(0, -50), 5.0, Color(c.r, c.g, c.b, 0.55 + bright * 0.4), true)
    Art.glow(self, Vector2(0, -28), 26.0, c, bright)
    draw_marker(-68.0)
