class_name LoreStone
extends WorldObject
## Readable echo stone: story and gentle hints.

var title := "Echo Stone"
var text := ""

func build() -> void:
    interactable = true
    add_solid(Rect2(-9, -6, 18, 8))

func prompt() -> String:
    return "Read the %s" % title

func interact(_player) -> void:
    AudioManager.play_note("A", "chime", -8.0)
    GameState.dialogue_requested.emit({"title": title, "text": text})

func _draw() -> void:
    var lv := level()
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, lv)
    draw_colored_polygon(PackedVector2Array([Vector2(-10, 0), Vector2(-8, -38), Vector2(0, -46), Vector2(8, -38), Vector2(10, 0)]), st)
    var rc := Color(0.5, 0.45, 0.7).lerp(SData.TEAL, lv)
    draw_line(Vector2(0, -34), Vector2(0, -12), rc, 2.0)
    draw_arc(Vector2(0, -26), 5.0, 0.0, TAU, 14, rc, 1.5)
    if lv > 0.3:
        Art.glow(self, Vector2(0, -26), 16.0, SData.TEAL, lv * 0.6)
    draw_marker()
