class_name HarmonyMural
extends WorldObject
## Stone mural showing the order in which the chimes must be rung.

var order: Array = []

func build() -> void:
    interactable = true
    add_solid(Rect2(-30, -8, 60, 10))

func prompt() -> String:
    return "Study the mural"

func interact(_player) -> void:
    AudioManager.play_note("G", "chime", -8.0)
    GameState.dialogue_requested.emit({
        "title": "Mural of the Spring",
        "text": "Four crystals stand around the dry basin. The mural shows the order in which the old choir rang them, left to right.",
        "glyphs": order,
    })

func _draw() -> void:
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, level())
    draw_rect(Rect2(-34, -44, 68, 44), st.darkened(0.15))
    draw_rect(Rect2(-31, -41, 62, 38), st)
    for i in order.size():
        var c: Color = SData.NOTE_COLOR[SData.NOTES[order[i]]]
        Art.glyph(self, order[i], Vector2(-21.0 + i * 14.0, -22), 4.5, c.lightened(0.1), true)
    draw_marker(-62.0)
