class_name SpringBasin
extends WorldObject
## Dry basin at the centre of the chime ring; fills when the Spring is restored.

var water := 0.0

func build() -> void:
    animated = true
    z_index = -9
    if GameState.puzzles_done.has("spring"):
        water = 1.0

func restore() -> void:
    create_tween().tween_property(self, "water", 1.0, 2.5)
    Fx.burst(world.fx, global_position, SData.NOTE_COLOR["G"], 30, 90.0, 1.4)
    Fx.ring(world.fx, global_position, SData.NOTE_COLOR["G"], 140.0, 1.2)

func _draw() -> void:
    draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 0.6))
    draw_circle(Vector2.ZERO, 50.0, SData.STONE_DEAD.lerp(SData.STONE_ALIVE, water).darkened(0.2))
    draw_circle(Vector2.ZERO, 42.0, Color("0a0814"))
    if water > 0.0:
        draw_circle(Vector2.ZERO, 42.0 * water, Color("1d6f8f").lerp(Color("2fc4c0"), 0.5 + 0.5 * sin(_t * 1.5)))
        for i in 3:
            draw_arc(Vector2.ZERO, 12.0 + fmod(_t * 12.0 + i * 11.0, 30.0), 0.0, TAU, 20, Color(0.8, 1, 1, 0.3), 1.5)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    if water > 0.05:
        Art.glow(self, Vector2(0, -6), 54.0, SData.NOTE_COLOR["G"], water * 0.6)
