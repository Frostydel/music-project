class_name BridgeDeck
extends Node2D
## A bridge that grows from `from_p` to `to_p` (local coords). style: wood|stone.

var from_p := Vector2.ZERO
var to_p := Vector2(192, 0)
var width := 70.0
var style := "wood"
var progress := 0.0:
    set(v):
        progress = v
        queue_redraw()

func _draw() -> void:
    if progress <= 0.001:
        return
    var end := from_p.lerp(to_p, progress)
    var base := Color("5e4a78") if style == "wood" else Color("8e88b8")
    Art.thick_line(self, from_p, end, width + 10.0, base.darkened(0.45))
    Art.thick_line(self, from_p, end, width, base)
    var dir := (to_p - from_p).normalized()
    var perp := Vector2(-dir.y, dir.x)
    var len := from_p.distance_to(end)
    var n := int(len / 14.0)
    for i in n:
        var c := from_p + dir * (float(i) * 14.0 + 7.0)
        draw_line(c + perp * width * 0.5, c - perp * width * 0.5, base.darkened(0.25), 1.5)
    Art.thick_line(self, from_p + perp * (width * 0.5 + 2.0), end + perp * (width * 0.5 + 2.0), 3.0, Color("2fbf9f", 0.8))
    Art.thick_line(self, from_p - perp * (width * 0.5 + 2.0), end - perp * (width * 0.5 + 2.0), 3.0, Color("2fbf9f", 0.8))
    if progress > 0.98:
        for i in 6:
            var c := from_p.lerp(to_p, (float(i) + 0.5) / 6.0)
            Art.glow(self, c + perp * (width * 0.5 + 2.0), 8.0, SData.GOLD, 0.7)
