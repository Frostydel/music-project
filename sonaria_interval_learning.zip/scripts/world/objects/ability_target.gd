class_name AbilityTarget
extends WorldObject
## Something a note can change. kind: tree | sapling | rune | pool.
## Used for optional withered trees and for Director "ability lesson" targets.

var ability := "growth"
var kind := "tree"
var done := false
var bloom := 0.0
var spec: Dictionary = {}
var reward_petals := 2

func build() -> void:
    accepts_notes = true
    animated = true
    if kind == "tree":
        add_solid(Rect2(-6, -8, 12, 10))

func note_radius() -> float:
    return 150.0

func _color() -> Color:
    return SData.NOTE_COLOR[SData.ABILITY_NOTE[ability]]

func on_note(a: String, _player) -> bool:
    if done or a != ability:
        return false
    done = true
    create_tween().tween_property(self, "bloom", 1.0, 1.4)
    Fx.burst(world.fx, global_position + Vector2(0, -20), _color(), 26, 100.0)
    Fx.ring(world.fx, global_position, _color(), 90.0)
    world.grant_petals(reward_petals, global_position)
    if kind == "tree":
        world.complete_feature(object_id)
        GameState.toast.emit("The withered tree blooms again!", _color())
    else:
        GameState.toast.emit("Lesson learned: the %s Note changes the world." % SData.ABILITY_LABEL[ability], _color())
    if not spec.is_empty():
        world.event_finished(spec, true)
    return true

func _draw() -> void:
    var b := bloom
    var col := _color()
    match kind:
        "tree", "sapling":
            var s := 1.0 if kind == "tree" else 0.45
            var trunk := SData.TRUNK_DEAD.lerp(SData.TRUNK_ALIVE, b)
            draw_colored_polygon(PackedVector2Array([Vector2(-5, 0) * s, Vector2(-3, -34) * s, Vector2(3, -34) * s, Vector2(5, 0) * s]), trunk)
            for br in [[Vector2(0, -30), Vector2(-17, -50)], [Vector2(0, -32), Vector2(15, -54)], [Vector2(0, -36), Vector2(-2, -64)]]:
                draw_line(br[0] * s, br[1] * s, trunk.lightened(0.1), 2.5 * s)
            if b > 0.02:
                var cc := SData.CANOPY_DEAD.lerp(SData.CANOPY_ALIVE_A, b)
                for c in [[Vector2(0, -52), 20.0], [Vector2(-14, -44), 14.0], [Vector2(14, -46), 15.0], [Vector2(0, -64), 13.0]]:
                    draw_circle(c[0] * s, c[1] * s * b, cc)
                Art.glow(self, Vector2(0, -52) * s, 26.0 * s, col, b * 0.7)
        "rune":
            var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, b)
            draw_colored_polygon(PackedVector2Array([Vector2(-14, 0), Vector2(-10, -28), Vector2(10, -28), Vector2(14, 0)]), st)
            var rc := Color(0.4, 0.35, 0.5).lerp(col, b)
            draw_arc(Vector2(0, -14), 7.0, 0.0, TAU, 16, rc, 2.0)
            draw_line(Vector2(0, -22), Vector2(0, -6), rc, 2.0)
            if b > 0.02:
                Art.glow(self, Vector2(0, -14), 30.0, col, b)
        "pool":
            draw_set_transform(Vector2.ZERO, 0.0, Vector2(1, 0.55))
            draw_circle(Vector2.ZERO, 26.0, Color("1a1428"))
            draw_arc(Vector2.ZERO, 26.0, 0.0, TAU, 24, SData.STONE_DEAD, 4.0)
            draw_circle(Vector2.ZERO, 23.0 * b, Color("2fc4c0").lerp(col, 0.3))
            draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
            if b > 0.02:
                Art.glow(self, Vector2(0, -4), 28.0, col, b * 0.7)
