class_name HarmonyController
extends RefCounted
## Environmental Harmony puzzle logic: strike chimes in the right order.
## Used for the main Spring Hollow and for Director-spawned chime puzzles.

var puzzle_id := ""
var order: Array = []
var chimes: Array = []
var progress: Array = []
var solved := false
var on_solved: Callable
var world
var center := Vector2.ZERO
var _cd := 0.0

func chime_by_glyph(g: int):
    for c in chimes:
        if is_instance_valid(c) and c.glyph == g:
            return c
    return null

func strike(chime) -> void:
    chime.ring()
    if solved:
        return
    progress.append(chime.glyph)
    chime.lit = true
    var idx := progress.size() - 1
    if progress[idx] != order[idx]:
        _fail()
    elif progress.size() == order.size():
        solved = true
        for c in chimes:
            if is_instance_valid(c):
                c.solved = true
        AudioManager.play_sfx("success")
        on_solved.call()

func _fail() -> void:
    AudioManager.play_sfx("wrong")
    GameState.toast.emit("The chimes fall silent. Check the order on the mural, then try again.", Color("ff8aa8"))
    progress.clear()
    for c in chimes:
        if is_instance_valid(c):
            c.dim()
    GameState.record_failure(puzzle_id)

## Light the chimes in the right order (used as a hint / by the Guide Wisp).
func demo() -> void:
    if world == null or solved:
        return
    for i in order.size():
        var g: int = order[i]
        world.get_tree().create_timer(0.6 * i + 0.2, false).timeout.connect(func():
            var c = chime_by_glyph(g)
            if c != null:
                c.flash())

## Called every frame by World: auto-demonstrate when the player is nearby.
func update(delta: float, player_pos: Vector2) -> void:
    if solved or world == null:
        return
    _cd -= delta
    if _cd <= 0.0 and player_pos.distance_to(center) < 170.0:
        _cd = 16.0
        demo()
