class_name EchoPetal
extends WorldObject
## Optional collectible, picked up by walking over it.

var taken := false

func build() -> void:
    animated = true

func _process(delta: float) -> void:
    super._process(delta)
    if taken or world == null or world.player == null:
        return
    if global_position.distance_to(world.player.global_position) < 26.0:
        taken = true
        GameState.add_petals(1)
        AudioManager.play_note("A", "bell", -12.0)
        Fx.burst(world.fx, global_position + Vector2(0, -10), SData.GOLD, 8, 50.0, 0.6)
        queue_free()

func _draw() -> void:
    var bob := sin(_t * 2.0 + position.x) * 2.5
    Art.glow(self, Vector2(0, -10 + bob), 12.0, SData.GOLD, 0.7)
    draw_colored_polygon(PackedVector2Array([Vector2(0, -17 + bob), Vector2(4, -10 + bob), Vector2(0, -3 + bob), Vector2(-4, -10 + bob)]), SData.GOLD)
