class_name GuideWisp
extends WorldObject
## Director "tutorial assist": a small wisp that accompanies the player for a
## short time while the assist (slower melody, hints) is active.

var life := 14.0

func build() -> void:
    animated = true
    z_index = 6

func _process(delta: float) -> void:
    super._process(delta)
    life -= delta
    if world != null and world.player != null:
        var target: Vector2 = world.player.global_position + Vector2(26, -6)
        position = position.lerp(target, clampf(delta * 3.0, 0.0, 1.0))
    if life <= 0.0:
        queue_free()

func _draw() -> void:
    var a := clampf(life / 2.0, 0.0, 1.0)
    var bob := sin(_t * 4.0) * 4.0
    Art.glow(self, Vector2(0, -38 + bob), 22.0, SData.GOLD, a)
    draw_circle(Vector2(0, -38 + bob), 5.0, Color(1, 0.95, 0.75, a))
