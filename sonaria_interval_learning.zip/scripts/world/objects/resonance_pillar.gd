class_name ResonancePillar
extends WorldObject
## Dormant ancient mechanism. Resonance makes its runes glow.

var active := false
var glow := 0.0

func build() -> void:
    accepts_notes = true
    animated = true
    add_solid(Rect2(-14, -8, 28, 12))

func note_radius() -> float:
    return 150.0

func on_note(a: String, _player) -> bool:
    if active or a != "resonance":
        return false
    active = true
    create_tween().tween_property(self, "glow", 1.0, 1.2)
    world.complete_feature(object_id)
    var c: Color = SData.NOTE_COLOR["E"]
    Fx.ring(world.fx, global_position + Vector2(0, -30), c, 150.0, 1.0)
    Fx.burst(world.fx, global_position + Vector2(0, -40), c, 22, 90.0)
    GameState.toast.emit("The pillar's runes ignite.", c)
    return true

func _draw() -> void:
    var st := SData.STONE_DEAD.lerp(SData.STONE_ALIVE, maxf(glow, level()))
    draw_colored_polygon(PackedVector2Array([Vector2(-14, 0), Vector2(-11, -62), Vector2(11, -62), Vector2(14, 0)]), st)
    draw_rect(Rect2(-17, -8, 34, 8), st.darkened(0.2))
    draw_rect(Rect2(-16, -68, 32, 8), st.lightened(0.1))
    var rc := Color(0.4, 0.35, 0.55).lerp(SData.NOTE_COLOR["E"], glow)
    for i in 3:
        draw_arc(Vector2(0, -16.0 - i * 16.0), 5.0, 0.0, TAU, 14, rc, 2.0)
    if glow > 0.02:
        Art.glow(self, Vector2(0, -34), 44.0, SData.NOTE_COLOR["E"], glow * (0.7 + 0.2 * sin(_t * 3.0)))
