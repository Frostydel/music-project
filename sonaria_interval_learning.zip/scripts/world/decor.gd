class_name Decor
extends Node2D
## Non-interactive ground flora (tufts, flowers, mushrooms). Withered when a
## region is dead, glowing when restored; cross-faded by region level.

var world
var items: Array = []     # [pos, kind, color_seed]
var _t := 0.0
var _acc := 0.0

func build() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 12345
    for i in 650:
        var tile := Vector2(rng.randf_range(1.0, 63.0), rng.randf_range(1.0, 39.0))
        var cx := SData.river_cx(tile.y)
        if absf(tile.x - cx) < 2.4:
            continue
        items.append([tile * SData.TILE, rng.randi_range(0, 3), rng.randf()])

func _process(delta: float) -> void:
    _t += delta
    _acc += delta
    if _acc > 0.12:
        _acc = 0.0
        queue_redraw()

func _draw() -> void:
    for it in items:
        var p: Vector2 = it[0]
        var lv: float = world.level_of(SData.region_at_tile(p.x / SData.TILE))
        var kind: int = it[1]
        var cs: float = it[2]
        if lv < 0.98:
            var a := 1.0 - lv
            var dc := Color(0.35, 0.3, 0.42, 0.8 * a)
            draw_line(p, p + Vector2(-3, -7), dc, 1.5)
            draw_line(p, p + Vector2(2, -9), dc, 1.5)
            draw_line(p, p + Vector2(5, -5), dc, 1.5)
        if lv > 0.02:
            var col := SData.CANOPY_ALIVE_A.lerp(SData.CANOPY_ALIVE_B, cs)
            col.a = lv
            match kind:
                0:
                    draw_line(p, p + Vector2(-3, -9), col, 2.0)
                    draw_line(p, p + Vector2(0, -11), col, 2.0)
                    draw_line(p, p + Vector2(3, -8), col, 2.0)
                1:
                    draw_line(p, p + Vector2(0, -9), Color(0.2, 0.7, 0.55, lv), 2.0)
                    var pulse := 0.6 + 0.4 * sin(_t * 2.0 + cs * 20.0)
                    Art.glow(self, p + Vector2(0, -10), 9.0, SData.GOLD if cs > 0.5 else SData.TEAL, lv * pulse)
                    draw_circle(p + Vector2(0, -10), 3.0, Color(1, 0.95, 0.75, lv))
                2:
                    draw_rect(Rect2(p.x - 1.5, p.y - 6.0, 3.0, 6.0), Color(0.8, 0.8, 0.9, lv))
                    var pulse2 := 0.6 + 0.4 * sin(_t * 1.5 + cs * 30.0)
                    draw_circle(p + Vector2(0, -7), 5.0, Color(col.r, col.g, col.b, lv * 0.9))
                    Art.glow(self, p + Vector2(0, -7), 9.0, SData.VIOLET, lv * pulse2 * 0.8)
                _:
                    Art.crystal(self, p, 9.0, 3.0, SData.TEAL.lerp(SData.VIOLET, cs))
