class_name River
extends Node2D
## The ravine/river. Dry and cracked until Flow is sung at the River Source,
## after which water flows from north to south. Gaps (bridge sites) are
## separate solids that open when a bridge/arch is created.

var world
var flow_y := 0.0              # pixels from the top that currently carry water
var flowing := false
var _flow_start := 5.0 * SData.TILE
var _gaps_open: Dictionary = {}
var _gap_bodies: Dictionary = {}
var _cracks: Array = []
var _t := 0.0

func build() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 99
    var main_body := StaticBody2D.new()
    main_body.collision_layer = 2
    add_child(main_body)
    for y in SData.MAP_H:
        var cx := SData.river_cx(y + 0.5) * SData.TILE
        var rect := Rect2(cx - SData.RIVER_HALF * SData.TILE, y * SData.TILE, SData.RIVER_HALF * 2.0 * SData.TILE, SData.TILE)
        var gap := _gap_of_row(y)
        if gap == "":
            _add_shape(main_body, rect)
            world.grid.add("river_%d" % y, rect)
        else:
            if not _gap_bodies.has(gap):
                var gb := StaticBody2D.new()
                gb.collision_layer = 2
                add_child(gb)
                _gap_bodies[gap] = gb
                _gaps_open[gap] = false
            _add_shape(_gap_bodies[gap], rect)
            world.grid.add("gap_%s_%d" % [gap, y], rect)
        for k in 3:
            var x := rng.randf_range(rect.position.x + 8.0, rect.end.x - 8.0)
            _cracks.append([Vector2(x, y * SData.TILE + rng.randf_range(2.0, 26.0)), rng.randf_range(-1.0, 1.0), rng.randf_range(10.0, 26.0)])

func _add_shape(body: StaticBody2D, rect: Rect2) -> void:
    var sh := CollisionShape2D.new()
    var rs := RectangleShape2D.new()
    rs.size = rect.size
    sh.shape = rs
    sh.position = rect.get_center()
    body.add_child(sh)

func _gap_of_row(y: int) -> String:
    for g in SData.GAPS:
        if y >= SData.GAPS[g][0] and y <= SData.GAPS[g][1]:
            return g
    return ""

func is_gap_open(gap: String) -> bool:
    return _gaps_open.get(gap, false)

func open_gap(gap: String) -> void:
    if not _gap_bodies.has(gap) or _gaps_open[gap]:
        return
    _gaps_open[gap] = true
    for c in _gap_bodies[gap].get_children():
        c.set_deferred("disabled", true)
    for y in range(SData.GAPS[gap][0], SData.GAPS[gap][1] + 1):
        world.grid.set_enabled("gap_%s_%d" % [gap, y], false)

func start_flow() -> void:
    if flowing:
        return
    flowing = true
    flow_y = _flow_start
    var tw := create_tween()
    tw.tween_property(self, "flow_y", SData.MAP_PX.y, 4.0).set_trans(Tween.TRANS_SINE)

func _process(delta: float) -> void:
    _t += delta
    if flowing:
        queue_redraw()

func _draw() -> void:
    var T := SData.TILE
    var bed := Color("0a0814")
    var edge := Color("1b1530")
    for y in SData.MAP_H:
        var cx := SData.river_cx(y + 0.5) * T
        var half := SData.RIVER_HALF * T
        var lv: float = world.level_of("grove") * 0.5 + world.level_of("ruins") * 0.5
        draw_rect(Rect2(cx - half - 5.0, y * T, half * 2.0 + 10.0, T), edge.lerp(Color("2a5560"), lv * 0.6))
        draw_rect(Rect2(cx - half, y * T, half * 2.0, T), bed)
        if flowing and (y + 1) * T <= flow_y + T:
            var wy := y * T
            var k := 0.5 + 0.5 * sin(_t * 1.5 + y * 0.6)
            draw_rect(Rect2(cx - half, wy, half * 2.0, T), Color("1d6f8f").lerp(Color("2fc4c0"), k * 0.5))
            for s in 3:
                var off := fmod(_t * 40.0 + s * 41.0 + y * 17.0, half * 2.0)
                draw_line(Vector2(cx - half + off, wy + 6.0 + s * 9.0), Vector2(cx - half + off + 18.0, wy + 6.0 + s * 9.0), Color(0.8, 1.0, 1.0, 0.35), 2.0)
    if not flowing:
        for c in _cracks:
            draw_line(c[0], c[0] + Vector2(c[1] * c[2], c[2] * 0.6), Color("3a2a58"), 1.5)
    # hint of unreachable source at the head of the ravine
    draw_rect(Rect2(0, 0, 1, 1), Color(0, 0, 0, 0))
