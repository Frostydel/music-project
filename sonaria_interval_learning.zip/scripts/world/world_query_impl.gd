class_name WorldQueryImpl
extends WorldQuery
## Real WorldQuery backed by the collision grid (flood fill from the player).

var world
var _seen := PackedByteArray()
var _version := -1
var _origin := Vector2i(-1, -1)

func _init(w) -> void:
    world = w

func player_pos() -> Vector2:
    if world.player != null:
        return world.player.global_position
    return SData.START_TILE * SData.TILE

func _flood() -> void:
    world.grid.ensure()
    var cell: Vector2i = world.grid.cell_of(player_pos())
    if _version != world.grid.version or cell != _origin:
        _seen = world.grid.flood(player_pos())
        _version = world.grid.version
        _origin = cell

func site_reachable(site_id: String) -> bool:
    if not SData.SITES.has(site_id):
        return false
    _flood()
    return world.grid.reaches(_seen, SData.SITES[site_id]["pos"] * SData.TILE, 44.0)

func route_ready(site_id: String) -> bool:
    if not SData.SITES.has(site_id):
        return false
    var gap: String = SData.SITES[site_id].get("gap", "")
    if not SData.GAPS.has(gap):
        return false
    var row: float = (SData.GAPS[gap][0] + SData.GAPS[gap][1]) * 0.5 + 0.5
    var cx := SData.river_cx(row)
    _flood()
    var west: Vector2 = Vector2(cx - 3.4, row) * SData.TILE
    var east: Vector2 = Vector2(cx + 3.4, row) * SData.TILE
    return world.grid.reaches(_seen, west, 36.0) and world.grid.reaches(_seen, east, 36.0)

func practice_spot_ok() -> bool:
    return world.find_free_spot(player_pos(), 80.0, 170.0, null) != null

func patch_healed(site_id: String) -> bool:
    return GameState.has_flag("healed_" + site_id)
