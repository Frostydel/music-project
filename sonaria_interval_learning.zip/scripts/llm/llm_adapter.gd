class_name LLMAdapter
extends Node
## OPTIONAL LLM proposal source. Disabled unless SONARIA_LLM_ENDPOINT is set.
## It only ever returns a *proposed* spec (whitelisted keys, untrusted
## values). The Director validates it exactly like any other candidate, and
## the game works identically when this adapter is off, offline, slow or wrong.
##
## Environment variables (never hard-coded, never logged):
##   SONARIA_LLM_ENDPOINT  OpenAI-compatible chat-completions URL
##   SONARIA_LLM_API_KEY   optional bearer token
##   SONARIA_LLM_MODEL     model name (default "default")
##   SONARIA_LLM_TIMEOUT   seconds (default 4)

signal proposal_ready(spec: Dictionary, status: String)

var endpoint := ""
var model := "default"
var timeout := 4.0
var override_enabled := true     # tests can force-disable
var _api_key := ""
var _http: HTTPRequest = null
var _serial := 0

func _init() -> void:
    reload_config()

func reload_config() -> void:
    endpoint = OS.get_environment("SONARIA_LLM_ENDPOINT").strip_edges()
    _api_key = OS.get_environment("SONARIA_LLM_API_KEY")
    var m := OS.get_environment("SONARIA_LLM_MODEL")
    model = m if m != "" else "default"
    var t := OS.get_environment("SONARIA_LLM_TIMEOUT")
    timeout = float(t) if t.is_valid_float() and float(t) > 0.0 else 4.0

func is_enabled() -> bool:
    return override_enabled and endpoint != "" and Prefs.use_llm

func is_busy() -> bool:
    return _http != null

func status_text() -> String:
    if endpoint == "":
        return "off (no SONARIA_LLM_ENDPOINT)"
    if not Prefs.use_llm:
        return "off (disabled in settings)"
    return "on (%s)" % endpoint.get_slice("/", 2)

func build_prompt(snap: Dictionary) -> Array:
    var system := "You are the event director of a 2D music-fantasy game. Propose ONE next world event as a single JSON object and nothing else. " \
        + "Allowed event_type values: %s. Allowed required_ability: none, growth, resonance, flow (must be one the player owns). " % str(EventSpec.RULES.keys()) \
        + "reward is {\"type\": one of musical_fragment|echo_petals|hint|none, \"amount\": int}. difficulty is an integer 1-3. " \
        + "world_effect must match the type (hidden_shrine=reveal_shrine, musical_creature=reveal_secret, environment_puzzle=spawn_chime_puzzle, corruption_shift=heal_corruption, route_opening=open_route, discovery=spawn_discovery, tutorial_assist=simplify_puzzle, ability_lesson=spawn_practice_target). " \
        + "Optional: site_id, region, secret, target_puzzle, text (max 140 chars of flavour). Never include code."
    var brief := {
        "region": snap.get("region"), "difficulty": snap.get("difficulty"), "abilities": snap.get("abilities"),
        "fragments": snap.get("fragments"), "puzzles_done": snap.get("puzzles_done"), "recent_failures": snap.get("recent_failures"),
        "exploration": snap.get("exploration_total"), "event_counts": snap.get("event_counts"), "lesson_pending": snap.get("lesson_pending"),
    }
    return [{"role": "system", "content": system}, {"role": "user", "content": JSON.stringify(brief)}]

func request_proposal(snap: Dictionary) -> void:
    if _http != null:
        return
    _serial += 1
    var my_serial := _serial
    _http = HTTPRequest.new()
    _http.timeout = timeout
    add_child(_http)
    _http.request_completed.connect(_on_completed.bind(my_serial))
    var headers := PackedStringArray(["Content-Type: application/json"])
    if _api_key != "":
        headers.append("Authorization: Bearer " + _api_key)
    var body := JSON.stringify({"model": model, "messages": build_prompt(snap), "temperature": 0.7, "max_tokens": 300})
    var err := _http.request(endpoint, headers, HTTPClient.METHOD_POST, body)
    if err != OK:
        _finish({}, "request_failed")
        return
    # Hard safety net independent of HTTPRequest.timeout.
    get_tree().create_timer(timeout + 0.75).timeout.connect(_on_timeout.bind(my_serial))

func _on_timeout(serial: int) -> void:
    if serial == _serial and _http != null:
        _finish({}, "timeout")

func _on_completed(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray, serial: int) -> void:
    if serial != _serial or _http == null:
        return
    if result != HTTPRequest.RESULT_SUCCESS:
        _finish({}, "network_error_%d" % result)
        return
    if code != 200:
        _finish({}, "http_%d" % code)
        return
    var parsed = JSON.parse_string(body.get_string_from_utf8())
    if parsed == null:
        _finish({}, "invalid_json")
        return
    var text := _extract_text(parsed)
    var obj = _extract_object(text)
    if typeof(obj) != TYPE_DICTIONARY:
        _finish({}, "invalid_json")
        return
    var spec := EventSpec.normalize(obj)
    if spec.is_empty():
        _finish({}, "empty")
        return
    _finish(spec, "ok")

func _extract_text(parsed: Variant) -> String:
    if typeof(parsed) != TYPE_DICTIONARY:
        return ""
    if parsed.has("event_type"):
        return JSON.stringify(parsed)
    var choices = parsed.get("choices", null)
    if typeof(choices) == TYPE_ARRAY and choices.size() > 0 and typeof(choices[0]) == TYPE_DICTIONARY:
        var msg = choices[0].get("message", {})
        if typeof(msg) == TYPE_DICTIONARY:
            return str(msg.get("content", ""))
    var content = parsed.get("content", null)       # Anthropic-style
    if typeof(content) == TYPE_ARRAY and content.size() > 0 and typeof(content[0]) == TYPE_DICTIONARY:
        return str(content[0].get("text", ""))
    return ""

func _extract_object(text: String) -> Variant:
    var a := text.find("{")
    var b := text.rfind("}")
    if a == -1 or b <= a:
        return null
    return JSON.parse_string(text.substr(a, b - a + 1))

func _finish(spec: Dictionary, status: String) -> void:
    if _http != null:
        _http.queue_free()
        _http = null
    proposal_ready.emit(spec, status)
