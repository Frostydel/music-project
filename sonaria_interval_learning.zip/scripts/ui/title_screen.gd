class_name TitleScreen
extends Control
## Title screen with an animated starfield, floating notes and tree silhouettes.

signal start_requested(seed_value: int)

var _t := 0.0
var _stars: Array = []
var _notes: Array = []
var _seed_edit: LineEdit

func _init() -> void:
    theme = UITheme.get_theme()
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var rng := RandomNumberGenerator.new()
    rng.seed = 5
    for i in 120:
        _stars.append([Vector2(rng.randf() * 1280.0, rng.randf() * 520.0), rng.randf_range(0.5, 2.0), rng.randf() * 6.0])
    for i in 14:
        _notes.append([rng.randf() * 1280.0, rng.randf() * 720.0, rng.randf_range(10.0, 30.0), rng.randi_range(0, 3), rng.randf() * 6.0])
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    center.add_child(v)
    var title := UITheme.label("SONARIA", 96, Color("f2e9ff"))
    title.add_theme_color_override("font_outline_color", SData.VIOLET)
    title.add_theme_constant_override("outline_size", 14)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(title)
    var sub := UITheme.label("The World That Hears You", 26, SData.GOLD)
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(sub)
    v.add_child(Control.new())
    var play := UITheme.button("New Game", Vector2(300, 52))
    play.pressed.connect(_on_play)
    var pc := CenterContainer.new()
    pc.add_child(play)
    v.add_child(pc)
    var sh := HBoxContainer.new()
    sh.alignment = BoxContainer.ALIGNMENT_CENTER
    sh.add_theme_constant_override("separation", 8)
    sh.add_child(UITheme.label("Seed", 16, Color(0.75, 0.75, 0.95)))
    _seed_edit = LineEdit.new()
    _seed_edit.placeholder_text = "random"
    _seed_edit.custom_minimum_size = Vector2(150, 38)
    _seed_edit.text_submitted.connect(func(_s): _on_play())
    sh.add_child(_seed_edit)
    var rb := UITheme.button("Random", Vector2(100, 38))
    rb.pressed.connect(func(): _seed_edit.text = str(randi() % 1000000))
    sh.add_child(rb)
    v.add_child(sh)
    for spec in [["Controls", "controls"], ["Settings", "settings"]]:
        var b := UITheme.button(spec[0], Vector2(300, 44))
        b.pressed.connect(func(): add_child(ModalPanel.new(spec[1])))
        var c := CenterContainer.new()
        c.add_child(b)
        v.add_child(c)
    var q := UITheme.button("Quit", Vector2(300, 44))
    q.pressed.connect(func(): get_tree().quit())
    var qc := CenterContainer.new()
    qc.add_child(q)
    v.add_child(qc)
    var foot := UITheme.label("Sing the world back to life.  WASD move - E interact - 1/2/3 notes - Space sing", 14, Color(0.6, 0.6, 0.85))
    foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(foot)
    play.grab_focus()

func _on_play() -> void:
    var s := _seed_edit.text.strip_edges()
    var seed_value: int
    if s == "":
        seed_value = randi() % 1000000
    elif s.is_valid_int():
        seed_value = int(s)
    else:
        seed_value = absi(s.hash()) % 1000000
    start_requested.emit(seed_value)

func _process(delta: float) -> void:
    _t += delta
    queue_redraw()

func _draw() -> void:
    var s := get_viewport_rect().size
    for i in 12:
        var k := float(i) / 12.0
        draw_rect(Rect2(0, k * s.y, s.x, s.y / 12.0 + 1.0), Color("0b0d24").lerp(Color("2a1f5e"), k * k))
    for st in _stars:
        var a := 0.4 + 0.6 * (0.5 + 0.5 * sin(_t * 1.5 + st[2]))
        draw_circle(st[0] * (s / Vector2(1280, 720)), st[1], Color(1, 1, 1, a))
    for b in range(3):
        var pts := PackedVector2Array()
        for x in range(0, 1300, 40):
            pts.append(Vector2(x, 180.0 + b * 50.0 + sin(x * 0.01 + _t * 0.4 + b) * 30.0))
        draw_polyline(pts, Color(SData.TEAL.r, SData.TEAL.g, SData.TEAL.b, 0.12), 24.0)
    for n in _notes:
        var p := Vector2(fmod(n[0] + _t * 8.0, s.x + 60.0) - 30.0, fmod(n[1] - _t * 14.0, s.y + 60.0))
        if p.y < -30.0:
            p.y += s.y + 60.0
        var c: Color = SData.NOTE_COLOR[SData.NOTES[n[3]]]
        Art.glow(self, p, n[2] * 1.6, c, 0.35)
        Art.crystal(self, p, n[2], n[2] * 0.45, Color(c.r, c.g, c.b, 0.55))
    # silhouettes
    var ground_y := s.y - 70.0
    draw_rect(Rect2(0, ground_y, s.x, 80), Color("07081a"))
    for i in 16:
        var x := float(i) * s.x / 15.0
        var h := 120.0 + 60.0 * sin(i * 1.7)
        draw_colored_polygon(PackedVector2Array([Vector2(x - 40, ground_y + 5), Vector2(x, ground_y - h), Vector2(x + 40, ground_y + 5)]), Color("0a0b22"))
        Art.glow(self, Vector2(x, ground_y - h * 0.5), 26.0, SData.VIOLET, 0.12 + 0.1 * sin(_t + i))
