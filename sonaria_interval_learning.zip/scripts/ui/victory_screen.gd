class_name VictoryScreen
extends Control
signal replay_requested
signal new_seed_requested
signal menu_requested

var _t := 0.0

func _init() -> void:
    theme = UITheme.get_theme()
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var dim := ColorRect.new()
    dim.color = Color(0.03, 0.02, 0.12, 0.82)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    center.add_child(panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 12)
    panel.add_child(v)
    var t := UITheme.label("THE SILENCE IS BROKEN", 38, SData.GOLD)
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(t)
    v.add_child(UITheme.wrap_label("The Main Melody rolls across Sonaria. Roots wake, rivers remember their rhythm, and every living thing finds its song again. The Resonance Core, no longer a last echo, begins to hum a tune of its own.", 640, 18))
    var mins := int(GameState.playtime / 60.0)
    var secs := int(GameState.playtime) % 60
    var fails := 0
    for k in GameState.puzzle_fails:
        fails += int(GameState.puzzle_fails[k])
    v.add_child(UITheme.label("Time %d:%02d    Fragments %d    Echo Petals %d    Mistakes %d    Hints %d    Director events %d" % [mins, secs, GameState.fragments, GameState.petals, GameState.failure_log.size(), GameState.hints_used, GameState.event_history.size()], 15, Color(0.75, 0.85, 1.0)))
    v.add_child(UITheme.label("World seed: %d" % GameState.seed_value, 15, Color(0.75, 0.75, 0.95)))
    var h := HBoxContainer.new()
    h.alignment = BoxContainer.ALIGNMENT_CENTER
    h.add_theme_constant_override("separation", 12)
    v.add_child(h)
    for spec in [["Play again (same seed)", replay_requested], ["New seed", new_seed_requested], ["Main menu", menu_requested]]:
        var b := UITheme.button(spec[0], Vector2(200, 46))
        b.pressed.connect(func(): spec[1].emit())
        h.add_child(b)
    modulate.a = 0.0
    create_tween().tween_property(self, "modulate:a", 1.0, 1.5)
