class_name UITheme
extends RefCounted
## Shared look: deep blue panels, violet borders, teal/gold accents.

const TEXT := Color("e8e4ff")
static var _theme: Theme

static func box(bg: Color, border: Color, bw := 2, radius := 10, pad := 12) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(bw)
    s.set_corner_radius_all(radius)
    s.set_content_margin_all(pad)
    s.shadow_color = Color(0, 0, 0, 0.35)
    s.shadow_size = 6
    return s

static func get_theme() -> Theme:
    if _theme != null:
        return _theme
    var t := Theme.new()
    t.default_font_size = 18
    t.set_stylebox("panel", "PanelContainer", box(Color(0.05, 0.06, 0.17, 0.92), SData.VIOLET.darkened(0.2)))
    t.set_stylebox("panel", "Panel", box(Color(0.05, 0.06, 0.17, 0.92), SData.VIOLET.darkened(0.2)))
    t.set_stylebox("normal", "Button", box(Color(0.10, 0.10, 0.28, 0.95), SData.VIOLET.darkened(0.1), 2, 8, 8))
    t.set_stylebox("hover", "Button", box(Color(0.17, 0.15, 0.42, 1.0), SData.TEAL, 2, 8, 8))
    t.set_stylebox("pressed", "Button", box(Color(0.08, 0.30, 0.34, 1.0), SData.GOLD, 2, 8, 8))
    t.set_stylebox("focus", "Button", box(Color(0.14, 0.13, 0.36, 1.0), SData.GOLD, 2, 8, 8))
    t.set_stylebox("disabled", "Button", box(Color(0.08, 0.08, 0.16, 0.8), Color(0.3, 0.3, 0.4), 2, 8, 8))
    for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
        t.set_color(c, "Button", TEXT)
    t.set_color("font_disabled_color", "Button", Color(0.5, 0.5, 0.6))
    t.set_color("font_color", "Label", TEXT)
    t.set_color("font_color", "CheckBox", TEXT)
    t.set_color("font_color", "LineEdit", TEXT)
    t.set_stylebox("normal", "LineEdit", box(Color(0.04, 0.04, 0.12, 0.95), SData.VIOLET.darkened(0.3), 2, 6, 8))
    t.set_stylebox("focus", "LineEdit", box(Color(0.04, 0.04, 0.12, 0.95), SData.TEAL, 2, 6, 8))
    var track := StyleBoxFlat.new()
    track.bg_color = Color(0.15, 0.15, 0.35)
    track.set_corner_radius_all(4)
    track.content_margin_top = 4
    track.content_margin_bottom = 4
    var fill := StyleBoxFlat.new()
    fill.bg_color = SData.TEAL.darkened(0.2)
    fill.set_corner_radius_all(4)
    fill.content_margin_top = 4
    fill.content_margin_bottom = 4
    t.set_stylebox("slider", "HSlider", track)
    t.set_stylebox("grabber_area", "HSlider", fill)
    t.set_stylebox("grabber_area_highlight", "HSlider", fill)
    t.set_constant("separation", "VBoxContainer", 10)
    _theme = t
    return t

static func label(text: String, size := 18, color := TEXT) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    return l

static func button(text: String, min_size := Vector2(240, 46)) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.focus_mode = Control.FOCUS_ALL
    return b

static func wrap_label(text: String, width: float, size := 18, color := TEXT) -> Label:
    var l := label(text, size, color)
    l.custom_minimum_size.x = width
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    return l
