class_name PauseMenu
extends Control
signal resume_requested
signal restart_requested
signal new_seed_requested
signal menu_requested

func _init() -> void:
    theme = UITheme.get_theme()
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_anchors_preset(Control.PRESET_FULL_RECT)
    visible = false
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.02, 0.1, 0.75)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    center.add_child(panel)
    var v := VBoxContainer.new()
    panel.add_child(v)
    var t := UITheme.label("PAUSED", 34, SData.GOLD)
    t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    v.add_child(t)
    v.add_child(_btn("Resume", func(): resume_requested.emit()))
    v.add_child(_btn("Controls", func(): _open("controls")))
    v.add_child(_btn("Settings", func(): _open("settings")))
    v.add_child(_btn("Restart (same seed)", func(): restart_requested.emit()))
    v.add_child(_btn("New game (new seed)", func(): new_seed_requested.emit()))
    v.add_child(_btn("Main menu", func(): menu_requested.emit()))

func _btn(text: String, cb: Callable) -> Button:
    var b := UITheme.button(text)
    b.pressed.connect(cb)
    return b

func _open(mode: String) -> void:
    add_child(ModalPanel.new(mode))

func _unhandled_input(event: InputEvent) -> void:
    if visible and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
        resume_requested.emit()
        get_viewport().set_input_as_handled()
