class_name GlyphRow
extends Control
## Draws a row of glyph shapes and/or note crystals (for clues & dialogue).

var glyphs: Array = []
var notes: Array = []
var note_label := ""

func setup(g: Array, n: Array, label := "") -> void:
    glyphs = g
    notes = n
    note_label = label
    custom_minimum_size = Vector2(maxi(glyphs.size() + notes.size(), 1) * 56.0, 54.0)
    queue_redraw()

func _draw() -> void:
    var x := 28.0
    for g in glyphs:
        var c: Color = SData.NOTE_COLOR[SData.NOTES[g]]
        Art.glow(self, Vector2(x, 27), 22.0, c, 0.5)
        Art.glyph(self, g, Vector2(x, 27), 12.0, c, true)
        x += 56.0
    for n in notes:
        var c: Color = SData.NOTE_COLOR[n]
        Art.glow(self, Vector2(x, 27), 24.0, c, 0.6)
        Art.crystal(self, Vector2(x, 36), 24.0, 11.0, c)
        if note_label != "":
            draw_string(ThemeDB.fallback_font, Vector2(x - 20, 50), note_label, HORIZONTAL_ALIGNMENT_CENTER, 40.0, 13, SData.GOLD)
        x += 56.0
