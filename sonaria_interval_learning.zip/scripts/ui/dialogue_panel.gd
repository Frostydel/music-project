class_name DialoguePanel
extends Control
## Modal text box for lore, clues and hints. Queues if already open.

signal opened
signal closed

var _panel: PanelContainer
var _title: Label
var _body: Label
var _row: GlyphRow
var _queue: Array = []
var _age := 0.0

func _init() -> void:
    theme = UITheme.get_theme()
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    visible = false
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    center.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(center)
    var margin := MarginContainer.new()
    margin.add_theme_constant_override("margin_top", 340)
    center.add_child(margin)
    _panel = PanelContainer.new()
    margin.add_child(_panel)
    var v := VBoxContainer.new()
    _panel.add_child(v)
    _title = UITheme.label("", 22, SData.GOLD)
    v.add_child(_title)
    _body = UITheme.wrap_label("", 700)
    v.add_child(_body)
    _row = GlyphRow.new()
    v.add_child(_row)
    v.add_child(UITheme.label("E / Enter  continue", 14, Color(0.6, 0.6, 0.8)))

func show_request(req: Dictionary) -> void:
    if visible:
        _queue.append(req)
        return
    _title.text = str(req.get("title", ""))
    _body.text = str(req.get("text", ""))
    _row.setup(req.get("glyphs", []), req.get("notes", []), str(req.get("note_label", "")))
    _row.visible = not (req.get("glyphs", []).is_empty() and req.get("notes", []).is_empty())
    _age = 0.0
    visible = true
    opened.emit()

func close() -> void:
    visible = false
    if not _queue.is_empty():
        var nxt: Dictionary = _queue.pop_front()
        show_request(nxt)
        return
    closed.emit()

func _process(delta: float) -> void:
    _age += delta

func _input(event: InputEvent) -> void:
    if not visible or _age < 0.2:
        return
    if event is InputEventKey and event.pressed and not event.echo:
        if event.is_action_pressed("interact") or event.keycode == KEY_ENTER or event.keycode == KEY_ESCAPE or event.keycode == KEY_SPACE:
            close()
            get_viewport().set_input_as_handled()
