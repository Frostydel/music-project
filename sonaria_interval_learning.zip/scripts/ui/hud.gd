class_name HUD
extends Control
## Gameplay HUD: fragments, petals, note bar, objective, interaction prompt,
## region banner, toasts and the Director debug panel (F3).

class FragmentBar extends Control:
    func _init() -> void:
        custom_minimum_size = Vector2(210, 30)
    func _draw() -> void:
        for i in SData.FRAGMENTS_MAX:
            var c := Vector2(16.0 + i * 38.0, 16.0)
            var on: bool = i < GameState.fragments
            var bonus := i >= SData.FRAGMENTS_NEEDED
            var col := SData.GOLD if on else (Color(0.25, 0.25, 0.4, 0.5) if bonus else Color(0.3, 0.3, 0.5))
            if on:
                Art.glow(self, c, 20.0, SData.GOLD, 0.7)
            Art.crystal(self, c + Vector2(0, 9), 17.0, 8.0, col)

class AbilityBar extends Control:
    func _init() -> void:
        custom_minimum_size = Vector2(210, 58)
    func _draw() -> void:
        for i in 3:
            var a: String = SData.ABILITIES[i]
            var c := Vector2(26.0 + i * 66.0, 26.0)
            var unlocked: bool = GameState.abilities.get(a, false)
            var col: Color = SData.NOTE_COLOR[SData.ABILITY_NOTE[a]]
            if unlocked:
                draw_circle(c, 22.0, col.darkened(0.55))
                draw_arc(c, 22.0, 0.0, TAU, 28, col, 3.0 if GameState.selected_ability != a else 5.0)
                if GameState.selected_ability == a:
                    Art.glow(self, c, 34.0, col, 0.8)
                draw_string(ThemeDB.fallback_font, c + Vector2(-8, 8), SData.ABILITY_NOTE[a], HORIZONTAL_ALIGNMENT_CENTER, 16.0, 22, col.lightened(0.5))
            else:
                draw_circle(c, 22.0, Color(0.1, 0.1, 0.2, 0.8))
                draw_arc(c, 22.0, 0.0, TAU, 28, Color(0.3, 0.3, 0.45), 2.0)
                draw_string(ThemeDB.fallback_font, c + Vector2(-5, 7), "?", HORIZONTAL_ALIGNMENT_CENTER, 12.0, 20, Color(0.4, 0.4, 0.55))
            draw_string(ThemeDB.fallback_font, c + Vector2(-4, 40), str(i + 1), HORIZONTAL_ALIGNMENT_CENTER, 10.0, 13, Color(0.7, 0.7, 0.9))

var _frag_bar: FragmentBar
var _abil_bar: AbilityBar
var _petals: Label
var _obj_title: Label
var _obj_hint: Label
var _prompt_panel: PanelContainer
var _prompt: Label
var _banner: Label
var _toasts: VBoxContainer
var _debug_panel: PanelContainer
var _debug: Label
var _seed_label: Label
var _banner_tween: Tween

func _init() -> void:
    theme = UITheme.get_theme()
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE

func _ready() -> void:
    # vignette
    var vg := TextureRect.new()
    var g := Gradient.new()
    g.colors = PackedColorArray([Color(0, 0, 0.05, 0), Color(0, 0, 0.05, 0.55)])
    g.offsets = PackedFloat32Array([0.55, 1.0])
    var gt := GradientTexture2D.new()
    gt.gradient = g
    gt.fill = GradientTexture2D.FILL_RADIAL
    gt.fill_from = Vector2(0.5, 0.5)
    gt.fill_to = Vector2(1.0, 0.5)
    gt.width = 256
    gt.height = 256
    vg.texture = gt
    vg.set_anchors_preset(Control.PRESET_FULL_RECT)
    vg.stretch_mode = TextureRect.STRETCH_SCALE
    vg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    vg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(vg)
    # top-left
    var tl := PanelContainer.new()
    tl.position = Vector2(14, 14)
    tl.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(tl)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 4)
    tl.add_child(v)
    v.add_child(UITheme.label("MELODY FRAGMENTS", 13, Color(0.7, 0.7, 0.95)))
    _frag_bar = FragmentBar.new()
    v.add_child(_frag_bar)
    _petals = UITheme.label("Echo Petals: 0", 15, SData.GOLD)
    v.add_child(_petals)
    v.add_child(UITheme.label("NOTES  (1-3 select, Space sing)", 13, Color(0.7, 0.7, 0.95)))
    _abil_bar = AbilityBar.new()
    v.add_child(_abil_bar)
    # objective
    var op := PanelContainer.new()
    op.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(op)
    op.set_anchors_preset(Control.PRESET_TOP_RIGHT)
    op.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    op.offset_left = -14
    op.offset_right = -14
    op.offset_top = 14
    var ov := VBoxContainer.new()
    ov.add_theme_constant_override("separation", 4)
    op.add_child(ov)
    ov.add_child(UITheme.label("OBJECTIVE", 13, Color(0.7, 0.7, 0.95)))
    _obj_title = UITheme.wrap_label("", 340, 19, SData.GOLD)
    ov.add_child(_obj_title)
    _obj_hint = UITheme.wrap_label("", 340, 14, Color(0.78, 0.78, 0.95))
    ov.add_child(_obj_hint)
    # banner
    _banner = UITheme.label("", 40, Color.WHITE)
    _banner.add_theme_color_override("font_outline_color", Color(0.1, 0.05, 0.3))
    _banner.add_theme_constant_override("outline_size", 8)
    _banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
    _banner.custom_minimum_size = Vector2(900, 60)
    _banner.position = Vector2(190, 80)
    _banner.modulate.a = 0.0
    _banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_banner)
    # prompt
    _prompt_panel = PanelContainer.new()
    _prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _prompt = UITheme.label("", 20, SData.GOLD)
    _prompt_panel.add_child(_prompt)
    _prompt_panel.visible = false
    add_child(_prompt_panel)
    # toasts
    _toasts = VBoxContainer.new()
    _toasts.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _toasts.position = Vector2(14, 430)
    _toasts.custom_minimum_size = Vector2(480, 0)
    _toasts.alignment = BoxContainer.ALIGNMENT_END
    add_child(_toasts)
    # debug
    _debug_panel = PanelContainer.new()
    _debug_panel.visible = false
    _debug_panel.position = Vector2(14, 250)
    _debug_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _debug = UITheme.wrap_label("Director: waiting...", 420, 13, Color(0.85, 0.95, 1.0))
    _debug_panel.add_child(_debug)
    add_child(_debug_panel)
    # hint footer
    _seed_label = UITheme.label("Seed %d   |   Esc pause   F3 director" % GameState.seed_value, 12, Color(0.6, 0.6, 0.8, 0.8))
    _seed_label.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
    _seed_label.grow_horizontal = Control.GROW_DIRECTION_BEGIN
    _seed_label.grow_vertical = Control.GROW_DIRECTION_BEGIN
    _seed_label.offset_right = -10
    _seed_label.offset_bottom = -8
    add_child(_seed_label)
    GameState.toast.connect(add_toast)
    GameState.fragments_changed.connect(func(_n): _refresh())
    GameState.petals_changed.connect(func(_n): _refresh())
    GameState.ability_unlocked.connect(func(_a): _refresh())
    GameState.objective_changed.connect(_refresh)
    GameState.region_changed.connect(func(r): show_banner(SData.REGION_NAMES[r]))
    _refresh()
    show_banner(SData.REGION_NAMES[GameState.current_region])

func _process(_d: float) -> void:
    if _prompt_panel.visible:
        _prompt_panel.position = Vector2((size.x - _prompt_panel.size.x) * 0.5, size.y - 90.0)

func _refresh() -> void:
    _frag_bar.queue_redraw()
    _abil_bar.queue_redraw()
    _petals.text = "Echo Petals: %d" % GameState.petals
    var lines: Array = GameState.objective_lines()
    _obj_title.text = str(lines[0])
    _obj_hint.text = str(lines[1])

func set_prompt(text: String) -> void:
    _prompt_panel.visible = text != ""
    _prompt.text = "E   " + text

func show_banner(text: String, sub_color := Color.WHITE) -> void:
    _banner.text = text
    _banner.add_theme_color_override("font_color", sub_color)
    if _banner_tween != null:
        _banner_tween.kill()
    _banner.modulate.a = 0.0
    _banner_tween = create_tween()
    _banner_tween.tween_property(_banner, "modulate:a", 1.0, 0.6)
    _banner_tween.tween_interval(2.2)
    _banner_tween.tween_property(_banner, "modulate:a", 0.0, 1.0)

func add_toast(text: String, color: Color) -> void:
    var p := PanelContainer.new()
    p.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var l := UITheme.wrap_label(text, 440, 16, color.lightened(0.25))
    p.add_child(l)
    _toasts.add_child(p)
    while _toasts.get_child_count() > 5:
        _toasts.get_child(0).queue_free()
        _toasts.remove_child(_toasts.get_child(0))
    var tw := create_tween()
    tw.tween_interval(5.0)
    tw.tween_property(p, "modulate:a", 0.0, 1.0)
    tw.finished.connect(p.queue_free)

func toggle_debug() -> void:
    _debug_panel.visible = not _debug_panel.visible

func show_decision(d: Dictionary) -> void:
    var spec: Dictionary = d.get("spec", {})
    var txt := "DIRECTOR  trigger=%s  considered=%s rejected=%s\n" % [d.get("trigger", "?"), d.get("considered", "-"), d.get("rejected", "-")]
    if spec.is_empty():
        txt += "-> no event\n"
    else:
        txt += "-> %s @ %s  d%s  ability=%s  reward=%s  src=%s%s\n" % [spec.get("event_type"), spec.get("site_id"), spec.get("difficulty"), spec.get("required_ability"), spec.get("reward", {}).get("type"), spec.get("source"), "" if d.get("executed", false) else " (NOT executed)"]
    for r in d.get("reasons", []):
        txt += "   %s\n" % str(r)
    _debug.text = txt
