class_name ModalPanel
extends Control
## Controls / Settings overlay, usable from the title screen and pause menu.

signal closed

func _init(mode := "controls") -> void:
    theme = UITheme.get_theme()
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var dim := ColorRect.new()
    dim.color = Color(0.02, 0.02, 0.08, 0.8)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := PanelContainer.new()
    center.add_child(panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 10)
    panel.add_child(v)
    if mode == "controls":
        _build_controls(v)
    else:
        _build_settings(v)
    var b := UITheme.button("Close", Vector2(200, 42))
    b.pressed.connect(_close)
    var bc := CenterContainer.new()
    bc.add_child(b)
    v.add_child(bc)
    b.grab_focus()

func _close() -> void:
    Prefs.save_settings()
    closed.emit()
    queue_free()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
        _close()
        get_viewport().set_input_as_handled()

func _build_controls(v: VBoxContainer) -> void:
    v.add_child(UITheme.label("CONTROLS", 28, SData.GOLD))
    var rows := [
        ["WASD / Arrow keys", "Move"], ["E", "Interact (stones, chimes, tablets, shrines)"],
        ["1  2  3", "Select Growth / Resonance / Flow note"], ["Space", "Sing the selected note (affects things nearby)"],
        ["In a puzzle: 1-4", "Sing notes (or click them)"], ["L / H / R / Backspace", "Listen again / Hint / Retry / Undo"],
        ["Esc", "Pause (or close a puzzle)"], ["F3", "Show the AI Director's decisions"],
    ]
    var grid := GridContainer.new()
    grid.columns = 2
    grid.add_theme_constant_override("h_separation", 28)
    grid.add_theme_constant_override("v_separation", 6)
    v.add_child(grid)
    for r in rows:
        grid.add_child(UITheme.label(r[0], 17, SData.TEAL))
        grid.add_child(UITheme.label(r[1], 17))
    v.add_child(UITheme.wrap_label("Music changes the world: sing the right note near withered things. Every puzzle can be retried, and hints are free.", 560, 15, Color(0.75, 0.75, 0.95)))

func _slider(v: VBoxContainer, label: String, value: float, cb: Callable) -> void:
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 16)
    var l := UITheme.label(label, 17)
    l.custom_minimum_size.x = 120
    h.add_child(l)
    var s := HSlider.new()
    s.min_value = 0.0
    s.max_value = 1.0
    s.step = 0.05
    s.value = value
    s.custom_minimum_size = Vector2(260, 24)
    s.value_changed.connect(cb)
    h.add_child(s)
    v.add_child(h)

func _build_settings(v: VBoxContainer) -> void:
    v.add_child(UITheme.label("SETTINGS", 28, SData.GOLD))
    _slider(v, "Master", Prefs.master, func(x): Prefs.master = x; AudioManager.apply_volumes())
    _slider(v, "Music", Prefs.music, func(x): Prefs.music = x; AudioManager.apply_volumes())
    _slider(v, "Effects", Prefs.sfx, func(x): Prefs.sfx = x; AudioManager.apply_volumes())
    var c1 := CheckBox.new()
    c1.text = "Magical particles"
    c1.button_pressed = Prefs.particles
    c1.toggled.connect(func(b): Prefs.particles = b)
    v.add_child(c1)
    var c2 := CheckBox.new()
    c2.text = "Allow optional LLM event proposals"
    c2.button_pressed = Prefs.use_llm
    c2.toggled.connect(func(b): Prefs.use_llm = b)
    v.add_child(c2)
    var probe := LLMAdapter.new()
    v.add_child(UITheme.label("LLM director: " + probe.status_text(), 14, Color(0.7, 0.7, 0.9)))
    probe.free()
