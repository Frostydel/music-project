extends Node
## Procedural audio (autoload "AudioManager"). No audio assets are required:
## every sound is synthesised at start-up. If files with matching names exist
## in res://assets/audio/ (e.g. wrong.ogg, ambient_alive.ogg) they override
## the synthesised version.

const RATE := 22050
const AMB_RATE := 16000
const BPM := 78.0
const CHORDS := [[0, 3, 7], [-4, 0, 3], [3, 7, 10], [-2, 2, 5]]   # Am, F, C, G (semitones from A4)

var level := 0.0                 # overall restoration 0..1 (smoothed internally)
var music_enabled := false
var overrides_used: Array = []

var _streams: Dictionary = {}
var _sfx_pool: Array = []
var _music_pool: Array = []
var _amb_dead: AudioStreamPlayer
var _amb_alive: AudioStreamPlayer
var _shown := 0.0
var _beat := 0.0
var _step := 0
var _rng := RandomNumberGenerator.new()
var _pattern := 0

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_PAUSABLE
    _setup_buses()
    _build_streams()
    for i in 14:
        _sfx_pool.append(_make_player("SFX"))
    for i in 12:
        _music_pool.append(_make_player("Music"))
    _amb_dead = _make_player("Music")
    _amb_alive = _make_player("Music")
    _amb_dead.stream = _streams["ambient_dead"]
    _amb_alive.stream = _streams["ambient_alive"]
    apply_volumes()

func _setup_buses() -> void:
    for b in ["Music", "SFX"]:
        if AudioServer.get_bus_index(b) == -1:
            AudioServer.add_bus()
            var idx := AudioServer.bus_count - 1
            AudioServer.set_bus_name(idx, b)
            AudioServer.set_bus_send(idx, "Master")

func apply_volumes() -> void:
    AudioServer.set_bus_volume_db(0, linear_to_db(maxf(Prefs.master, 0.0001)))
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Music"), linear_to_db(maxf(Prefs.music, 0.0001)))
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("SFX"), linear_to_db(maxf(Prefs.sfx, 0.0001)))

func _make_player(bus: String) -> AudioStreamPlayer:
    var p := AudioStreamPlayer.new()
    p.bus = bus
    add_child(p)
    return p

# ------------------------------------------------------------ synthesis
func _build_streams() -> void:
    for kind in ["pluck", "bell", "water", "chime", "pad"]:
        _streams[kind] = _load_override(kind, _to_wav(_synth(kind, 440.0, _dur(kind)), RATE, false))
    _streams["wrong"] = _load_override("wrong", _to_wav(_synth("wrong", 110.0, 0.4), RATE, false))
    _streams["ambient_dead"] = _load_override("ambient_dead", _to_wav(_ambient(false), AMB_RATE, true))
    _streams["ambient_alive"] = _load_override("ambient_alive", _to_wav(_ambient(true), AMB_RATE, true))

func _dur(kind: String) -> float:
    match kind:
        "pad": return 3.2
        "chime": return 1.8
        "bell": return 1.6
        "water": return 1.1
    return 1.2

func _load_override(key: String, fallback: AudioStream) -> AudioStream:
    for ext in ["ogg", "wav", "mp3"]:
        var path := "res://assets/audio/%s.%s" % [key, ext]
        if ResourceLoader.exists(path):
            var res = load(path)
            if res is AudioStream:
                overrides_used.append(key)
                return res
    return fallback

func _synth(kind: String, f: float, dur: float) -> PackedFloat32Array:
    var n := int(dur * RATE)
    var out := PackedFloat32Array()
    out.resize(n)
    for i in n:
        var t := float(i) / RATE
        var v := 0.0
        var att := minf(1.0, t / 0.004)
        match kind:
            "pluck":
                v = (sin(TAU * f * t) + 0.45 * sin(TAU * 2.0 * f * t) + 0.2 * sin(TAU * 3.0 * f * t)) * exp(-3.4 * t) * att * 0.5
            "bell":
                v = (sin(TAU * f * t) + 0.5 * sin(TAU * f * 2.76 * t) * exp(-2.0 * t) + 0.3 * sin(TAU * f * 5.4 * t) * exp(-4.0 * t)) * exp(-2.2 * t) * att * 0.5
            "water":
                var vib := 1.0 + 0.004 * sin(TAU * 6.0 * t)
                v = (sin(TAU * f * vib * t) + 0.25 * sin(TAU * f * 2.0 * t)) * exp(-2.6 * t) * minf(1.0, t / 0.03) * 0.55
            "chime":
                v = (sin(TAU * f * t) + 0.4 * sin(TAU * f * 3.0 * t) * exp(-3.0 * t)) * exp(-1.9 * t) * att * 0.55
            "pad":
                var env := minf(1.0, t / 0.5) * minf(1.0, (dur - t) / 0.8)
                v = (sin(TAU * f * t) + 0.5 * sin(TAU * f * 1.005 * t) + 0.25 * sin(TAU * f * 2.0 * t)) * env * 0.32
            "wrong":
                var env2 := exp(-5.0 * t) * att
                v = (sin(TAU * f * t) + sin(TAU * f * 1.06 * t) + 0.5 * sin(TAU * f * 2.0 * t)) * env2 * 0.45
        out[i] = v
    return out

func _ambient(alive: bool) -> PackedFloat32Array:
    var secs := 8.0
    var n := int(secs * AMB_RATE)
    var out := PackedFloat32Array()
    out.resize(n)
    var r := RandomNumberGenerator.new()
    r.seed = 4242 if alive else 1717
    var noise_lp := 0.0
    var chirps: Array = []
    if alive:
        for c in 4:
            chirps.append([r.randf_range(0.4, 6.8), r.randf_range(2200.0, 3400.0), r.randf_range(0.10, 0.2)])
    for i in n:
        var t := float(i) / AMB_RATE
        var env := 0.5 - 0.5 * cos(TAU * t / secs)      # zero at loop ends -> seamless noise
        var raw := r.randf_range(-1.0, 1.0)
        noise_lp += (raw - noise_lp) * (0.02 if not alive else 0.05)
        var v := 0.0
        if not alive:
            v += 0.16 * sin(TAU * 55.0 * t) + 0.10 * sin(TAU * 82.5 * t)
            v *= 0.75 + 0.25 * sin(TAU * 0.25 * t)
            v += noise_lp * 2.2 * env * (0.6 + 0.4 * sin(TAU * 0.125 * t))
        else:
            for fr in [110.0, 164.875, 220.0, 261.625, 329.625]:
                v += 0.07 * sin(TAU * fr * t)
            v *= 0.8 + 0.2 * sin(TAU * 0.375 * t)
            v += 0.03 * sin(TAU * 659.25 * t) * (0.5 + 0.5 * sin(TAU * 0.5 * t))
            v += noise_lp * 0.7 * env
            for c in chirps:
                var dt: float = t - c[0]
                if dt >= 0.0 and dt < c[2]:
                    var k: float = dt / c[2]
                    v += 0.12 * sin(TAU * (c[1] + 700.0 * k) * dt) * sin(PI * k)
        out[i] = v
    return out

func _to_wav(data: PackedFloat32Array, rate: int, loop: bool) -> AudioStreamWAV:
    var s := AudioStreamWAV.new()
    s.format = AudioStreamWAV.FORMAT_16_BITS
    s.mix_rate = rate
    s.stereo = false
    var bytes := PackedByteArray()
    bytes.resize(data.size() * 2)
    for i in data.size():
        bytes.encode_s16(i * 2, int(clampf(data[i], -1.0, 1.0) * 32767.0))
    s.data = bytes
    if loop:
        s.loop_mode = AudioStreamWAV.LOOP_FORWARD
        s.loop_begin = 0
        s.loop_end = data.size()
    return s

# ------------------------------------------------------------ playback API
func _play_on(pool: Array, stream: AudioStream, pitch: float, vol_db: float) -> void:
    if stream == null:
        return
    var chosen: AudioStreamPlayer = null
    for p in pool:
        if not p.playing:
            chosen = p
            break
    if chosen == null:
        chosen = pool[0]
    chosen.stream = stream
    chosen.pitch_scale = pitch
    chosen.volume_db = vol_db
    chosen.play()

func play_note(note: String, kind := "pluck", vol_db := -4.0) -> void:
    if not SData.NOTE_FREQ.has(note):
        return
    _play_on(_sfx_pool, _streams.get(kind, _streams["pluck"]), SData.NOTE_FREQ[note] / 440.0, vol_db)

func play_ability(ability: String) -> void:
    var kind := {"growth": "pluck", "resonance": "bell", "flow": "water"}.get(ability, "pluck") as String
    play_note(SData.ABILITY_NOTE.get(ability, "C"), kind, -2.0)

func play_chime(glyph: int) -> void:
    play_note(SData.NOTES[clampi(glyph, 0, 3)], "chime", -3.0)

func play_semitone(kind: String, semis: float, vol_db: float, music := true) -> void:
    _play_on(_music_pool if music else _sfx_pool, _streams.get(kind, _streams["pluck"]), pow(2.0, semis / 12.0), vol_db)

func play_melody(notes: Array, step := 0.28, kind := "pluck") -> void:
    for i in notes.size():
        var n: String = notes[i]
        get_tree().create_timer(step * i, false).timeout.connect(play_note.bind(n, kind, -3.0))

func play_sfx(name: String) -> void:
    match name:
        "wrong":
            _play_on(_sfx_pool, _streams["wrong"], 1.0, -4.0)
        "success":
            play_melody(["C", "E", "G", "A"], 0.11, "bell")
        "click":
            play_note("A", "pluck", -14.0)
        "collect":
            play_melody(["G", "A"], 0.08, "bell")
        "unlock":
            play_melody(["C", "G", "A"], 0.15, "bell")
            _play_on(_sfx_pool, _streams["pad"], 0.5, -8.0)
        "reveal":
            play_melody(["E", "G", "A"], 0.18, "chime")
        "region_complete":
            play_melody(["C", "E", "G", "A", "G", "A"], 0.14, "bell")
            _play_on(_sfx_pool, _streams["pad"], 0.5, -5.0)
            _play_on(_sfx_pool, _streams["pad"], 0.75, -7.0)
        "victory":
            play_melody(["C", "E", "G", "A", "G", "A", "C"], 0.2, "bell")
            _play_on(_sfx_pool, _streams["pad"], 0.5, -3.0)
            _play_on(_sfx_pool, _streams["pad"], 0.75, -4.0)
            _play_on(_sfx_pool, _streams["pad"], 1.0, -6.0)

# ------------------------------------------------------------ music director
func start_music(seed_in: int) -> void:
    _rng.seed = seed_in
    _step = 0
    _beat = 0.0
    _shown = level
    music_enabled = true
    _amb_dead.play()
    _amb_alive.play()

func stop_music() -> void:
    music_enabled = false
    for p in _music_pool:
        p.stop()
    _amb_dead.stop()
    _amb_alive.stop()

func _process(delta: float) -> void:
    if not music_enabled:
        return
    _shown = move_toward(_shown, level, delta * 0.15)
    _amb_dead.volume_db = linear_to_db(maxf(0.0001, (1.0 - _shown) * 0.9 + 0.05))
    _amb_alive.volume_db = linear_to_db(maxf(0.0001, smoothstep(0.05, 0.9, _shown) * 0.9))
    _beat += delta
    var step_len := 60.0 / BPM / 2.0
    while _beat >= step_len:
        _beat -= step_len
        _tick()

func _tick() -> void:
    var i := _step % 8
    var bar := int(_step / 8.0) % 4
    if i == 0 and bar == 0:
        _pattern = _rng.randi_range(0, 2)
    var chord: Array = CHORDS[bar]
    var l := _shown
    if i == 0:
        play_semitone("pad", float(chord[0]) - 12.0, -24.0 + 12.0 * l)
    if l >= 0.2:
        var arp := [[0, 1, 2, 1, 0, 1, 2, 1], [0, 2, 1, 2, 0, 2, 1, 2], [0, 1, 2, 2, 1, 0, 1, 2]][_pattern] as Array
        play_semitone("pluck", float(chord[arp[i]]), -26.0 + 10.0 * l)
    if l >= 0.5:
        if i == 0 or i == 4:
            play_semitone("pluck", float(chord[0]) - 24.0, -17.0 + 4.0 * l)
        if i == 0:
            play_semitone("pad", float(chord[1]), -26.0 + 8.0 * l)
            play_semitone("pad", float(chord[2]), -27.0 + 8.0 * l)
    if l >= 0.75 and (i == 0 or i == 3 or i == 6):
        var melody: Array = GameState.final_melody
        if not melody.is_empty():
            var n: String = melody[(_step / 3) % melody.size()]
            var semis := {"C": 3.0, "E": 7.0, "G": 10.0, "A": 12.0}[n] as float
            play_semitone("bell", semis, -20.0 + 6.0 * l)
    _step += 1
