extends Node
## Entry point: title screen <-> game. Supports a few CLI user args for
## automated checks:  -- --autostart --seed=123 --screenshot=/tmp/a.png --shot-after=3

var title: TitleScreen
var game: Game
var _args := {}

func _ready() -> void:
    for a in OS.get_cmdline_user_args():
        var kv := a.trim_prefix("--").split("=", true, 1)
        _args[kv[0]] = kv[1] if kv.size() > 1 else "1"
    if _args.has("autostart"):
        _start(int(_args.get("seed", "1")))
    else:
        _show_title()
    if _args.has("screenshot"):
        var wait := float(_args.get("shot-after", "3"))
        get_tree().create_timer(wait).timeout.connect(_shot)

func _show_title() -> void:
    if game != null:
        game.queue_free()
        game = null
    get_tree().paused = false
    AudioManager.level = 0.0
    AudioManager.start_music(7)
    title = TitleScreen.new()
    add_child(title)
    title.start_requested.connect(_start)

func _start(seed_value: int) -> void:
    if title != null:
        title.queue_free()
        title = null
    if game != null:
        game.queue_free()
        game = null
    GameState.new_game(seed_value)
    game = Game.new()
    add_child(game)
    game.restart_requested.connect(func(s): _start.call_deferred(s))
    game.menu_requested.connect(func(): _show_title.call_deferred())
    if _args.get("cheat", "") != "":
        _apply_cheat.call_deferred(str(_args["cheat"]))

## Developer-only helper for screenshots/tests: --cheat=restore|abilities
func _apply_cheat(mode: String) -> void:
    for a in SData.ABILITIES:
        GameState.abilities[a] = true
    GameState.selected_ability = "growth"
    if mode == "restore":
        for id in GameState.features:
            GameState.features[id]["done"] = true
        GameState.fragments = SData.FRAGMENTS_NEEDED
        game.world.snap_levels()
    if _args.has("at"):
        var p: PackedStringArray = str(_args["at"]).split(",")
        game.player.position = Vector2(float(p[0]), float(p[1])) * SData.TILE

func _shot() -> void:
    var img := get_viewport().get_texture().get_image()
    img.save_png(str(_args["screenshot"]))
    print("screenshot saved: ", _args["screenshot"])
    get_tree().quit()
