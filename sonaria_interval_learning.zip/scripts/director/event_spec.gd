class_name EventSpec
extends RefCounted
## Event Specification schema + per-type rule table.
##
## Spec (plain Dictionary, JSON-serialisable):
##   event_type, region, site_id, difficulty(1-3), required_ability,
##   reward {type, amount}, world_effect, [puzzle], [secret], [target_puzzle],
##   [text], source ("rules" | "llm" | "fallback"), id

const RULES := {
    "hidden_shrine": {"effects": ["reveal_shrine"], "rewards": ["musical_fragment", "echo_petals"], "site_kind": "shrine", "weight": 40.0, "max": 3, "cooldown": 70.0, "corruption": false},
    "musical_creature": {"effects": ["reveal_secret"], "rewards": ["hint", "echo_petals"], "site_kind": "creature", "weight": 30.0, "max": 3, "cooldown": 60.0, "corruption": false},
    "environment_puzzle": {"effects": ["spawn_chime_puzzle"], "rewards": ["echo_petals", "musical_fragment"], "site_kind": "puzzle", "weight": 28.0, "max": 2, "cooldown": 90.0, "corruption": false},
    "corruption_shift": {"effects": ["heal_corruption"], "rewards": ["echo_petals", "none"], "site_kind": "corruption", "weight": 30.0, "max": 6, "cooldown": 45.0, "corruption": true},
    "route_opening": {"effects": ["open_route"], "rewards": ["none"], "site_kind": "route", "weight": 30.0, "max": 2, "cooldown": 80.0, "corruption": false},
    "discovery": {"effects": ["spawn_discovery"], "rewards": ["echo_petals", "musical_fragment"], "site_kind": "discovery", "weight": 30.0, "max": 6, "cooldown": 35.0, "corruption": false},
    "tutorial_assist": {"effects": ["simplify_puzzle"], "rewards": ["hint"], "site_kind": "none", "weight": 10.0, "max": 8, "cooldown": 40.0, "corruption": false},
    "ability_lesson": {"effects": ["spawn_practice_target"], "rewards": ["echo_petals"], "site_kind": "practice", "weight": 10.0, "max": 3, "cooldown": 5.0, "corruption": true},
}
const SECRETS := ["objective_hint", "hidden_cache"]
const KEYS := ["event_type", "region", "site_id", "difficulty", "required_ability", "reward", "world_effect", "text", "secret", "target_puzzle"]
const REWARD_MAX := {"musical_fragment": 1, "echo_petals": 5, "hint": 1, "none": 0}
const REGION_CORRUPTION_LIMIT := 0.85

static var _counter := 0

static func next_id() -> String:
    _counter += 1
    return "evt_%04d" % _counter

static func reset_counter() -> void:
    _counter = 0

## Strip an untrusted dictionary (e.g. from an LLM) down to whitelisted keys.
## Values keep their (possibly wrong) types so the validator can reject them.
static func normalize(raw: Variant) -> Dictionary:
    if typeof(raw) != TYPE_DICTIONARY:
        return {}
    var spec := {}
    for k in KEYS:
        if raw.has(k):
            spec[k] = raw[k]
    if spec.has("reward"):
        var r = spec["reward"]
        if typeof(r) == TYPE_STRING:
            spec["reward"] = {"type": r, "amount": 1 if r == "musical_fragment" else 3}
        elif typeof(r) == TYPE_DICTIONARY:
            spec["reward"] = {"type": r.get("type", ""), "amount": r.get("amount", 1)}
    if spec.has("difficulty") and typeof(spec["difficulty"]) == TYPE_FLOAT:
        spec["difficulty"] = int(spec["difficulty"])
    if spec.has("text"):
        spec["text"] = sanitize_text(spec["text"])
    spec["required_ability"] = spec.get("required_ability", "none")
    spec["source"] = "llm"
    return spec

static func sanitize_text(t: Variant) -> String:
    var s := str(t)
    var out := ""
    for ch in s:
        if ch in "[]<>{}\\`$":
            continue
        out += ch
    return out.strip_edges().left(140)

static func make(type: String, site_id: String, region: String, difficulty: int, ability: String, reward_type: String, amount: int, effect: String, source := "rules") -> Dictionary:
    return {
        "id": next_id(), "event_type": type, "region": region, "site_id": site_id,
        "difficulty": difficulty, "required_ability": ability,
        "reward": {"type": reward_type, "amount": amount}, "world_effect": effect, "source": source,
    }
