class_name WorldQuery
extends RefCounted
## Read-only view of the world used by the Validator and the Director.
## The default implementation is permissive (used by unit tests); World
## provides the real one (WorldQueryImpl) backed by the collision grid.

func site_reachable(_site_id: String) -> bool:
    return true

func route_ready(_site_id: String) -> bool:
    return true

func practice_spot_ok() -> bool:
    return true

func patch_healed(_site_id: String) -> bool:
    return false

func player_pos() -> Vector2:
    return SData.START_TILE * SData.TILE
