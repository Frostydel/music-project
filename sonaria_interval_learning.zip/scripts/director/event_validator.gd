class_name EventValidator
extends RefCounted
## Rejects anything that is unsupported, unavailable, unreachable, repeated or
## unsolvable. Pure function of (spec, state snapshot, world query).

static func validate(spec: Dictionary, snap: Dictionary, q: WorldQuery) -> Dictionary:
    var errors: Array = []
    var t = spec.get("event_type", "")
    if typeof(t) != TYPE_STRING or not EventSpec.RULES.has(t):
        return {"ok": false, "errors": ["unsupported event_type '%s'" % str(t)]}
    var rule: Dictionary = EventSpec.RULES[t]
    var owned: Array = snap.get("abilities", [])

    # --- difficulty
    var d = spec.get("difficulty", 1)
    if typeof(d) != TYPE_INT or d < 1 or d > 3:
        errors.append("difficulty must be an integer 1-3")
    elif d > int(snap.get("difficulty", 1)) + 1:
        errors.append("difficulty spike (%d vs player %d)" % [d, snap.get("difficulty", 1)])

    # --- ability
    var ab = spec.get("required_ability", "none")
    if typeof(ab) != TYPE_STRING or (ab != "none" and not SData.ABILITIES.has(ab)):
        errors.append("invalid ability '%s'" % str(ab))
        ab = "none"
    elif ab != "none" and not owned.has(ab):
        errors.append("ability '%s' not unlocked yet" % ab)

    # --- effect
    var eff = spec.get("world_effect", "")
    if typeof(eff) != TYPE_STRING or not rule["effects"].has(eff):
        errors.append("world_effect '%s' not allowed for %s" % [str(eff), t])

    # --- reward
    var rw = spec.get("reward", {})
    var rtype := ""
    if typeof(rw) != TYPE_DICTIONARY:
        errors.append("reward must be an object")
    else:
        rtype = str(rw.get("type", ""))
        var amt = rw.get("amount", 0)
        if not rule["rewards"].has(rtype):
            errors.append("reward '%s' impossible for %s" % [rtype, t])
        elif typeof(amt) != TYPE_INT or amt < 0 or amt > int(EventSpec.REWARD_MAX.get(rtype, 0)):
            errors.append("reward amount out of range")
        if rtype == "musical_fragment":
            var supply := int(snap.get("fragments", 0)) + int(snap.get("pending_fragments", 0)) + int(snap.get("undone_main_fragments", 0))
            if supply >= SData.FRAGMENTS_MAX:
                errors.append("fragment supply exhausted (%d/%d)" % [supply, SData.FRAGMENTS_MAX])

    # --- text (untrusted)
    if spec.has("text") and (typeof(spec["text"]) != TYPE_STRING or String(spec["text"]).length() > 140):
        errors.append("text invalid")

    # --- repetition
    var counts: Dictionary = snap.get("event_counts", {})
    if int(counts.get(t, 0)) >= int(rule["max"]):
        errors.append("%s used too often" % t)
    var last: Dictionary = snap.get("event_last_time", {})
    if last.has(t) and float(snap.get("time", 0.0)) - float(last[t]) < float(rule["cooldown"]):
        errors.append("%s on cooldown" % t)

    # --- region consistency
    var region = spec.get("region", "")
    if typeof(region) != TYPE_STRING or not SData.REGIONS.has(region):
        errors.append("unknown region")
        region = ""
    var rlevel := float(snap.get("region_levels", {}).get(region, 0.0))
    if rule["corruption"] and region != "" and rlevel >= EventSpec.REGION_CORRUPTION_LIMIT:
        errors.append("region already restored; corruption-dependent event invalid")

    # --- site
    var site_id = spec.get("site_id", "")
    var kind: String = rule["site_kind"]
    if kind == "none":
        pass
    elif kind == "practice":
        if site_id != "near_player" or not q.practice_spot_ok():
            errors.append("no valid practice spot")
    else:
        if typeof(site_id) != TYPE_STRING or not SData.SITES.has(site_id):
            errors.append("unknown site '%s'" % str(site_id))
        else:
            var site: Dictionary = SData.SITES[site_id]
            if site["kind"] != kind:
                errors.append("site kind mismatch")
            if region != "" and site["region"] != region:
                errors.append("region does not match site")
            if snap.get("used_sites", []).has(site_id):
                errors.append("site already used")
            elif not q.site_reachable(site_id):
                errors.append("site unreachable")
            if kind == "shrine" and not site["abilities"].has(ab):
                errors.append("shrine site does not support ability '%s'" % str(ab))
            if kind == "route":
                if not snap.get("flags", {}).get("bridge_grown", false):
                    errors.append("route requires the main bridge")
                elif not q.route_ready(site_id):
                    errors.append("route endpoints not both reachable")
            if kind == "corruption":
                if q.patch_healed(site_id) or snap.get("flags", {}).get("healed_" + site_id, false):
                    errors.append("corruption already healed")
                elif rlevel < 0.25:
                    errors.append("region not restored enough to change")

    # --- per-type prerequisites
    match t:
        "ability_lesson":
            if ab == "none" or not snap.get("lesson_pending", []).has(ab):
                errors.append("lesson ability was not just unlocked")
        "tutorial_assist":
            var tp = spec.get("target_puzzle", "")
            var fails: Dictionary = snap.get("failures", {})
            if typeof(tp) != TYPE_STRING or int(fails.get(tp, 0)) < 2 or snap.get("puzzles_done", []).has(tp):
                errors.append("no struggling puzzle to assist")
            if ab != "none":
                errors.append("assist needs no ability")
        "musical_creature":
            if not EventSpec.SECRETS.has(spec.get("secret", "objective_hint")):
                errors.append("unknown secret kind")
        "hidden_shrine", "environment_puzzle":
            if spec.has("puzzle") and not PuzzleGenerator.is_solvable(spec["puzzle"]):
                errors.append("puzzle is not solvable")
            if t == "environment_puzzle" and spec.has("puzzle") and spec["puzzle"].get("kind", "") != "order":
                errors.append("environment puzzle must be an order puzzle")

    return {"ok": errors.is_empty(), "errors": errors}
