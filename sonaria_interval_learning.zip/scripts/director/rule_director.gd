class_name RuleDirector
extends RefCounted
## Rule-based Director: generates every candidate event, discards invalid
## ones with the Validator, scores the rest against player behaviour and
## picks one (weighted among the best three) using the seeded RNG.

const THRESHOLD := 20.0

static func decide(snap: Dictionary, q: WorldQuery, rng: RandomNumberGenerator, trigger: String) -> Dictionary:
    var cands: Array = []
    var rejected := 0
    for spec in _generate(snap, q):
        var res := EventValidator.validate(spec, snap, q)
        if not res["ok"]:
            rejected += 1
            continue
        var sc := _score(spec, snap, trigger)
        cands.append({"spec": spec, "score": sc["score"], "reasons": sc["reasons"]})
    if cands.is_empty():
        return {"spec": {}, "considered": 0, "rejected": rejected, "trigger": trigger, "reasons": ["no valid candidate"]}
    cands.sort_custom(func(a, b): return a["score"] > b["score"])
    if cands[0]["score"] < THRESHOLD:
        return {"spec": {}, "considered": cands.size(), "rejected": rejected, "trigger": trigger, "reasons": ["best score %.0f below threshold" % cands[0]["score"]]}
    var top: Array = cands.slice(0, mini(3, cands.size()))
    var ranked: Array = []
    for c in top:
        ranked.append({"type": c["spec"]["event_type"], "site": c["spec"]["site_id"], "reward": c["spec"]["reward"]["type"], "score": c["score"]})
    var floor_score: float = top[top.size() - 1]["score"]
    var total := 0.0
    for c in top:
        total += maxf(1.0, c["score"] - floor_score + 10.0)
    var roll := rng.randf() * total
    var pick: Dictionary = top[0]
    for c in top:
        roll -= maxf(1.0, c["score"] - floor_score + 10.0)
        if roll <= 0.0:
            pick = c
            break
    var spec: Dictionary = pick["spec"].duplicate(true)
    materialize(spec, rng)
    return {"spec": spec, "score": pick["score"], "reasons": pick["reasons"], "considered": cands.size(), "rejected": rejected, "trigger": trigger, "ranked": ranked}

## Attach generated content (puzzles) to a chosen spec. Puzzles never come
## from an LLM: they are always produced by the deterministic generator.
static func materialize(spec: Dictionary, rng: RandomNumberGenerator) -> void:
    var d: int = int(spec.get("difficulty", 1))
    match spec.get("event_type", ""):
        "hidden_shrine":
            spec["puzzle"] = PuzzleGenerator.event_melody(rng, d)
        "environment_puzzle":
            spec["puzzle"] = PuzzleGenerator.event_order(rng, 3)
    if not spec.has("id"):
        spec["id"] = EventSpec.next_id()

static func _generate(snap: Dictionary, q: WorldQuery) -> Array:
    var out: Array = []
    var d: int = clampi(int(snap["difficulty"]) - (1 if int(snap["recent_failures"]) >= 2 else 0), 1, 3)
    var owned: Array = snap["abilities"]
    for site_id in SData.SITES:
        var s: Dictionary = SData.SITES[site_id]
        var region: String = s["region"]
        match s["kind"]:
            "shrine":
                for ab in s["abilities"]:
                    if ab != "none" and not owned.has(ab):
                        continue
                    out.append(EventSpec.make("hidden_shrine", site_id, region, d, ab, "musical_fragment", 1, "reveal_shrine"))
                    out.append(EventSpec.make("hidden_shrine", site_id, region, d, ab, "echo_petals", 3, "reveal_shrine"))
            "creature":
                for secret in EventSpec.SECRETS:
                    var sp := EventSpec.make("musical_creature", site_id, region, 1, "none", "hint", 1, "reveal_secret")
                    sp["secret"] = secret
                    out.append(sp)
            "puzzle":
                out.append(EventSpec.make("environment_puzzle", site_id, region, d, "none", "echo_petals", 4, "spawn_chime_puzzle"))
                out.append(EventSpec.make("environment_puzzle", site_id, region, d, "none", "musical_fragment", 1, "spawn_chime_puzzle"))
            "corruption":
                out.append(EventSpec.make("corruption_shift", site_id, region, 1, "none", "echo_petals", 2, "heal_corruption"))
            "route":
                out.append(EventSpec.make("route_opening", site_id, region, 1, "none", "none", 0, "open_route"))
            "discovery":
                out.append(EventSpec.make("discovery", site_id, region, 1, "none", "echo_petals", 3, "spawn_discovery"))
                out.append(EventSpec.make("discovery", site_id, region, 1, "none", "musical_fragment", 1, "spawn_discovery"))
    for ab in snap["lesson_pending"]:
        out.append(EventSpec.make("ability_lesson", "near_player", snap["region"], 1, ab, "echo_petals", 2, "spawn_practice_target"))
    var worst := ""
    var worst_n := 1
    for pid in snap["failures"]:
        if int(snap["failures"][pid]) > worst_n and not snap["puzzles_done"].has(pid):
            worst = pid
            worst_n = int(snap["failures"][pid])
    if worst != "":
        var ta := EventSpec.make("tutorial_assist", "", snap["region"], 1, "none", "hint", 1, "simplify_puzzle")
        ta["target_puzzle"] = worst
        out.append(ta)
    return out

static func _score(spec: Dictionary, snap: Dictionary, trigger: String) -> Dictionary:
    var t: String = spec["event_type"]
    var score: float = EventSpec.RULES[t]["weight"]
    var why: Array = []
    var region: String = spec["region"]
    var cur: String = snap["region"]
    var expl: float = float(snap["exploration"].get(region, 0.0))
    var count := int(snap["event_counts"].get(t, 0))
    if count > 0:
        score -= 25.0 * count
        why.append("-%d repeat penalty" % (25 * count))
    if region == cur:
        score += 12.0
        why.append("+12 in current region")
    elif t != "tutorial_assist" and t != "ability_lesson":
        score -= 8.0
    var struggling: bool = int(snap["recent_failures"]) >= 2
    var needs_fragment: bool = (int(snap["fragments"]) + int(snap["pending_fragments"]) + int(snap["undone_main_fragments"])) < SData.FRAGMENTS_NEEDED
    var is_frag: bool = spec["reward"]["type"] == "musical_fragment"
    match t:
        "ability_lesson":
            score += 120.0
            why.append("+120 player just unlocked %s" % spec["required_ability"])
        "tutorial_assist":
            var f := int(snap["failures"].get(spec.get("target_puzzle", ""), 0))
            score += 60.0 + 30.0 * float(f - 2)
            why.append("+%d player failed '%s' %d times" % [60 + 30 * (f - 2), spec.get("target_puzzle", ""), f])
        "hidden_shrine":
            if expl >= 0.4:
                score += 40.0
                why.append("+40 region thoroughly explored (%.0f%%)" % (expl * 100.0))
            if needs_fragment and is_frag and (snap["puzzles_done"].size() >= 2 or float(snap["exploration_total"]) >= 0.3):
                score += 110.0
                why.append("+110 a fragment is still missing from the supply")
            elif is_frag and not needs_fragment:
                score -= 20.0
                why.append("-20 bonus fragment, not required")
            if struggling:
                score -= 30.0
                why.append("-30 player is struggling")
            if spec["required_ability"] != "none":
                score += 6.0
        "musical_creature":
            if not snap["visited_regions"].has(region) or float(snap["time_since_progress"]) > 120.0:
                score += 25.0
                why.append("+25 player needs direction")
            if spec.get("secret", "") == "hidden_cache" and expl >= 0.4:
                score += 12.0
            if spec.get("secret", "") == "objective_hint" and float(snap["time_since_progress"]) > 120.0:
                score += 25.0
        "environment_puzzle":
            if snap["abilities"].size() >= 2 and int(snap["difficulty"]) >= 2:
                score += 20.0
                why.append("+20 player is ready for more puzzles")
            if struggling:
                score -= 30.0
            if needs_fragment and is_frag:
                score += 50.0
        "corruption_shift":
            if snap["recent_restore_region"] == region:
                score += 55.0
                why.append("+55 region just changed after a restoration")
            if trigger == "feature_restored":
                score += 15.0
        "route_opening":
            if snap["region_complete"].get("grove", false) or float(snap["exploration_total"]) > 0.35:
                score += 35.0
                why.append("+35 player is shuttling between banks")
        "discovery":
            if expl < 0.45 and region == cur:
                score += 14.0
            if float(snap["exploration_total"]) >= 0.3:
                score += 20.0
                why.append("+20 exploration rewarded")
            if needs_fragment and is_frag:
                score += 35.0
            elif is_frag:
                score -= 15.0
    if trigger == "region_entered" and (t == "musical_creature" or t == "discovery"):
        score += 15.0
        why.append("+15 new region entered")
    if struggling and spec["difficulty"] > 1:
        score -= 20.0
    return {"score": score, "reasons": why}
