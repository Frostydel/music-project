class_name FallbackEvents
extends RefCounted
## Safe, predefined events used whenever generation or validation fails.
## They are still validated before use, so they can never break the game.

static func templates() -> Array:
    var list: Array = []
    for site_id in SData.sites_of_kind("discovery"):
        var s: Dictionary = SData.SITES[site_id]
        var sp := EventSpec.make("discovery", site_id, s["region"], 1, "none", "echo_petals", 3, "spawn_discovery", "fallback")
        sp["id"] = "fallback_" + site_id
        list.append(sp)
    var nook := EventSpec.make("hidden_shrine", "shrine_glade_nook", "glade", 1, "none", "musical_fragment", 1, "reveal_shrine", "fallback")
    nook["id"] = "fallback_nook_fragment"
    list.push_front(nook)
    return list

static func pick(snap: Dictionary, q: WorldQuery, rng: RandomNumberGenerator, want_fragment := false) -> Dictionary:
    for tpl in templates():
        var spec: Dictionary = tpl.duplicate(true)
        if want_fragment and spec["reward"]["type"] != "musical_fragment":
            continue
        var res := EventValidator.validate(spec, snap, q)
        if not res["ok"] and spec["event_type"] == "hidden_shrine":
            spec["reward"] = {"type": "echo_petals", "amount": 3}
            res = EventValidator.validate(spec, snap, q)
        if res["ok"]:
            RuleDirector.materialize(spec, rng)
            return spec
    return {}
