class_name EventExecutor
extends RefCounted
## The ONLY bridge from an event spec to the game world. It maps whitelisted
## world_effect names to World methods; unknown effects are never executed,
## and the spec is re-validated immediately before activation.

const HANDLERS := {
    "reveal_shrine": "exec_reveal_shrine",
    "reveal_secret": "exec_reveal_secret",
    "spawn_chime_puzzle": "exec_spawn_chime_puzzle",
    "heal_corruption": "exec_heal_corruption",
    "open_route": "exec_open_route",
    "spawn_discovery": "exec_spawn_discovery",
    "simplify_puzzle": "exec_simplify_puzzle",
    "spawn_practice_target": "exec_spawn_practice_target",
}

var world: Object

func _init(w: Object) -> void:
    world = w

func execute(spec: Dictionary, snap: Dictionary, q: WorldQuery) -> bool:
    var res := EventValidator.validate(spec, snap, q)
    if not res["ok"]:
        return false
    var handler: String = HANDLERS.get(spec.get("world_effect", ""), "")
    if handler == "" or world == null or not world.has_method(handler):
        return false
    return bool(world.call(handler, spec))
