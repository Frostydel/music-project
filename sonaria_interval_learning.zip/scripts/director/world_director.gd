class_name WorldDirector
extends Node
## AI World Director orchestrator.
##   GameState snapshot -> (LLM proposal | RuleDirector) -> Validator
##   -> EventExecutor -> World, with FallbackEvents when anything fails.

signal decision_made(decision: Dictionary)

const TICK := 6.0
const MIN_GAP := 28.0
const PRIORITY_GAP := 4.0
const MAX_ACTIVE := 2

var world: Object
var query: WorldQuery
var executor: EventExecutor
var llm: LLMAdapter
var enabled := true
var log: Array = []
var last_decision: Dictionary = {}
var _since_tick := 0.0
var _last_event_time := -100.0
var _inflight := false
var _inflight_trigger := ""
var _queued_trigger := ""

func setup(world_node: Object, q: WorldQuery) -> void:
    world = world_node
    query = q
    executor = EventExecutor.new(world_node)
    llm = LLMAdapter.new()
    add_child(llm)
    llm.proposal_ready.connect(_on_llm)

func _ready() -> void:
    GameState.ability_unlocked.connect(func(_a): request("ability_unlocked", true))
    GameState.puzzle_failed.connect(func(_id, n): if n >= 2: request("puzzle_failed", true))
    GameState.region_changed.connect(func(_r): request("region_entered"))
    GameState.feature_restored.connect(func(_id, _r): request("feature_restored"))
    GameState.puzzle_completed.connect(func(_id): request("puzzle_completed"))

func _process(delta: float) -> void:
    _since_tick += delta
    if _since_tick >= TICK:
        _since_tick = 0.0
        if _queued_trigger != "":
            var t := _queued_trigger
            _queued_trigger = ""
            request(t, true)
        else:
            request("tick")

## Ask the Director for an event. Respects pacing unless `priority`.
func request(trigger: String, priority := false) -> void:
    if not enabled or _inflight or not GameState.game_active or GameState.won or world == null:
        return
    var gap := PRIORITY_GAP if priority else MIN_GAP
    if GameState.playtime - _last_event_time < gap:
        if priority:
            _queued_trigger = trigger
        return
    if world.active_event_count() >= MAX_ACTIVE and not priority:
        return
    var snap := GameState.snapshot()
    if llm.is_enabled() and not llm.is_busy() and trigger != "ability_unlocked":
        _inflight = true
        _inflight_trigger = trigger
        llm.request_proposal(snap)
        return
    _apply(RuleDirector.decide(snap, query, GameState.rng_director, trigger), snap, trigger)

func _on_llm(spec: Dictionary, status: String) -> void:
    _inflight = false
    var snap := GameState.snapshot()
    var trigger := _inflight_trigger
    if status == "ok":
        var res := EventValidator.validate(_prepare_llm(spec, snap), snap, query)
        if res["ok"]:
            var prepared := _prepare_llm(spec, snap)
            RuleDirector.materialize(prepared, GameState.rng_director)
            _apply({"spec": prepared, "score": 0.0, "reasons": ["accepted LLM proposal"], "trigger": trigger, "considered": 1, "rejected": 0}, snap, trigger)
            return
        _record({"spec": {}, "reasons": ["LLM proposal rejected: " + "; ".join(res["errors"]), "falling back to rules"], "trigger": trigger, "llm_status": "rejected"})
    else:
        _record({"spec": {}, "reasons": ["LLM unavailable (%s); using rules" % status], "trigger": trigger, "llm_status": status})
    _apply(RuleDirector.decide(snap, query, GameState.rng_director, trigger), snap, trigger)

## Fill defaults an LLM may omit (site/region) from the rule tables, so the
## validator judges a complete spec. Nothing here trusts the LLM's values.
func _prepare_llm(spec: Dictionary, snap: Dictionary) -> Dictionary:
    var s := spec.duplicate(true)
    s["id"] = EventSpec.next_id() if not s.has("id") else s["id"]
    var t = s.get("event_type", "")
    if typeof(t) != TYPE_STRING or not EventSpec.RULES.has(t):
        return s
    var kind: String = EventSpec.RULES[t]["site_kind"]
    if kind == "practice":
        s["site_id"] = "near_player"
        s["region"] = snap["region"]
    elif kind == "none":
        s["site_id"] = ""
        s["region"] = snap["region"]
    elif not s.has("site_id") or not SData.SITES.has(s["site_id"]):
        # choose the first valid site of that kind deterministically
        for sid in SData.sites_of_kind(kind):
            var probe := s.duplicate(true)
            probe["site_id"] = sid
            probe["region"] = SData.SITES[sid]["region"]
            if EventValidator.validate(probe, snap, query)["ok"]:
                return probe
    elif SData.SITES.has(s.get("site_id", "")):
        s["region"] = SData.SITES[s["site_id"]]["region"]
    return s

func _apply(decision: Dictionary, snap: Dictionary, trigger: String) -> void:
    var spec: Dictionary = decision.get("spec", {})
    var executed := false
    if not spec.is_empty():
        executed = executor.execute(spec, snap, query)
        if not executed:
            decision["reasons"] = decision.get("reasons", []) + ["executor refused; using fallback"]
    var need_fallback: bool = (not spec.is_empty() and not executed) or (spec.is_empty() and _wants_fallback(trigger) and int(decision.get("considered", 0)) == 0)
    if not executed and need_fallback:
        var missing: bool = int(snap["fragments"]) + int(snap["pending_fragments"]) + int(snap["undone_main_fragments"]) < SData.FRAGMENTS_NEEDED and snap["puzzles_done"].size() >= 2
        var fb := FallbackEvents.pick(snap, query, GameState.rng_director, missing)
        if not fb.is_empty() and executor.execute(fb, snap, query):
            spec = fb
            executed = true
            decision["spec"] = fb
            decision["reasons"] = decision.get("reasons", []) + ["fallback event used"]
    decision["executed"] = executed
    if executed:
        _last_event_time = GameState.playtime
        GameState.event_history.append({"type": spec["event_type"], "site": spec.get("site_id", ""), "time": GameState.playtime, "source": spec.get("source", "rules"), "id": spec["id"]})
    _record(decision)

func _wants_fallback(trigger: String) -> bool:
    return trigger == "ability_unlocked" or trigger == "puzzle_failed" or trigger == "region_entered"

func _record(decision: Dictionary) -> void:
    decision["time"] = GameState.playtime
    log.append(decision)
    last_decision = decision
    decision_made.emit(decision)

## Synchronous, LLM-free evaluation (used by tests and the debug tools).
func evaluate_now(trigger: String) -> Dictionary:
    var snap := GameState.snapshot()
    _apply(RuleDirector.decide(snap, query, GameState.rng_director, trigger), snap, trigger)
    return last_decision
