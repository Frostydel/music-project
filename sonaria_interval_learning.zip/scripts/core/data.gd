class_name SData
extends RefCounted
## Static game constants: palette, notes, regions and the catalogue of
## predefined spawn sites. Procedural generation only ever picks from these
## known-valid locations, so generated content cannot break the level.

const TILE := 32
const MAP_W := 64
const MAP_H := 40
const MAP_PX := Vector2(MAP_W * TILE, MAP_H * TILE)
const START_TILE := Vector2(4.5, 20.5)

const ABILITIES: Array = ["growth", "resonance", "flow"]
const NOTES: Array = ["C", "E", "G", "A"]
const NOTE_FREQ := {"C": 523.25, "E": 659.25, "G": 783.99, "A": 880.0}
const NOTE_COLOR := {"C": Color("5ee0a0"), "E": Color("b48cff"), "G": Color("5ab8ff"), "A": Color("ffd27a")}
const ABILITY_NOTE := {"growth": "C", "resonance": "E", "flow": "G"}
const ABILITY_LABEL := {"growth": "Growth", "resonance": "Resonance", "flow": "Flow"}
const FRAGMENTS_NEEDED := 4
const FRAGMENTS_MAX := 5
const ROMAN := ["I", "II", "III", "IV", "V", "VI", "VII", "VIII"]

const REGION_NAMES := {
    "glade": "The Hushed Glade", "grove": "Whispering Grove",
    "ruins": "The Sunken Ruins", "sanctum": "Heart Sanctum",
}
const REGIONS: Array = ["glade", "grove", "ruins", "sanctum"]

const GROUND_DEAD := Color("34334a")
const GROUND_ALIVE_A := Color("1d5c63")
const GROUND_ALIVE_B := Color("245a78")
const PATH_DEAD := Color("4a4560")
const PATH_ALIVE := Color("8c7aa8")
const TRUNK_DEAD := Color("3a3445")
const TRUNK_ALIVE := Color("5e4a78")
const CANOPY_DEAD := Color("4b4760")
const CANOPY_ALIVE_A := Color("2fbf9f")
const CANOPY_ALIVE_B := Color("7a5fd0")
const STONE_DEAD := Color("56546a")
const STONE_ALIVE := Color("8e88b8")
const GOLD := Color("ffd98a")
const VIOLET := Color("9a7cff")
const TEAL := Color("4fe0d0")
const DEEP := Color("0b0d24")
const BLIGHT := Color("3c1f4d")

const RIVER_HALF := 2.0
## Tile rows (inclusive) of the three places the ravine can be bridged.
const GAPS := {"north": [7, 9], "main": [19, 21], "south": [31, 33]}

## Predefined, validated spawn sites (tile coordinates).
const SITES := {
    "shrine_glade_nook": {"kind": "shrine", "pos": Vector2(4.5, 6.5), "region": "glade", "abilities": ["none", "growth", "resonance", "flow"]},
    "shrine_mossy_hollow": {"kind": "shrine", "pos": Vector2(21.5, 5.0), "region": "grove", "abilities": ["growth", "none"]},
    "shrine_moonpool": {"kind": "shrine", "pos": Vector2(24.5, 34.5), "region": "grove", "abilities": ["flow", "none"]},
    "shrine_cairn": {"kind": "shrine", "pos": Vector2(42.5, 33.5), "region": "ruins", "abilities": ["resonance", "none"]},
    "creature_glade": {"kind": "creature", "pos": Vector2(11.5, 27.5), "region": "glade"},
    "creature_grove": {"kind": "creature", "pos": Vector2(25.5, 24.5), "region": "grove"},
    "creature_ruins": {"kind": "creature", "pos": Vector2(41.5, 11.5), "region": "ruins"},
    "puzzle_glade": {"kind": "puzzle", "pos": Vector2(12.5, 13.5), "region": "glade"},
    "puzzle_grove": {"kind": "puzzle", "pos": Vector2(26.5, 29.5), "region": "grove"},
    "puzzle_ruins": {"kind": "puzzle", "pos": Vector2(50.5, 31.5), "region": "ruins"},
    "discovery_glade_a": {"kind": "discovery", "pos": Vector2(13.5, 8.5), "region": "glade"},
    "discovery_glade_b": {"kind": "discovery", "pos": Vector2(6.5, 33.5), "region": "glade"},
    "discovery_grove_a": {"kind": "discovery", "pos": Vector2(27.5, 14.5), "region": "grove"},
    "discovery_grove_b": {"kind": "discovery", "pos": Vector2(21.5, 22.5), "region": "grove"},
    "discovery_ruins_a": {"kind": "discovery", "pos": Vector2(40.5, 7.5), "region": "ruins"},
    "discovery_ruins_b": {"kind": "discovery", "pos": Vector2(46.5, 33.5), "region": "ruins"},
    "route_north": {"kind": "route", "pos": Vector2(34.0, 8.5), "region": "grove", "gap": "north"},
    "route_south": {"kind": "route", "pos": Vector2(34.0, 32.5), "region": "grove", "gap": "south"},
    "corruption_glade_a": {"kind": "corruption", "pos": Vector2(14.5, 12.5), "region": "glade"},
    "corruption_glade_b": {"kind": "corruption", "pos": Vector2(13.5, 29.5), "region": "glade"},
    "corruption_grove_a": {"kind": "corruption", "pos": Vector2(22.5, 18.0), "region": "grove"},
    "corruption_grove_b": {"kind": "corruption", "pos": Vector2(28.5, 32.0), "region": "grove"},
    "corruption_ruins_a": {"kind": "corruption", "pos": Vector2(39.5, 15.5), "region": "ruins"},
    "corruption_ruins_b": {"kind": "corruption", "pos": Vector2(47.5, 30.5), "region": "ruins"},
}

static func region_at_tile(tx: float) -> String:
    if tx < 18.0:
        return "glade"
    if tx < 34.5:
        return "grove"
    if tx < 52.0:
        return "ruins"
    return "sanctum"

static func river_cx(ty: float) -> float:
    return 34.0 + 1.2 * sin(ty * 0.3)

static func sites_of_kind(kind: String) -> Array:
    var out: Array = []
    for id in SITES:
        if SITES[id]["kind"] == kind:
            out.append(id)
    return out

static func dir_text(from: Vector2, to: Vector2) -> String:
    var d := to - from
    if d.length() < 90.0:
        return "right beside you"
    var ang := rad_to_deg(atan2(d.y, d.x))
    var names := ["east", "south-east", "south", "south-west", "west", "north-west", "north", "north-east"]
    var idx := int(round(ang / 45.0))
    if idx < 0:
        idx += 8
    return "to the %s" % names[idx % 8]
