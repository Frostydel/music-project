class_name Fx
extends RefCounted
## Particle bursts, expanding rings and a shared soft glow texture.

static var _glow: GradientTexture2D

static func glow_texture() -> Texture2D:
    if _glow == null:
        var g := Gradient.new()
        g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
        g.offsets = PackedFloat32Array([0.0, 1.0])
        _glow = GradientTexture2D.new()
        _glow.gradient = g
        _glow.fill = GradientTexture2D.FILL_RADIAL
        _glow.fill_from = Vector2(0.5, 0.5)
        _glow.fill_to = Vector2(1.0, 0.5)
        _glow.width = 128
        _glow.height = 128
    return _glow

static func burst(parent: Node, pos: Vector2, color: Color, amount := 16, speed := 80.0, life := 0.9) -> void:
    if parent == null or not is_instance_valid(parent) or not Prefs.particles:
        return
    var p := CPUParticles2D.new()
    p.position = pos
    p.amount = amount
    p.lifetime = life
    p.one_shot = true
    p.explosiveness = 1.0
    p.texture = glow_texture()
    p.direction = Vector2(0, -1)
    p.spread = 180.0
    p.initial_velocity_min = speed * 0.4
    p.initial_velocity_max = speed
    p.gravity = Vector2(0, -20)
    p.scale_amount_min = 0.05
    p.scale_amount_max = 0.14
    p.color = color
    var ramp := Gradient.new()
    ramp.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0)])
    ramp.offsets = PackedFloat32Array([0.0, 1.0])
    p.color_ramp = ramp
    p.z_index = 40
    parent.add_child(p)
    p.emitting = true
    p.finished.connect(p.queue_free)

class RingFx extends Node2D:
    var color := Color.WHITE
    var max_r := 120.0
    var dur := 0.7
    var t := 0.0
    func _process(delta: float) -> void:
        t += delta
        queue_redraw()
        if t >= dur:
            queue_free()
    func _draw() -> void:
        var k := clampf(t / dur, 0.0, 1.0)
        var r := max_r * (1.0 - pow(1.0 - k, 3.0))
        draw_circle(Vector2.ZERO, r, Color(color.r, color.g, color.b, 0.10 * (1.0 - k)))
        draw_arc(Vector2.ZERO, r, 0.0, TAU, 56, Color(color.r, color.g, color.b, 1.0 - k), 1.0 + 3.0 * (1.0 - k))

static func ring(parent: Node, pos: Vector2, color: Color, max_r := 120.0, dur := 0.7) -> void:
    if parent == null or not is_instance_valid(parent):
        return
    var r := RingFx.new()
    r.position = pos
    r.color = color
    r.max_r = max_r
    r.dur = dur
    r.z_index = 40
    parent.add_child(r)
