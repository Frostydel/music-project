extends Node
## Central game state (autoload "GameState"). Single source of truth for
## progress, world features, failures and the seeded random streams.

signal ability_unlocked(ability: String)
signal fragments_changed(count: int)
signal petals_changed(count: int)
signal puzzle_completed(puzzle_id: String)
signal puzzle_failed(puzzle_id: String, fail_count: int)
signal feature_restored(feature_id: String, region: String)
signal region_completed(region: String)
signal region_changed(region: String)
signal objective_changed
signal event_resolved(spec: Dictionary)
signal toast(text: String, color: Color)
signal puzzle_requested(request: Dictionary)
signal dialogue_requested(request: Dictionary)
signal game_won

const MAIN_PUZZLES := ["awakening", "spring", "shrine"]
const COARSE := 128.0   # exploration cell size in pixels

var seed_value := 0
var abilities: Dictionary = {}
var selected_ability := "growth"
var fragments := 0
var petals := 0
var flags: Dictionary = {}
var features: Dictionary = {}       # id -> {region, weight, required, done}
var puzzles_done: Dictionary = {}
var puzzle_fails: Dictionary = {}
var failure_log: Array = []
var assist: Dictionary = {}         # puzzle id -> assist level granted by the Director
var hints_used := 0
var explored: Dictionary = {}
var explorable: Dictionary = {}     # region -> number of coarse cells (set by World)
var current_region := "glade"
var visited_regions: Dictionary = {}
var playtime := 0.0
var difficulty := 1
var event_history: Array = []
var pending_fragment_sources := 0
var lesson_pending: Array = []
var recent_restore_region := ""
var last_progress_time := 0.0
var puzzle_specs: Dictionary = {}
var final_melody: Array = []
var game_active := false
var won := false
var rng_world := RandomNumberGenerator.new()
var rng_director := RandomNumberGenerator.new()

func _ready() -> void:
    new_game(1)
    game_active = false

func new_game(seed_in: int) -> void:
    seed_value = seed_in
    abilities = {}
    for a in SData.ABILITIES:
        abilities[a] = false
    selected_ability = "growth"
    fragments = 0
    petals = 0
    flags = {}
    features = {}
    puzzles_done = {}
    puzzle_fails = {}
    failure_log = []
    assist = {}
    hints_used = 0
    explored = {}
    explorable = {}
    current_region = "glade"
    visited_regions = {"glade": true}
    playtime = 0.0
    difficulty = 1
    event_history = []
    pending_fragment_sources = 0
    lesson_pending = []
    recent_restore_region = ""
    last_progress_time = 0.0
    rng_world.seed = seed_in
    rng_director.seed = seed_in * 7919 + 104729
    puzzle_specs = PuzzleGenerator.main_puzzles(rng_world)
    final_melody = puzzle_specs["altar"]["notes"].duplicate()
    game_active = true
    won = false

func _process(delta: float) -> void:
    if game_active and not won:
        playtime += delta

# ------------------------------------------------------------ abilities etc.
func unlock_ability(a: String) -> void:
    if abilities.get(a, false):
        return
    abilities[a] = true
    selected_ability = a
    lesson_pending.append(a)
    last_progress_time = playtime
    ability_unlocked.emit(a)
    objective_changed.emit()

func add_fragment() -> Array:
    var idx := fragments
    fragments += 1
    last_progress_time = playtime
    fragments_changed.emit(fragments)
    objective_changed.emit()
    return final_melody.slice(idx * 2, idx * 2 + 2)

func add_petals(n: int) -> void:
    petals += n
    petals_changed.emit(petals)

func set_flag(f: String, v := true) -> void:
    flags[f] = v
    objective_changed.emit()

func has_flag(f: String) -> bool:
    return flags.get(f, false)

func complete_puzzle(id: String) -> void:
    puzzles_done[id] = true
    puzzle_fails[id] = 0
    last_progress_time = playtime
    _recompute_difficulty()
    puzzle_completed.emit(id)
    objective_changed.emit()

func record_failure(id: String) -> void:
    puzzle_fails[id] = int(puzzle_fails.get(id, 0)) + 1
    failure_log.append({"id": id, "t": playtime})
    _recompute_difficulty()
    puzzle_failed.emit(id, puzzle_fails[id])

func recent_failure_count(window := 90.0) -> int:
    var n := 0
    for f in failure_log:
        if playtime - float(f["t"]) <= window:
            n += 1
    return n

func _recompute_difficulty() -> void:
    var d := 1 + int(puzzles_done.size() / 2.0)
    if recent_failure_count() >= 3:
        d -= 1
    difficulty = clampi(d, 1, 3)

func set_region(r: String) -> void:
    if r == current_region:
        return
    current_region = r
    visited_regions[r] = true
    region_changed.emit(r)

# ------------------------------------------------------------ restoration
func register_feature(id: String, region: String, weight: float, required: bool) -> void:
    features[id] = {"region": region, "weight": weight, "required": required, "done": false}

func complete_feature(id: String) -> void:
    if not features.has(id) or features[id]["done"]:
        return
    features[id]["done"] = true
    var region: String = features[id]["region"]
    recent_restore_region = region
    last_progress_time = playtime
    feature_restored.emit(id, region)
    objective_changed.emit()
    if features[id]["required"] and region_complete(region):
        region_completed.emit(region)

func feature_done(id: String) -> bool:
    return features.has(id) and features[id]["done"]

func region_level(region: String) -> float:
    var total := 0.0
    var done := 0.0
    for id in features:
        var f: Dictionary = features[id]
        if f["region"] == region:
            total += f["weight"]
            if f["done"]:
                done += f["weight"]
    return done / total if total > 0.0 else 0.0

func region_complete(region: String) -> bool:
    var any := false
    for id in features:
        var f: Dictionary = features[id]
        if f["region"] == region and f["required"]:
            any = true
            if not f["done"]:
                return false
    return any

func overall_level() -> float:
    var total := 0.0
    var done := 0.0
    for id in features:
        var f: Dictionary = features[id]
        total += f["weight"]
        if f["done"]:
            done += f["weight"]
    return done / total if total > 0.0 else 0.0

func win() -> void:
    if won:
        return
    won = true
    game_won.emit()

# ------------------------------------------------------------ exploration
func mark_explored(pos: Vector2) -> void:
    var c := Vector2i(int(pos.x / COARSE), int(pos.y / COARSE))
    explored[c] = true

func exploration(region: String) -> float:
    var total: int = int(explorable.get(region, 0))
    if total <= 0:
        return 0.0
    var n := 0
    for c in explored:
        if SData.region_at_tile((float(c.x) + 0.5) * COARSE / SData.TILE) == region:
            n += 1
    return minf(1.0, float(n) / float(total))

func exploration_total() -> float:
    var total := 0
    for r in explorable:
        total += int(explorable[r])
    return minf(1.0, float(explored.size()) / float(maxi(total, 1)))

# ------------------------------------------------------------ fragments
func undone_main_fragment_sources() -> int:
    var n := 0
    for id in MAIN_PUZZLES:
        if not puzzles_done.has(id):
            n += 1
    return n

func fragment_supply() -> int:
    return fragments + pending_fragment_sources + undone_main_fragment_sources()

# ------------------------------------------------------------ snapshot
## Immutable summary handed to the Director / Validator / LLM adapter.
func snapshot() -> Dictionary:
    var owned: Array = []
    for a in SData.ABILITIES:
        if abilities.get(a, false):
            owned.append(a)
    var levels := {}
    var complete := {}
    var expl := {}
    for r in SData.REGIONS:
        levels[r] = region_level(r)
        complete[r] = region_complete(r)
        expl[r] = exploration(r)
    var counts := {}
    var last := {}
    var used: Array = []
    for e in event_history:
        counts[e["type"]] = int(counts.get(e["type"], 0)) + 1
        last[e["type"]] = e["time"]
        if e.get("site", "") != "":
            used.append(e["site"])
    var done: Array = puzzles_done.keys()
    var fails := puzzle_fails.duplicate()
    return {
        "seed": seed_value, "time": playtime, "region": current_region, "difficulty": difficulty,
        "abilities": owned, "fragments": fragments, "pending_fragments": pending_fragment_sources,
        "undone_main_fragments": undone_main_fragment_sources(), "petals": petals,
        "flags": flags.duplicate(), "puzzles_done": done, "failures": fails,
        "recent_failures": recent_failure_count(), "region_levels": levels, "region_complete": complete,
        "exploration": expl, "exploration_total": exploration_total(),
        "event_counts": counts, "event_last_time": last, "used_sites": used,
        "lesson_pending": lesson_pending.duplicate(), "recent_restore_region": recent_restore_region,
        "visited_regions": visited_regions.keys(), "time_since_progress": playtime - last_progress_time,
    }

# ------------------------------------------------------------ objectives
## Returns [primary objective, hint] strings for the HUD.
func objective_lines() -> Array:
    if won:
        return ["The Silence is broken. Sonaria sings again.", ""]
    var out: Array = []
    if not abilities["growth"]:
        out.append(["Wake the Awakening Stone", "Walk to the glowing stone east of your start and press E."])
    if abilities["growth"] and not has_flag("thicket_cleared"):
        out.append(["Clear the withered thicket", "Press 1, then Space (sing) beside the thorn wall on the east path."])
    if abilities["growth"] and not puzzles_done.has("spring"):
        out.append(["Restore the Spring Hollow", "In the grove's north-west, ring the four chimes in the mural's order (E)."])
    if has_flag("thicket_cleared") and not has_flag("bridge_grown"):
        out.append(["Grow a bridge over the ravine", "Sing Growth beside the Elder Willow at the ravine's west bank."])
    if has_flag("bridge_grown") and not puzzles_done.has("shrine"):
        out.append(["Unlock the Resonance Shrine", "Read the four Tablets of the Old Choir, then enter their notes at the shrine."])
    if puzzles_done.has("shrine") and not (feature_done("pillar_1") and feature_done("pillar_2")):
        out.append(["Awaken the ruin pillars", "Sing Resonance (select 2) beside both pillars near the sealed corridor."])
    if abilities["flow"] and puzzles_done.has("shrine") and not feature_done("silt_cleared"):
        out.append(["Wash away the silt barrier", "Sing Flow (select 3) at the dry aqueduct in the ruins."])
    if feature_done("pillar_1") and feature_done("pillar_2") and not feature_done("door_open"):
        out.append(["Open the sealed door", "Sing Resonance at the door once both pillars glow."])
    if puzzles_done.has("shrine") and fragments < SData.FRAGMENTS_NEEDED and out.size() < 2:
        out.append(["Find another melody fragment (%d/%d)" % [fragments, SData.FRAGMENTS_NEEDED], "Explore. Hidden shrines and creatures will reveal themselves."])
    if feature_done("door_open") and fragments >= SData.FRAGMENTS_NEEDED:
        out.append(["Restore the Main Melody", "Enter the Heart Sanctum and approach the altar."])
    if out.is_empty():
        out.append(["Explore Sonaria", "Seek hidden shrines, creatures and echo petals."])
    var first: Array = out[0]
    var line2: String = first[1]
    if out.size() > 1:
        line2 += "\nAlso: " + str(out[1][0])
    return [first[0], line2]
