class_name Game
extends Node
## One playthrough: world, player, Director, UI. Freed and rebuilt on restart.

signal restart_requested(seed_value: int)
signal menu_requested

var world: World
var player: Player
var director: WorldDirector
var hud: HUD
var puzzle_ui: PuzzleUI
var dialogue: DialoguePanel
var pause_menu: PauseMenu
var victory: VictoryScreen
var paused := false
var _pending_dialogues: Array = []
var _ui: CanvasLayer
var _overlay: CanvasLayer

func _ready() -> void:
    EventSpec.reset_counter()
    world = World.new()
    add_child(world)
    player = Player.new()
    player.world = world
    player.position = SData.START_TILE * SData.TILE
    world.objects.add_child(player)
    world.player = player
    director = WorldDirector.new()
    add_child(director)
    director.setup(world, world.query)
    world.director = director

    _ui = CanvasLayer.new()
    _ui.layer = 10
    add_child(_ui)
    hud = HUD.new()
    _ui.add_child(hud)
    dialogue = DialoguePanel.new()
    _ui.add_child(dialogue)
    puzzle_ui = PuzzleUI.new()
    _ui.add_child(puzzle_ui)
    _overlay = CanvasLayer.new()
    _overlay.layer = 20
    _overlay.process_mode = Node.PROCESS_MODE_ALWAYS
    add_child(_overlay)
    pause_menu = PauseMenu.new()
    _overlay.add_child(pause_menu)
    pause_menu.resume_requested.connect(_resume)
    pause_menu.restart_requested.connect(func(): _restart(GameState.seed_value))
    pause_menu.new_seed_requested.connect(func(): _restart(randi() % 1000000))
    pause_menu.menu_requested.connect(func(): _unpause(); menu_requested.emit())

    player.prompt_changed.connect(hud.set_prompt)
    director.decision_made.connect(hud.show_decision)
    GameState.puzzle_requested.connect(func(r): puzzle_ui.open(r))
    GameState.dialogue_requested.connect(_on_dialogue)
    GameState.region_completed.connect(_on_region_completed)
    GameState.game_won.connect(_on_won)
    for c in [puzzle_ui.opened, puzzle_ui.closed, dialogue.opened, dialogue.closed]:
        c.connect(_update_freeze)
    puzzle_ui.closed.connect(_flush_dialogues)

    AudioManager.level = 0.0
    AudioManager.start_music(GameState.seed_value)
    get_tree().create_timer(1.2, false).timeout.connect(func():
        GameState.dialogue_requested.emit({"title": "Sonaria", "text": "The world has gone silent. Walk (WASD) and press E near glowing things. Your Resonance Core will remember the rest."}))

func _exit_tree() -> void:
    AudioManager.stop_music()
    get_tree().paused = false

func _on_dialogue(req: Dictionary) -> void:
    if puzzle_ui.visible:
        _pending_dialogues.append(req)
    else:
        dialogue.show_request(req)

func _flush_dialogues() -> void:
    if _pending_dialogues.is_empty():
        return
    get_tree().create_timer(0.4, false).timeout.connect(func():
        while not _pending_dialogues.is_empty():
            dialogue.show_request(_pending_dialogues.pop_front()))

func _update_freeze() -> void:
    player.frozen = puzzle_ui.visible or dialogue.visible or paused or GameState.won

func _on_region_completed(region: String) -> void:
    AudioManager.play_sfx("region_complete")
    if region != "sanctum":
        hud.show_banner("%s restored" % SData.REGION_NAMES[region], SData.GOLD)

func _on_won() -> void:
    player.frozen = true
    victory = VictoryScreen.new()
    _overlay.add_child(victory)
    victory.replay_requested.connect(func(): _restart(GameState.seed_value))
    victory.new_seed_requested.connect(func(): _restart(randi() % 1000000))
    victory.menu_requested.connect(func(): menu_requested.emit())

func _restart(seed_value: int) -> void:
    _unpause()
    restart_requested.emit(seed_value)

func _unpause() -> void:
    paused = false
    get_tree().paused = false

func _resume() -> void:
    pause_menu.visible = false
    _unpause()
    _update_freeze()

func _unhandled_input(event: InputEvent) -> void:
    if GameState.won:
        return
    if event.is_action_pressed("debug"):
        hud.toggle_debug()
    elif event.is_action_pressed("pause") and not puzzle_ui.visible and not dialogue.visible:
        if paused:
            _resume()
        else:
            paused = true
            pause_menu.visible = true
            get_tree().paused = true
            _update_freeze()
