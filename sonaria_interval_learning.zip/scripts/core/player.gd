class_name Player
extends CharacterBody2D
## 8-directional player with smooth acceleration, interaction targeting and
## note casting. All input is ignored while `frozen` (menus/puzzles).

signal prompt_changed(text: String)
signal note_cast(ability: String, affected: bool)

const SPEED := 150.0
const ACCEL := 900.0
const FRICTION := 1200.0
const CAST_COOLDOWN := 0.55

var frozen := false
var world = null
var facing := Vector2.DOWN
var target: WorldObject = null
var camera: Camera2D
var light: PointLight2D
var _t := 0.0
var _cast_cd := 0.0
var _explore_t := 0.0
var _step_t := 0.0
var _core_pulse := 0.0
var _last_prompt := ""

func _ready() -> void:
    collision_layer = 1
    collision_mask = 2
    var shape := CollisionShape2D.new()
    var c := CircleShape2D.new()
    c.radius = 8.0
    shape.shape = c
    shape.position = Vector2(0, -4)
    add_child(shape)
    camera = Camera2D.new()
    camera.zoom = Vector2(1.6, 1.6)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 7.0
    camera.limit_left = 0
    camera.limit_top = 0
    camera.limit_right = int(SData.MAP_PX.x)
    camera.limit_bottom = int(SData.MAP_PX.y)
    camera.position = Vector2(0, -16)
    add_child(camera)
    light = PointLight2D.new()
    light.texture = Fx.glow_texture()
    light.texture_scale = 2.6
    light.energy = 0.75
    light.color = Color(0.75, 0.88, 1.0)
    light.position = Vector2(0, -16)
    add_child(light)

func _physics_process(delta: float) -> void:
    var dir := Vector2.ZERO
    if not frozen:
        dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
    if dir.length() > 0.05:
        velocity = velocity.move_toward(dir.normalized() * SPEED, ACCEL * delta)
        facing = dir.normalized()
    else:
        velocity = velocity.move_toward(Vector2.ZERO, FRICTION * delta)
    move_and_slide()
    _step_t += velocity.length() * delta

func _process(delta: float) -> void:
    _t += delta
    _cast_cd = maxf(0.0, _cast_cd - delta)
    _core_pulse = maxf(0.0, _core_pulse - delta * 2.0)
    queue_redraw()
    _update_target()
    _explore_t += delta
    if _explore_t > 0.4 and world != null:
        _explore_t = 0.0
        GameState.mark_explored(global_position)
        GameState.set_region(SData.region_at_tile(global_position.x / SData.TILE))

func _update_target() -> void:
    if frozen:
        _set_target(null)
        return
    var best: WorldObject = null
    var bd := 1e9
    for o in get_tree().get_nodes_in_group("interactable"):
        if not is_instance_valid(o) or not o.can_interact():
            continue
        var d := global_position.distance_to(o.interact_point())
        if d < o.interact_radius and d < bd:
            best = o
            bd = d
    _set_target(best)

func _set_target(o: WorldObject) -> void:
    if o != target:
        if target != null and is_instance_valid(target):
            target.highlighted = false
            target.queue_redraw()
        target = o
        if target != null:
            target.highlighted = true
    var txt := ""
    if target != null:
        txt = target.prompt()
    if txt != _last_prompt:
        _last_prompt = txt
        prompt_changed.emit(txt)

func _unhandled_input(event: InputEvent) -> void:
    if frozen:
        return
    if event.is_action_pressed("interact") and target != null and is_instance_valid(target):
        target.interact(self)
        get_viewport().set_input_as_handled()
    elif event.is_action_pressed("cast"):
        cast_note()
        get_viewport().set_input_as_handled()
    else:
        for i in 3:
            if event.is_action_pressed("note_%d" % (i + 1)):
                select_ability(SData.ABILITIES[i])
                get_viewport().set_input_as_handled()

func select_ability(a: String) -> void:
    if not GameState.abilities.get(a, false):
        GameState.toast.emit("You haven't learned the %s Note yet." % SData.ABILITY_LABEL[a], Color("ff8aa8"))
        return
    GameState.selected_ability = a
    AudioManager.play_ability(a)
    GameState.objective_changed.emit()

## Sing the selected note: affects every matching target within its radius.
func cast_note() -> bool:
    if _cast_cd > 0.0:
        return false
    var a := GameState.selected_ability
    if not GameState.abilities.get(a, false):
        GameState.toast.emit("Learn a note first: wake the Awakening Stone.", Color("ff8aa8"))
        return false
    _cast_cd = CAST_COOLDOWN
    _core_pulse = 1.0
    AudioManager.play_ability(a)
    var col: Color = SData.NOTE_COLOR[SData.ABILITY_NOTE[a]]
    if world != null:
        Fx.ring(world.fx, global_position + Vector2(0, -8), col, 130.0, 0.7)
    var affected := false
    for o in get_tree().get_nodes_in_group("note_target"):
        if not is_instance_valid(o):
            continue
        if o.global_position.distance_to(global_position) <= o.note_radius():
            if o.on_note(a, self):
                affected = true
    note_cast.emit(a, affected)
    return affected

func _draw() -> void:
    var bob := sin(_step_t * 0.12) * 1.5 if velocity.length() > 10.0 else sin(_t * 2.0) * 0.6
    var a := GameState.selected_ability
    var core: Color = SData.NOTE_COLOR[SData.ABILITY_NOTE[a]] if GameState.abilities.get(a, false) else SData.GOLD
    draw_circle(Vector2(0, 0), 9.0, Color(0, 0, 0, 0.28))
    draw_colored_polygon(PackedVector2Array([Vector2(-9, 0), Vector2(-6, -20 + bob), Vector2(6, -20 + bob), Vector2(9, 0)]), Color("3b3a7a"))
    draw_colored_polygon(PackedVector2Array([Vector2(-9, 0), Vector2(-2, -4), Vector2(0, 0)]), Color("2a2960"))
    draw_circle(Vector2(0, -24 + bob), 6.5, Color("e8d2b8"))
    draw_arc(Vector2(0, -25 + bob), 7.5, PI, TAU, 12, Color("4b49a0"), 4.0)
    var eye := facing * 2.0
    draw_circle(Vector2(-2, -24 + bob) + eye, 0.9, Color("1a1a40"))
    draw_circle(Vector2(2, -24 + bob) + eye, 0.9, Color("1a1a40"))
    var orb := Vector2(cos(_t * 2.2) * 13.0, -16.0 + sin(_t * 2.2) * 4.0 + bob)
    Art.glow(self, orb, 11.0 + _core_pulse * 10.0, core, 0.9)
    draw_circle(orb, 3.0, Color(1, 1, 1, 0.95))
