class_name Art
extends RefCounted
## Small procedural drawing helpers shared by world objects and UI.
## All functions must be called from inside a CanvasItem's _draw().

## Thick line drawn as an explicit quad (avoids driver quirks of wide draw_line).
static func thick_line(ci: CanvasItem, a: Vector2, b: Vector2, w: float, color: Color) -> void:
    var d := b - a
    if d.length() < 0.001:
        return
    var n := Vector2(-d.y, d.x).normalized() * (w * 0.5)
    ci.draw_colored_polygon(PackedVector2Array([a + n, b + n, b - n, a - n]), color)

static func glow(ci: CanvasItem, pos: Vector2, r: float, color: Color, strength := 0.5) -> void:
    for i in 4:
        var k := 1.0 - float(i) * 0.24
        ci.draw_circle(pos, r * k, Color(color.r, color.g, color.b, strength * 0.13 * float(i + 1)))

static func crystal(ci: CanvasItem, pos: Vector2, h: float, w: float, color: Color) -> void:
    var pts := PackedVector2Array([pos + Vector2(0, -h), pos + Vector2(w, -h * 0.35), pos + Vector2(0, h * 0.25), pos + Vector2(-w, -h * 0.35)])
    ci.draw_colored_polygon(pts, color)
    ci.draw_colored_polygon(PackedVector2Array([pts[0], pts[1], pos + Vector2(0, -h * 0.35)]), color.lightened(0.35))
    ci.draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), color.lightened(0.55), 1.2)

static func star(ci: CanvasItem, pos: Vector2, r: float, color: Color, points := 5) -> void:
    var pts := PackedVector2Array()
    for i in points * 2:
        var a := -PI / 2.0 + PI * float(i) / float(points)
        var rr := r if i % 2 == 0 else r * 0.45
        pts.append(pos + Vector2(cos(a), sin(a)) * rr)
    ci.draw_colored_polygon(pts, color)

## Glyph ids: 0 circle, 1 triangle, 2 diamond, 3 star
static func glyph(ci: CanvasItem, id: int, pos: Vector2, r: float, color: Color, filled := true) -> void:
    var pts := PackedVector2Array()
    match id:
        0:
            if filled:
                ci.draw_circle(pos, r, color)
            else:
                ci.draw_arc(pos, r, 0.0, TAU, 24, color, 2.0)
            return
        1:
            pts = PackedVector2Array([pos + Vector2(0, -r), pos + Vector2(r, r * 0.8), pos + Vector2(-r, r * 0.8)])
        2:
            pts = PackedVector2Array([pos + Vector2(0, -r), pos + Vector2(r, 0), pos + Vector2(0, r), pos + Vector2(-r, 0)])
        _:
            if filled:
                star(ci, pos, r * 1.15, color)
            else:
                var sp := PackedVector2Array()
                for i in 11:
                    var a := -PI / 2.0 + PI * float(i % 10) / 5.0
                    var rr := r * 1.15 if i % 2 == 0 else r * 0.5
                    sp.append(pos + Vector2(cos(a), sin(a)) * rr)
                ci.draw_polyline(sp, color, 2.0)
            return
    if filled:
        ci.draw_colored_polygon(pts, color)
    else:
        pts.append(pts[0])
        ci.draw_polyline(pts, color, 2.0)
