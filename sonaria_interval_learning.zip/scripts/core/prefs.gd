extends Node
## User preferences + keyboard input registration (autoload "Prefs").

const PATH := "user://sonaria_settings.cfg"
var master := 0.8
var music := 0.8
var sfx := 0.9
var particles := true
var use_llm := true

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _register_inputs()
    load_settings()

func _bind(action: String, keys: Array) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)
    for k in keys:
        var ev := InputEventKey.new()
        ev.physical_keycode = k
        InputMap.action_add_event(action, ev)

func _register_inputs() -> void:
    _bind("move_left", [KEY_A, KEY_LEFT])
    _bind("move_right", [KEY_D, KEY_RIGHT])
    _bind("move_up", [KEY_W, KEY_UP])
    _bind("move_down", [KEY_S, KEY_DOWN])
    _bind("interact", [KEY_E])
    _bind("cast", [KEY_SPACE])
    _bind("note_1", [KEY_1])
    _bind("note_2", [KEY_2])
    _bind("note_3", [KEY_3])
    _bind("pause", [KEY_ESCAPE, KEY_P])
    _bind("debug", [KEY_F3])

func load_settings() -> void:
    var cf := ConfigFile.new()
    if cf.load(PATH) != OK:
        return
    master = cf.get_value("audio", "master", master)
    music = cf.get_value("audio", "music", music)
    sfx = cf.get_value("audio", "sfx", sfx)
    particles = cf.get_value("video", "particles", particles)
    use_llm = cf.get_value("ai", "use_llm", use_llm)

func save_settings() -> void:
    var cf := ConfigFile.new()
    cf.set_value("audio", "master", master)
    cf.set_value("audio", "music", music)
    cf.set_value("audio", "sfx", sfx)
    cf.set_value("video", "particles", particles)
    cf.set_value("ai", "use_llm", use_llm)
    cf.save(PATH)
